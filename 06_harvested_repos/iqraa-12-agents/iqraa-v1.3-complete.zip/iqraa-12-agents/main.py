#!/usr/bin/env python3
"""
IQRA System v1.3 - Main Entry Point
=====================================
11 Agents | 6 Gates | 12 Playbooks

Usage:
    python main.py query "ما تعريف التوحيد؟"
    python main.py serve --port 8080
    python main.py test
"""

import asyncio
import argparse
import logging
import sys
from datetime import datetime

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s'
)
logger = logging.getLogger("iqra.main")


async def run_query(query: str, session_id: str = None):
    """
    Run a query through the IQRA system.
    
    Flow:
    1. Linguist preprocesses the query
    2. Orchestrator classifies and plans
    3. Execute playbook steps
    4. Guardian validates at gates
    5. Return result
    """
    from src.preprocessing.linguist import LinguistAgent
    from src.core.orchestrator import OrchestratorAgent
    from src.core.guardian import GuardianAgent
    from src.shared.base_agent import AgentMessage
    import uuid
    
    run_id = f"RUN-{uuid.uuid4().hex[:8].upper()}"
    session_id = session_id or f"SESS-{uuid.uuid4().hex[:8].upper()}"
    
    logger.info(f"Starting run {run_id} for query: {query[:50]}...")
    
    # Initialize agents
    linguist = LinguistAgent()
    orchestrator = OrchestratorAgent()
    guardian = GuardianAgent()
    
    # Step 1: Linguistic preprocessing
    logger.info("Step 1: Linguistic preprocessing...")
    ling_message = AgentMessage(
        run_id=run_id,
        session_id=session_id,
        from_agent="SYSTEM",
        to_agent="AGT-01-LINGUIST",
        payload={"text": query},
    )
    ling_result = await linguist.execute(ling_message)
    
    if not ling_result.success:
        logger.error(f"Linguistic analysis failed: {ling_result.error}")
        return {"success": False, "error": ling_result.error}
    
    # Gate G-0: Input validation
    logger.info("Gate G-0: Input validation...")
    g0_message = AgentMessage(
        run_id=run_id,
        payload={
            "action": "evaluate_gate",
            "gate_id": "G-0",
            "data": {"linguistic_analysis": ling_result.output.to_dict()},
        },
    )
    g0_result = await guardian.execute(g0_message)
    
    if not g0_result.output.passed:
        logger.warning(f"Gate G-0 failed: {g0_result.output.to_dict()}")
    
    # Step 2: Query classification and planning
    logger.info("Step 2: Query classification and planning...")
    orch_message = AgentMessage(
        run_id=run_id,
        session_id=session_id,
        from_agent="AGT-01-LINGUIST",
        to_agent="AGT-02-ORCHESTRATOR",
        payload={
            "query": query,
            "linguistic_analysis": ling_result.output.to_dict(),
        },
    )
    plan_result = await orchestrator.execute(orch_message)
    
    if not plan_result.success:
        logger.error(f"Planning failed: {plan_result.error}")
        return {"success": False, "error": plan_result.error}
    
    plan = plan_result.output
    logger.info(f"Query type: {plan.query_type.value}")
    logger.info(f"Playbook: {plan.playbook.value}")
    logger.info(f"Steps: {len(plan.steps)}")
    
    # Step 3: Execute playbook (simplified for demo)
    logger.info("Step 3: Executing playbook...")
    
    # For demo, we'll just return the plan
    # In production, this would execute each step
    
    # Gate G-5: Export validation
    logger.info("Gate G-5: Export validation...")
    g5_message = AgentMessage(
        run_id=run_id,
        payload={
            "action": "export_check",
            "data": {
                "query": query,
                "plan": plan.to_dict(),
            },
        },
    )
    g5_result = await guardian.execute(g5_message)
    
    # Build response
    response = {
        "success": True,
        "run_id": run_id,
        "session_id": session_id,
        "query": query,
        "query_type": plan.query_type.value,
        "playbook": plan.playbook.value,
        "linguistic_analysis": ling_result.output.to_dict(),
        "execution_plan": plan.to_dict(),
        "gates": {
            "G-0": g0_result.output.to_dict(),
            "G-5": g5_result.output.to_dict(),
        },
        "timestamp": datetime.utcnow().isoformat(),
    }
    
    logger.info(f"Run {run_id} completed successfully")
    return response


def serve(host: str = "0.0.0.0", port: int = 8080):
    """Start the IQRA API server."""
    logger.info(f"Starting IQRA server on {host}:{port}")
    
    try:
        from fastapi import FastAPI
        import uvicorn
        
        app = FastAPI(
            title="IQRA System API",
            version="1.3",
            description="Islamic Knowledge Research Assistant"
        )
        
        @app.get("/health")
        async def health():
            return {"status": "healthy", "version": "1.3"}
        
        @app.post("/query")
        async def query(request: dict):
            query_text = request.get("query", "")
            session_id = request.get("session_id")
            result = await run_query(query_text, session_id)
            return result
        
        uvicorn.run(app, host=host, port=port)
        
    except ImportError:
        logger.error("FastAPI/uvicorn not installed. Run: pip install fastapi uvicorn")
        sys.exit(1)


def run_tests():
    """Run test suite."""
    import subprocess
    result = subprocess.run(
        ["python", "-m", "pytest", "tests/", "-v"],
        cwd="/home/claude/iqraa-12-agents"
    )
    sys.exit(result.returncode)


def main():
    parser = argparse.ArgumentParser(
        description="IQRA System v1.3 - Islamic Knowledge Research Assistant"
    )
    subparsers = parser.add_subparsers(dest="command", help="Commands")
    
    # Query command
    query_parser = subparsers.add_parser("query", help="Run a query")
    query_parser.add_argument("text", help="Query text in Arabic")
    query_parser.add_argument("--session", help="Session ID")
    
    # Serve command
    serve_parser = subparsers.add_parser("serve", help="Start API server")
    serve_parser.add_argument("--host", default="0.0.0.0", help="Host")
    serve_parser.add_argument("--port", type=int, default=8080, help="Port")
    
    # Test command
    subparsers.add_parser("test", help="Run tests")
    
    args = parser.parse_args()
    
    if args.command == "query":
        result = asyncio.run(run_query(args.text, args.session))
        import json
        print(json.dumps(result, ensure_ascii=False, indent=2))
        
    elif args.command == "serve":
        serve(args.host, args.port)
        
    elif args.command == "test":
        run_tests()
        
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
