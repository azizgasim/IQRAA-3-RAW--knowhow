-- =============================================================================
-- IQRA System v1.3 - BigQuery Schema
-- 21 Tables across 2 Datasets: ops_logs (8) + kb_store (13)
-- =============================================================================

-- =============================================================================
-- DATASET: ops_logs (Operational Logs)
-- =============================================================================

-- 1. run_index: One record per execution
CREATE TABLE IF NOT EXISTS `{PROJECT_ID}.ops_logs.run_index` (
  run_id STRING NOT NULL,
  session_id STRING,
  user_id STRING,
  query_text STRING,
  query_type STRING,
  playbook_id STRING,
  status STRING,  -- pending, running, completed, failed, cancelled
  started_at TIMESTAMP NOT NULL,
  completed_at TIMESTAMP,
  total_cost_usd FLOAT64,
  total_tokens INT64,
  gate_results JSON,
  metadata JSON,
  PRIMARY KEY (run_id) NOT ENFORCED
);

-- 2. journal_entries: Flexible event log
CREATE TABLE IF NOT EXISTS `{PROJECT_ID}.ops_logs.journal_entries` (
  entry_id STRING NOT NULL,
  run_id STRING NOT NULL,
  timestamp TIMESTAMP NOT NULL,
  agent_id STRING,
  event_type STRING,
  event_data JSON,
  severity STRING,  -- debug, info, warn, error
  PRIMARY KEY (entry_id) NOT ENFORCED
);

-- 3. gate_events: Structured gate records
CREATE TABLE IF NOT EXISTS `{PROJECT_ID}.ops_logs.gate_events` (
  event_id STRING NOT NULL,
  run_id STRING NOT NULL,
  gate_id STRING NOT NULL,  -- G-0 to G-5
  timestamp TIMESTAMP NOT NULL,
  passed BOOL NOT NULL,
  criteria_results JSON,
  blocking_criteria ARRAY<STRING>,
  agent_id STRING,
  confidence FLOAT64,
  notes STRING,
  PRIMARY KEY (event_id) NOT ENFORCED
);

-- 4. agent_messages: Communication log
CREATE TABLE IF NOT EXISTS `{PROJECT_ID}.ops_logs.agent_messages` (
  message_id STRING NOT NULL,
  run_id STRING NOT NULL,
  from_agent STRING,
  to_agent STRING,
  message_type STRING,  -- request, response, event, error
  payload JSON,
  timestamp TIMESTAMP NOT NULL,
  correlation_id STRING,
  trace_id STRING,
  latency_ms INT64,
  PRIMARY KEY (message_id) NOT ENFORCED
);

-- 5. error_log: Basic error log (legacy)
CREATE TABLE IF NOT EXISTS `{PROJECT_ID}.ops_logs.error_log` (
  error_id STRING NOT NULL,
  run_id STRING,
  timestamp TIMESTAMP NOT NULL,
  agent_id STRING,
  error_type STRING,
  error_message STRING,
  stack_trace STRING,
  severity STRING,
  PRIMARY KEY (error_id) NOT ENFORCED
);

-- 6. error_registry: Centralized error tracking (NEW v1.3)
CREATE TABLE IF NOT EXISTS `{PROJECT_ID}.ops_logs.error_registry` (
  error_id STRING NOT NULL,
  run_id STRING,
  agent_id STRING,
  timestamp TIMESTAMP NOT NULL,
  error_type STRING,  -- validation, processing, integration, timeout
  error_code STRING,  -- E001, E002, etc.
  severity STRING,    -- critical, high, medium, low
  error_message STRING,
  input_snapshot JSON,
  output_snapshot JSON,
  gate_id STRING,
  root_cause STRING,
  resolution STRING,
  prevention_rule STRING,
  status STRING,  -- open, analyzing, resolved, learned
  PRIMARY KEY (error_id) NOT ENFORCED
);

-- 7. error_patterns: Discovered error patterns (NEW v1.3)
CREATE TABLE IF NOT EXISTS `{PROJECT_ID}.ops_logs.error_patterns` (
  pattern_id STRING NOT NULL,
  pattern_name STRING,
  detection_rule JSON,
  affected_agents ARRAY<STRING>,
  occurrence_count INT64,
  first_seen TIMESTAMP,
  last_seen TIMESTAMP,
  recommended_fix STRING,
  auto_fix_available BOOL,
  success_rate_after_fix FLOAT64,
  status STRING,  -- active, resolved, monitoring
  PRIMARY KEY (pattern_id) NOT ENFORCED
);

-- 8. human_review_queue: Human review requests (NEW v1.3)
CREATE TABLE IF NOT EXISTS `{PROJECT_ID}.ops_logs.human_review_queue` (
  review_id STRING NOT NULL,
  run_id STRING NOT NULL,
  artifact_type STRING,  -- evidence, theory, claim, export
  artifact_id STRING,
  trigger_type STRING,   -- confidence, topic, gate, method
  trigger_details JSON,
  current_level INT64,   -- 1, 2, or 3
  assigned_reviewer STRING,
  assigned_at TIMESTAMP,
  decision STRING,       -- pending, approved, rejected, needs_revision
  decision_reason STRING,
  decided_at TIMESTAMP,
  status STRING,         -- pending, in_review, decided
  created_at TIMESTAMP NOT NULL,
  PRIMARY KEY (review_id) NOT ENFORCED
);

-- =============================================================================
-- DATASET: kb_store (Knowledge Base Store)
-- =============================================================================

-- 1. sources: Books, papers, manuscripts
CREATE TABLE IF NOT EXISTS `{PROJECT_ID}.kb_store.sources` (
  source_id STRING NOT NULL,
  title_ar STRING,
  title_en STRING,
  author_id STRING,
  source_type STRING,  -- book, manuscript, article, website
  publication_year INT64,
  publisher STRING,
  url STRING,
  metadata JSON,
  created_at TIMESTAMP NOT NULL,
  PRIMARY KEY (source_id) NOT ENFORCED
);

-- 2. notes: Summaries, excerpts, critiques
CREATE TABLE IF NOT EXISTS `{PROJECT_ID}.kb_store.notes` (
  note_id STRING NOT NULL,
  source_id STRING,
  note_type STRING,  -- summary, excerpt, critique, observation
  content STRING,
  page_ref STRING,
  created_by STRING,
  created_at TIMESTAMP NOT NULL,
  tags ARRAY<STRING>,
  PRIMARY KEY (note_id) NOT ENFORCED
);

-- 3. concept_cards: Operational definitions
CREATE TABLE IF NOT EXISTS `{PROJECT_ID}.kb_store.concept_cards` (
  concept_id STRING NOT NULL,
  term_ar STRING NOT NULL,
  term_en STRING,
  definition_ar STRING NOT NULL,
  definition_en STRING,
  domain STRING,
  subdomain STRING,
  related_concepts ARRAY<STRING>,
  evidence_ids ARRAY<STRING>,
  created_at TIMESTAMP NOT NULL,
  updated_at TIMESTAMP,
  version INT64 DEFAULT 1,
  PRIMARY KEY (concept_id) NOT ENFORCED
);

-- 4. evidence_units: Evidence records (UPDATED v1.3 with FRBR)
CREATE TABLE IF NOT EXISTS `{PROJECT_ID}.kb_store.evidence_units` (
  evidence_id STRING NOT NULL,
  run_id STRING,
  claim_text STRING NOT NULL,
  source_type STRING,  -- primary, secondary, tertiary
  work_id STRING,      -- FRBR
  expression_id STRING,
  manifestation_id STRING,
  item_id STRING,
  volume INT64,
  page_start INT64,
  page_end INT64,
  line_start INT64,
  line_end INT64,
  context_before STRING,
  context_after STRING,
  verified_against_original BOOL DEFAULT FALSE,
  linguistic_analysis_id STRING,
  confidence_score FLOAT64,
  created_at TIMESTAMP NOT NULL,
  created_by STRING,
  PRIMARY KEY (evidence_id) NOT ENFORCED
);

-- 5. context_units: Hidden context records
CREATE TABLE IF NOT EXISTS `{PROJECT_ID}.kb_store.context_units` (
  context_id STRING NOT NULL,
  concept_id STRING,
  context_type STRING,
  description STRING,
  time_period STRING,
  location STRING,
  key_figures ARRAY<STRING>,
  evidence_ids ARRAY<STRING>,
  created_at TIMESTAMP NOT NULL,
  PRIMARY KEY (context_id) NOT ENFORCED
);

-- 6. lineage_links: Transfer chains
CREATE TABLE IF NOT EXISTS `{PROJECT_ID}.kb_store.lineage_links` (
  link_id STRING NOT NULL,
  source_concept_id STRING NOT NULL,
  target_concept_id STRING NOT NULL,
  relation_type STRING,
  confidence FLOAT64,
  evidence_ids ARRAY<STRING>,
  temporal_order STRING,
  notes STRING,
  created_at TIMESTAMP NOT NULL,
  PRIMARY KEY (link_id) NOT ENFORCED
);

-- 7. spark_cards: Scout discoveries
CREATE TABLE IF NOT EXISTS `{PROJECT_ID}.kb_store.spark_cards` (
  spark_id STRING NOT NULL,
  spark_type STRING,
  description STRING,
  related_concepts ARRAY<STRING>,
  potential_significance STRING,
  suggested_investigation STRING,
  discovered_at TIMESTAMP NOT NULL,
  status STRING,
  PRIMARY KEY (spark_id) NOT ENFORCED
);

-- 8. theory_cards: Theorist outputs
CREATE TABLE IF NOT EXISTS `{PROJECT_ID}.kb_store.theory_cards` (
  theory_id STRING NOT NULL,
  title STRING NOT NULL,
  thesis_statement STRING,
  key_arguments ARRAY<STRING>,
  supporting_evidence ARRAY<STRING>,
  counter_arguments ARRAY<STRING>,
  assumptions ARRAY<STRING>,
  implications ARRAY<STRING>,
  confidence_level FLOAT64,
  status STRING,
  gate_4_passed BOOL DEFAULT FALSE,
  created_at TIMESTAMP NOT NULL,
  updated_at TIMESTAMP,
  PRIMARY KEY (theory_id) NOT ENFORCED
);

-- 9. works: FRBR Works (NEW v1.3)
CREATE TABLE IF NOT EXISTS `{PROJECT_ID}.kb_store.works` (
  work_id STRING NOT NULL,
  title_ar STRING NOT NULL,
  title_en STRING,
  author_id STRING,
  creation_date STRING,
  creation_date_hijri STRING,
  work_type STRING,
  subject_classification ARRAY<STRING>,
  related_works ARRAY<STRING>,
  derivative_of STRING,
  language STRING DEFAULT 'ar',
  created_at TIMESTAMP NOT NULL,
  PRIMARY KEY (work_id) NOT ENFORCED
);

-- 10. expressions: FRBR Expressions (NEW v1.3)
CREATE TABLE IF NOT EXISTS `{PROJECT_ID}.kb_store.expressions` (
  expression_id STRING NOT NULL,
  work_id STRING NOT NULL,
  expression_type STRING,
  language STRING,
  translator_id STRING,
  expression_date STRING,
  notes STRING,
  created_at TIMESTAMP NOT NULL,
  PRIMARY KEY (expression_id) NOT ENFORCED
);

-- 11. manifestations: FRBR Manifestations (NEW v1.3)
CREATE TABLE IF NOT EXISTS `{PROJECT_ID}.kb_store.manifestations` (
  manifestation_id STRING NOT NULL,
  expression_id STRING NOT NULL,
  publisher STRING,
  publication_place STRING,
  publication_year INT64,
  publication_year_hijri STRING,
  edition_number INT64,
  editor_id STRING,
  scholarly_edition BOOL DEFAULT FALSE,
  tahqiq_quality STRING,
  isbn STRING,
  total_volumes INT64,
  total_pages INT64,
  created_at TIMESTAMP NOT NULL,
  PRIMARY KEY (manifestation_id) NOT ENFORCED
);

-- 12. items: FRBR Items (NEW v1.3)
CREATE TABLE IF NOT EXISTS `{PROJECT_ID}.kb_store.items` (
  item_id STRING NOT NULL,
  manifestation_id STRING NOT NULL,
  holding_institution STRING,
  call_number STRING,
  condition STRING,
  digital_copy_url STRING,
  ocr_quality FLOAT64,
  manuscript_number STRING,
  provenance STRING,
  notes STRING,
  created_at TIMESTAMP NOT NULL,
  PRIMARY KEY (item_id) NOT ENFORCED
);

-- 13. semantic_index_metadata: RAG index metadata (NEW v1.3)
CREATE TABLE IF NOT EXISTS `{PROJECT_ID}.kb_store.semantic_index_metadata` (
  chunk_id STRING NOT NULL,
  source_table STRING,
  source_id STRING,
  chunk_text STRING,
  chunk_position INT64,
  source_type STRING,
  author STRING,
  era STRING,
  topic_tags ARRAY<STRING>,
  linguistic_analysis_id STRING,
  embedding_model STRING,
  indexed_at TIMESTAMP NOT NULL,
  PRIMARY KEY (chunk_id) NOT ENFORCED
);

-- =============================================================================
-- INDEXES (for Vector Search - Vertex AI)
-- =============================================================================
-- Note: Vector embeddings stored in Vertex AI Vector Search, not BigQuery
-- This table stores metadata for linking

-- Authors table (supporting FRBR)
CREATE TABLE IF NOT EXISTS `{PROJECT_ID}.kb_store.authors` (
  author_id STRING NOT NULL,
  name_ar STRING NOT NULL,
  name_en STRING,
  birth_date STRING,
  death_date STRING,
  birth_date_hijri STRING,
  death_date_hijri STRING,
  biography STRING,
  school_of_thought STRING,
  teachers ARRAY<STRING>,
  students ARRAY<STRING>,
  wikidata_id STRING,
  created_at TIMESTAMP NOT NULL,
  PRIMARY KEY (author_id) NOT ENFORCED
);
