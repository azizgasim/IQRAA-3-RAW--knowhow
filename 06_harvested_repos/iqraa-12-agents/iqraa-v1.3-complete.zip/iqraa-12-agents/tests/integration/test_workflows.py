"""
Integration Tests for IQRA System
==================================
End-to-end tests for complete workflows.
"""

import pytest
import asyncio
from unittest.mock import Mock, patch, AsyncMock

from src.core.orchestrator import OrchestratorAgent, QueryType, PlaybookType
from src.core.guardian import GuardianAgent
from src.preprocessing.linguist import LinguistAgent
from src.understanding.evidencer import EvidencerAgent
from src.understanding.analyst import AnalystAgent
from src.shared.base_agent import AgentMessage, AgentResult


class TestEvidenceWorkflow:
    """Test complete evidence retrieval workflow (PB-01)."""
    
    @pytest.fixture
    def agents(self):
        return {
            "orchestrator": OrchestratorAgent(),
            "linguist": LinguistAgent(),
            "evidencer": EvidencerAgent(),
            "guardian": GuardianAgent(),
        }
    
    @pytest.mark.asyncio
    async def test_evidence_workflow_e2e(self, agents):
        """Test complete evidence lookup workflow."""
        query = "ما دليل وجوب الزكاة من القرآن؟"
        
        # Step 1: Orchestrator creates plan
        orch_message = AgentMessage(payload={"query": query})
        plan_result = await agents["orchestrator"].process(orch_message)
        
        assert plan_result.success
        assert plan_result.output.query_type == QueryType.EVIDENCE_LOOKUP
        
        # Step 2: Linguist processes text
        ling_message = AgentMessage(payload={"text": query})
        ling_result = await agents["linguist"].process(ling_message)
        
        assert ling_result.success
        assert len(ling_result.output.tokens) > 0
        
        # Step 3: Guardian checks G-0
        g0_message = AgentMessage(payload={
            "action": "evaluate_gate",
            "gate_id": "G-0",
            "data": {"analysis": ling_result.output.to_dict()}
        })
        g0_result = await agents["guardian"].process(g0_message)
        
        assert g0_result.success
        assert g0_result.output.passed
        
        # Step 4: Evidencer collects evidence
        evid_message = AgentMessage(payload={
            "action": "collect",
            "query": query,
            "linguistic_analysis": ling_result.output.to_dict()
        })
        evid_result = await agents["evidencer"].process(evid_message)
        
        assert evid_result.success
        assert len(evid_result.output.evidence_units) > 0
        
        # Step 5: Guardian checks G-1
        g1_message = AgentMessage(payload={
            "action": "evaluate_gate",
            "gate_id": "G-1",
            "data": {"frbr_complete": True}
        })
        g1_result = await agents["guardian"].process(g1_message)
        
        assert g1_result.success


class TestConceptWorkflow:
    """Test complete concept analysis workflow (PB-02)."""
    
    @pytest.fixture
    def agents(self):
        return {
            "orchestrator": OrchestratorAgent(),
            "linguist": LinguistAgent(),
            "evidencer": EvidencerAgent(),
            "analyst": AnalystAgent(),
            "guardian": GuardianAgent(),
        }
    
    @pytest.mark.asyncio
    async def test_concept_workflow_e2e(self, agents):
        """Test complete concept analysis workflow."""
        query = "ما مفهوم التوحيد في العقيدة الإسلامية؟"
        
        # Step 1: Orchestrator
        plan_result = await agents["orchestrator"].process(
            AgentMessage(payload={"query": query})
        )
        assert plan_result.output.query_type == QueryType.CONCEPT_ANALYSIS
        
        # Step 2: Linguist
        ling_result = await agents["linguist"].process(
            AgentMessage(payload={"text": query})
        )
        assert ling_result.success
        
        # Step 3: Evidencer
        evid_result = await agents["evidencer"].process(
            AgentMessage(payload={"action": "collect", "query": query})
        )
        assert evid_result.success
        
        # Step 4: Analyst creates concept card
        analyst_result = await agents["analyst"].process(
            AgentMessage(payload={
                "action": "create_concept",
                "term_ar": "التوحيد",
                "evidence_ids": [e.evidence_id for e in evid_result.output.evidence_units]
            })
        )
        assert analyst_result.success
        assert analyst_result.output.term_ar == "التوحيد"
        
        # Step 5: Guardian G-2
        g2_result = await agents["guardian"].process(
            AgentMessage(payload={
                "action": "evaluate_gate",
                "gate_id": "G-2",
                "data": {"evidence_ids": ["E1"]}
            })
        )
        assert g2_result.success


class TestGateEnforcement:
    """Test gate enforcement blocks invalid outputs."""
    
    @pytest.fixture
    def guardian(self):
        return GuardianAgent()
    
    @pytest.mark.asyncio
    async def test_blocking_gate_fails_on_low_score(self, guardian):
        """Test that blocking gates can fail."""
        message = AgentMessage(payload={
            "action": "evaluate_gate",
            "gate_id": "G-4",  # Theory gate - blocking
            "data": {"evidence_ids": []}  # Not enough evidence
        })
        result = await guardian.process(message)
        
        # Gate should not pass without sufficient evidence
        assert result.output.blocking is True
    
    @pytest.mark.asyncio
    async def test_non_blocking_gate_warns(self, guardian):
        """Test that non-blocking gates warn but don't fail."""
        message = AgentMessage(payload={
            "action": "evaluate_gate",
            "gate_id": "G-2",  # Concept gate - non-blocking
            "data": {}
        })
        result = await guardian.process(message)
        
        assert result.output.blocking is False


class TestErrorHandling:
    """Test error handling across agents."""
    
    @pytest.mark.asyncio
    async def test_linguist_handles_invalid_input(self):
        agent = LinguistAgent()
        message = AgentMessage(payload={"text": ""})
        
        result = await agent.execute(message)
        assert result.success is False
        assert "validation" in result.error.lower()
    
    @pytest.mark.asyncio
    async def test_orchestrator_handles_empty_query(self):
        agent = OrchestratorAgent()
        message = AgentMessage(payload={"query": ""})
        
        result = await agent.execute(message)
        assert result.success is False


class TestConfidenceThresholds:
    """Test confidence-based routing."""
    
    @pytest.mark.asyncio
    async def test_low_confidence_triggers_review(self):
        """Test that low confidence triggers human review flag."""
        agent = LinguistAgent()
        agent.config.confidence_threshold = 0.9
        
        message = AgentMessage(payload={"text": "نص قصير"})
        result = await agent.execute(message)
        
        # With short text, confidence might be lower
        if result.confidence < 0.9:
            assert result.requires_human_review is True
