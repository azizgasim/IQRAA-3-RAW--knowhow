"""
Unit Tests for Guardian Agent
==============================
"""

import pytest
import asyncio

from src.core.guardian import (
    GuardianAgent, GateResult, CheckResult, AuditLog,
    GateID, CheckSeverity, GUARDIAN_CONFIG
)
from src.shared.base_agent import AgentMessage, AgentResult


class TestGuardianAgent:
    """Tests for GuardianAgent."""
    
    @pytest.fixture
    def agent(self):
        return GuardianAgent()
    
    # === Input Validation ===
    
    def test_validate_input_valid(self, agent):
        payload = {"action": "evaluate_gate", "gate_id": "G-0"}
        is_valid, error = agent.validate_input(payload)
        assert is_valid is True
    
    def test_validate_input_missing_action(self, agent):
        payload = {"gate_id": "G-0"}
        is_valid, error = agent.validate_input(payload)
        assert is_valid is False
    
    def test_validate_input_invalid_action(self, agent):
        payload = {"action": "invalid_action"}
        is_valid, error = agent.validate_input(payload)
        assert is_valid is False
    
    # === Gate Evaluation ===
    
    @pytest.mark.asyncio
    async def test_evaluate_gate_g0(self, agent):
        message = AgentMessage(payload={
            "action": "evaluate_gate",
            "gate_id": "G-0",
            "data": {}
        })
        result = await agent.process(message)
        
        assert result.success is True
        assert isinstance(result.output, GateResult)
        assert result.output.gate_id == "G-0"
    
    @pytest.mark.asyncio
    async def test_evaluate_gate_returns_checks(self, agent):
        message = AgentMessage(payload={
            "action": "evaluate_gate",
            "gate_id": "G-1",
            "data": {"frbr_complete": True}
        })
        result = await agent.process(message)
        
        assert len(result.output.checks) > 0
        assert all(isinstance(c, CheckResult) for c in result.output.checks)
    
    @pytest.mark.asyncio
    async def test_evaluate_gate_calculates_score(self, agent):
        message = AgentMessage(payload={
            "action": "evaluate_gate",
            "gate_id": "G-5",
            "data": {}
        })
        result = await agent.process(message)
        
        assert 0 <= result.output.overall_score <= 1
    
    @pytest.mark.asyncio
    async def test_gate_blocking_status(self, agent):
        # G-0 is blocking
        message = AgentMessage(payload={
            "action": "evaluate_gate",
            "gate_id": "G-0",
            "data": {}
        })
        result = await agent.process(message)
        assert result.output.blocking is True
        
        # G-2 is non-blocking
        message.payload["gate_id"] = "G-2"
        result = await agent.process(message)
        assert result.output.blocking is False
    
    @pytest.mark.asyncio
    async def test_invalid_gate_id(self, agent):
        message = AgentMessage(payload={
            "action": "evaluate_gate",
            "gate_id": "G-99",
            "data": {}
        })
        result = await agent.process(message)
        assert result.success is False
    
    # === Audit Logging ===
    
    @pytest.mark.asyncio
    async def test_create_audit(self, agent):
        message = AgentMessage(
            run_id="RUN-001",
            payload={
                "action": "audit",
                "agent_id": "AGT-01-LINGUIST",
                "audit_action": "process_completed",
                "details": {"tokens": 50}
            }
        )
        result = await agent.process(message)
        
        assert result.success is True
        assert isinstance(result.output, AuditLog)
        assert result.output.run_id == "RUN-001"
    
    @pytest.mark.asyncio
    async def test_audit_stored(self, agent):
        initial_count = len(agent.audit_logs)
        
        message = AgentMessage(payload={
            "action": "audit",
            "agent_id": "AGT-01",
            "audit_action": "test"
        })
        await agent.process(message)
        
        assert len(agent.audit_logs) == initial_count + 1
    
    # === Export Check ===
    
    @pytest.mark.asyncio
    async def test_export_check(self, agent):
        message = AgentMessage(payload={
            "action": "export_check",
            "data": {"evidence_ids": ["E1", "E2", "E3"]}
        })
        result = await agent.process(message)
        
        assert result.success is True
        assert result.output.gate_id == "G-5"


class TestGateResult:
    """Tests for GateResult dataclass."""
    
    def test_to_dict(self):
        gate = GateResult(
            gate_id="G-0",
            gate_name="Input Gate",
            passed=True,
            overall_score=0.95,
            checks=[],
            duration_ms=50,
            blocking=True
        )
        d = gate.to_dict()
        assert d["gate_id"] == "G-0"
        assert d["passed"] is True


class TestCheckResult:
    """Tests for CheckResult dataclass."""
    
    def test_to_dict(self):
        check = CheckResult(
            check_id="G0-C1",
            check_name="morphological_completeness",
            passed=True,
            score=0.96,
            message="Passed",
            severity=CheckSeverity.INFO
        )
        d = check.to_dict()
        assert d["severity"] == "info"
