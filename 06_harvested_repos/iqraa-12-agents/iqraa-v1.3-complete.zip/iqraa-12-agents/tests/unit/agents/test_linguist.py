"""
Unit Tests for Linguist Agent
==============================
"""

import pytest
import asyncio
from unittest.mock import Mock, patch

from src.preprocessing.linguist import (
    LinguistAgent, LinguisticAnalysis, MorphologicalResult,
    NamedEntity, POSTag, EntityType, LINGUIST_CONFIG
)
from src.shared.base_agent import AgentMessage, AgentResult


class TestLinguistAgent:
    """Tests for LinguistAgent."""
    
    @pytest.fixture
    def agent(self):
        return LinguistAgent()
    
    @pytest.fixture
    def sample_message(self):
        return AgentMessage(
            message_id="test-001",
            run_id="run-001",
            from_agent="AGT-02-ORCHESTRATOR",
            to_agent="AGT-01-LINGUIST",
            payload={"text": "قال الإمام الشافعي رحمه الله في كتابه الأم"}
        )
    
    # === Input Validation Tests ===
    
    def test_validate_input_valid(self, agent):
        """Test valid Arabic input passes validation."""
        payload = {"text": "بسم الله الرحمن الرحيم"}
        is_valid, error = agent.validate_input(payload)
        assert is_valid is True
        assert error is None
    
    def test_validate_input_missing_text(self, agent):
        """Test missing text field fails validation."""
        payload = {}
        is_valid, error = agent.validate_input(payload)
        assert is_valid is False
        assert "Missing required field" in error
    
    def test_validate_input_empty_text(self, agent):
        """Test empty text fails validation."""
        payload = {"text": ""}
        is_valid, error = agent.validate_input(payload)
        assert is_valid is False
    
    def test_validate_input_no_arabic(self, agent):
        """Test non-Arabic text fails validation."""
        payload = {"text": "Hello World"}
        is_valid, error = agent.validate_input(payload)
        assert is_valid is False
        assert "Arabic" in error
    
    def test_validate_input_mixed_text(self, agent):
        """Test mixed Arabic/English passes validation."""
        payload = {"text": "The word الله means God"}
        is_valid, error = agent.validate_input(payload)
        assert is_valid is True
    
    # === Normalization Tests ===
    
    def test_normalize_removes_tatweel(self, agent):
        """Test tatweel removal."""
        text = "الـــكـــتـــاب"
        normalized = agent._normalize_arabic(text)
        assert "ـ" not in normalized
    
    def test_normalize_alef_variants(self, agent):
        """Test alef normalization."""
        text = "إسلام أمة آخرة"
        normalized = agent._normalize_arabic(text)
        assert "إ" not in normalized
        assert "أ" not in normalized
        assert "آ" not in normalized
    
    def test_normalize_removes_diacritics(self, agent):
        """Test diacritic removal."""
        text = "كِتَابٌ"
        normalized = agent._normalize_arabic(text)
        assert normalized == "كتاب"
    
    # === Processing Tests ===
    
    @pytest.mark.asyncio
    async def test_process_returns_analysis(self, agent, sample_message):
        """Test process returns LinguisticAnalysis."""
        result = await agent.process(sample_message)
        assert result.success is True
        assert isinstance(result.output, LinguisticAnalysis)
    
    @pytest.mark.asyncio
    async def test_process_extracts_tokens(self, agent, sample_message):
        """Test tokens are extracted."""
        result = await agent.process(sample_message)
        assert len(result.output.tokens) > 0
        assert all(isinstance(t, MorphologicalResult) for t in result.output.tokens)
    
    @pytest.mark.asyncio
    async def test_process_detects_entities(self, agent):
        """Test named entity detection."""
        message = AgentMessage(
            payload={"text": "قال الشيخ ابن تيمية في سورة البقرة"}
        )
        result = await agent.process(message)
        entities = result.output.entities
        
        # Should detect scholar and Quran reference
        entity_types = [e.entity_type for e in entities]
        assert any(t in [EntityType.SCHOLAR, EntityType.QURAN_REF] for t in entity_types)
    
    @pytest.mark.asyncio
    async def test_process_detects_classical_arabic(self, agent):
        """Test classical Arabic detection."""
        message = AgentMessage(
            payload={"text": "قال رحمه الله أما بعد فإن"}
        )
        result = await agent.process(message)
        assert result.output.language_detected == "ar-classic"
    
    @pytest.mark.asyncio
    async def test_process_confidence_score(self, agent, sample_message):
        """Test confidence score is calculated."""
        result = await agent.process(sample_message)
        assert 0 <= result.confidence <= 1
        assert result.output.confidence_overall == result.confidence
    
    # === Output Validation Tests ===
    
    def test_validate_output_valid(self, agent):
        """Test valid output passes validation."""
        analysis = LinguisticAnalysis(
            analysis_id="LING-TEST",
            original_text="test",
            normalized_text="test",
            diacritized_text="test",
            tokens=[MorphologicalResult(
                token="test", token_normalized="test",
                lemma="test", root="tst", pattern="فعل",
                pos=POSTag.NOUN, confidence=0.9
            )],
            entities=[],
            language_detected="ar",
            confidence_overall=0.8
        )
        result = AgentResult(success=True, output=analysis)
        is_valid, error = agent.validate_output(result)
        assert is_valid is True
    
    def test_validate_output_empty_tokens(self, agent):
        """Test empty tokens fails validation."""
        analysis = LinguisticAnalysis(
            analysis_id="LING-TEST",
            original_text="test",
            normalized_text="test",
            diacritized_text="test",
            tokens=[],
            entities=[],
            language_detected="ar",
            confidence_overall=0.8
        )
        result = AgentResult(success=True, output=analysis)
        is_valid, error = agent.validate_output(result)
        assert is_valid is False


class TestMorphologicalResult:
    """Tests for MorphologicalResult dataclass."""
    
    def test_to_dict(self):
        """Test serialization to dict."""
        result = MorphologicalResult(
            token="كتاب",
            token_normalized="كتاب",
            lemma="كتب",
            root="كتب",
            pattern="فِعَال",
            pos=POSTag.NOUN,
            features={"gender": "masculine"},
            confidence=0.95
        )
        d = result.to_dict()
        assert d["token"] == "كتاب"
        assert d["pos"] == "noun"
        assert d["confidence"] == 0.95


class TestNamedEntity:
    """Tests for NamedEntity dataclass."""
    
    def test_to_dict(self):
        """Test serialization to dict."""
        entity = NamedEntity(
            text="الإمام الشافعي",
            text_normalized="الامام الشافعي",
            entity_type=EntityType.SCHOLAR,
            start_idx=0,
            end_idx=14,
            confidence=0.9
        )
        d = entity.to_dict()
        assert d["entity_type"] == "scholar"
        assert d["confidence"] == 0.9
