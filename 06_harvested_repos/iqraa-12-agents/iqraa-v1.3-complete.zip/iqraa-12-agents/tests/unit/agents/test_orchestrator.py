"""
Unit Tests for Orchestrator Agent
==================================
"""

import pytest
import asyncio

from src.core.orchestrator import (
    OrchestratorAgent, ExecutionPlan, ExecutionStep,
    QueryType, PlaybookType, ORCHESTRATOR_CONFIG
)
from src.shared.base_agent import AgentMessage, AgentResult


class TestOrchestratorAgent:
    """Tests for OrchestratorAgent."""
    
    @pytest.fixture
    def agent(self):
        return OrchestratorAgent()
    
    # === Input Validation ===
    
    def test_validate_input_valid(self, agent):
        payload = {"query": "ما تعريف التوحيد؟"}
        is_valid, error = agent.validate_input(payload)
        assert is_valid is True
    
    def test_validate_input_missing_query(self, agent):
        payload = {}
        is_valid, error = agent.validate_input(payload)
        assert is_valid is False
        assert "query" in error.lower()
    
    def test_validate_input_empty_query(self, agent):
        payload = {"query": "  "}
        is_valid, error = agent.validate_input(payload)
        assert is_valid is False
    
    # === Query Classification ===
    
    def test_classify_evidence_query(self, agent):
        query = "ما دليل وجوب الصلاة؟"
        result = agent._classify_query(query)
        assert result == QueryType.EVIDENCE_LOOKUP
    
    def test_classify_concept_query(self, agent):
        query = "ما مفهوم الإيمان عند الأشاعرة؟"
        result = agent._classify_query(query)
        assert result == QueryType.CONCEPT_ANALYSIS
    
    def test_classify_genealogy_query(self, agent):
        query = "ما تاريخ تطور مصطلح العقيدة؟"
        result = agent._classify_query(query)
        assert result == QueryType.GENEALOGY_TRACE
    
    def test_classify_comparison_query(self, agent):
        query = "ما الفرق بين الحنفية والشافعية؟"
        result = agent._classify_query(query)
        assert result == QueryType.COMPARISON
    
    def test_classify_theory_query(self, agent):
        query = "كيف نبني نظرية حول المقاصد؟"
        result = agent._classify_query(query)
        assert result == QueryType.THEORY_BUILD
    
    def test_classify_unknown_defaults_to_exploration(self, agent):
        query = "حدثني عن شيء مثير"
        result = agent._classify_query(query)
        assert result == QueryType.EXPLORATION
    
    # === Playbook Selection ===
    
    def test_select_playbook_evidence(self, agent):
        playbook = agent._select_playbook(QueryType.EVIDENCE_LOOKUP)
        assert playbook == PlaybookType.PB_01_EVIDENCE
    
    def test_select_playbook_concept(self, agent):
        playbook = agent._select_playbook(QueryType.CONCEPT_ANALYSIS)
        assert playbook == PlaybookType.PB_02_CONCEPT
    
    def test_select_playbook_theory(self, agent):
        playbook = agent._select_playbook(QueryType.THEORY_BUILD)
        assert playbook == PlaybookType.PB_07_THEORY
    
    # === Plan Generation ===
    
    @pytest.mark.asyncio
    async def test_process_returns_plan(self, agent):
        message = AgentMessage(payload={"query": "ما تعريف الإيمان؟"})
        result = await agent.process(message)
        
        assert result.success is True
        assert isinstance(result.output, ExecutionPlan)
    
    @pytest.mark.asyncio
    async def test_plan_has_steps(self, agent):
        message = AgentMessage(payload={"query": "ما دليل التوحيد؟"})
        result = await agent.process(message)
        
        assert len(result.output.steps) > 0
        assert all(isinstance(s, ExecutionStep) for s in result.output.steps)
    
    @pytest.mark.asyncio
    async def test_plan_steps_have_dependencies(self, agent):
        message = AgentMessage(payload={"query": "بناء نظرية"})
        result = await agent.process(message)
        
        steps = result.output.steps
        # First step has no dependencies
        assert len(steps[0].dependencies) == 0
        # Subsequent steps depend on previous
        for i in range(1, len(steps)):
            assert len(steps[i].dependencies) > 0
    
    @pytest.mark.asyncio
    async def test_plan_includes_linguist_first(self, agent):
        message = AgentMessage(payload={"query": "أي استعلام"})
        result = await agent.process(message)
        
        first_step = result.output.steps[0]
        assert first_step.agent_id == "AGT-01-LINGUIST"
    
    @pytest.mark.asyncio
    async def test_plan_stored_in_active_plans(self, agent):
        message = AgentMessage(payload={"query": "test"})
        result = await agent.process(message)
        
        plan_id = result.output.plan_id
        assert plan_id in agent.active_plans


class TestExecutionPlan:
    """Tests for ExecutionPlan dataclass."""
    
    def test_to_dict(self):
        plan = ExecutionPlan(
            plan_id="PLAN-TEST",
            query_type=QueryType.CONCEPT_ANALYSIS,
            playbook=PlaybookType.PB_02_CONCEPT,
            steps=[],
            estimated_cost_usd=0.5,
            estimated_time_seconds=120
        )
        d = plan.to_dict()
        assert d["plan_id"] == "PLAN-TEST"
        assert d["query_type"] == "concept_analysis"
        assert d["playbook"] == "PB-02"


class TestExecutionStep:
    """Tests for ExecutionStep dataclass."""
    
    def test_to_dict(self):
        step = ExecutionStep(
            step_id="STEP-01",
            agent_id="AGT-01-LINGUIST",
            action="analyze_text",
            inputs={"text": "test"},
            dependencies=[],
            gate_after="G-0"
        )
        d = step.to_dict()
        assert d["agent_id"] == "AGT-01-LINGUIST"
        assert d["gate_after"] == "G-0"
