"""
Genealogist Agent (الجينيالوجي)
================================
Layer 3: Exploration
Concept historian for lineage tracking and influence mapping.

Responsibilities:
- Trace concept evolution over time
- Map scholarly influences
- Identify intellectual lineages
- Detect meaning shifts
"""

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any
from enum import Enum
from datetime import datetime
import logging
import uuid

from src.shared.base_agent import (
    BaseAgent, AgentConfig, AgentMessage, AgentResult, AutonomyLevel,
)

logger = logging.getLogger(__name__)


class InfluenceType(Enum):
    """Types of intellectual influence."""
    DIRECT = "direct"  # تأثير مباشر
    INDIRECT = "indirect"  # تأثير غير مباشر
    REACTION = "reaction"  # رد فعل
    SYNTHESIS = "synthesis"  # تركيب
    CRITIQUE = "critique"  # نقد


class EvolutionType(Enum):
    """Types of concept evolution."""
    EXPANSION = "expansion"  # توسع
    RESTRICTION = "restriction"  # تضييق
    TRANSFORMATION = "transformation"  # تحول
    PRESERVATION = "preservation"  # حفظ
    REVIVAL = "revival"  # إحياء


@dataclass
class HistoricalPeriod:
    """A historical period with Hijri/Gregorian dates."""
    period_id: str
    name_ar: str
    name_en: Optional[str] = None
    hijri_start: Optional[int] = None
    hijri_end: Optional[int] = None
    gregorian_start: Optional[int] = None
    gregorian_end: Optional[int] = None
    
    def to_dict(self) -> dict:
        return {
            "period_id": self.period_id, "name_ar": self.name_ar, "name_en": self.name_en,
            "hijri_start": self.hijri_start, "hijri_end": self.hijri_end,
            "gregorian_start": self.gregorian_start, "gregorian_end": self.gregorian_end,
        }


@dataclass
class LineageLink:
    """A link in the intellectual lineage."""
    link_id: str
    source_id: str  # Scholar or concept ID
    target_id: str
    influence_type: InfluenceType
    period: Optional[HistoricalPeriod] = None
    evidence_ids: List[str] = field(default_factory=list)
    strength: float = 0.5
    description_ar: Optional[str] = None
    
    def to_dict(self) -> dict:
        return {
            "link_id": self.link_id, "source_id": self.source_id, "target_id": self.target_id,
            "influence_type": self.influence_type.value,
            "period": self.period.to_dict() if self.period else None,
            "evidence_ids": self.evidence_ids, "strength": self.strength,
            "description_ar": self.description_ar,
        }


@dataclass
class ConceptEvolution:
    """Evolution of a concept over time."""
    evolution_id: str
    concept_id: str
    stages: List[Dict[str, Any]] = field(default_factory=list)
    total_span_years: int = 0
    evolution_type: EvolutionType = EvolutionType.PRESERVATION
    
    def to_dict(self) -> dict:
        return {
            "evolution_id": self.evolution_id, "concept_id": self.concept_id,
            "stages": self.stages, "total_span_years": self.total_span_years,
            "evolution_type": self.evolution_type.value,
        }


@dataclass
class LineageTree:
    """Complete lineage tree for a concept or scholar."""
    tree_id: str
    root_id: str
    root_type: str  # "concept" or "scholar"
    links: List[LineageLink] = field(default_factory=list)
    depth: int = 0
    node_count: int = 0
    
    def to_dict(self) -> dict:
        return {
            "tree_id": self.tree_id, "root_id": self.root_id, "root_type": self.root_type,
            "links": [l.to_dict() for l in self.links],
            "depth": self.depth, "node_count": self.node_count,
        }


GENEALOGIST_CONFIG = AgentConfig(
    agent_id="AGT-07-GENEALOGIST",
    arabic_name="الجينيالوجي",
    layer="Exploration (Layer 3)",
    autonomy_level=AutonomyLevel.L2_ADVISOR,
    llm_model="gemini-1.5-pro",
    temperature=0.5,
    timeout_seconds=120,
)


class GenealogistAgent(BaseAgent):
    """Intellectual genealogy and lineage tracking agent."""
    
    def __init__(self, config: AgentConfig = GENEALOGIST_CONFIG):
        super().__init__(config)
        
    def validate_input(self, payload: dict) -> tuple[bool, Optional[str]]:
        if "action" not in payload:
            return False, "Missing required field: action"
        action = payload.get("action")
        valid_actions = ["trace_lineage", "map_influences", "track_evolution", "find_connections"]
        if action not in valid_actions:
            return False, f"Invalid action: {action}"
        return True, None
    
    def validate_output(self, result: AgentResult) -> tuple[bool, Optional[str]]:
        return True, None
    
    async def process(self, message: AgentMessage) -> AgentResult:
        action = message.payload.get("action")
        
        if action == "trace_lineage":
            return await self._trace_lineage(message)
        elif action == "map_influences":
            return await self._map_influences(message)
        elif action == "track_evolution":
            return await self._track_evolution(message)
        elif action == "find_connections":
            return await self._find_connections(message)
        
        return AgentResult(success=False, error=f"Unknown action: {action}")
    
    async def _trace_lineage(self, message: AgentMessage) -> AgentResult:
        """Trace the lineage of a concept or scholar."""
        entity_id = message.payload.get("entity_id")
        entity_type = message.payload.get("entity_type", "concept")
        max_depth = message.payload.get("max_depth", 5)
        
        self.logger.info(f"Tracing lineage for {entity_type}: {entity_id}")
        
        # TODO: Query BigQuery for lineage links
        links = []
        
        # Placeholder: Create sample lineage
        for i in range(min(3, max_depth)):
            link = LineageLink(
                link_id=f"LINK-{uuid.uuid4().hex[:8].upper()}",
                source_id=entity_id if i == 0 else f"ENT-{uuid.uuid4().hex[:8].upper()}",
                target_id=f"ENT-{uuid.uuid4().hex[:8].upper()}",
                influence_type=InfluenceType.DIRECT,
                period=HistoricalPeriod(
                    period_id=f"PER-{i+1}",
                    name_ar=f"القرن {i+2} الهجري",
                    hijri_start=(i+1)*100,
                    hijri_end=(i+2)*100,
                ),
                strength=0.8 - (i * 0.1),
            )
            links.append(link)
        
        tree = LineageTree(
            tree_id=f"TREE-{uuid.uuid4().hex[:8].upper()}",
            root_id=entity_id,
            root_type=entity_type,
            links=links,
            depth=len(links),
            node_count=len(links) + 1,
        )
        
        return AgentResult(
            success=True, output=tree, confidence=0.75,
            metadata={"link_count": len(links), "depth": tree.depth},
        )
    
    async def _map_influences(self, message: AgentMessage) -> AgentResult:
        """Map scholarly influences on a concept."""
        concept_id = message.payload.get("concept_id")
        
        influences = []
        scholars = ["ابن تيمية", "الغزالي", "ابن رشد"]
        
        for i, scholar in enumerate(scholars):
            influences.append({
                "scholar_name": scholar,
                "influence_type": InfluenceType.DIRECT.value if i == 0 else InfluenceType.INDIRECT.value,
                "strength": 0.9 - (i * 0.15),
                "evidence_count": 3 - i,
            })
        
        return AgentResult(
            success=True, output={"concept_id": concept_id, "influences": influences},
            confidence=0.7,
        )
    
    async def _track_evolution(self, message: AgentMessage) -> AgentResult:
        """Track evolution of a concept over time."""
        concept_id = message.payload.get("concept_id")
        
        stages = [
            {"period": "القرن الأول", "meaning": "المعنى الأصلي", "evidence_count": 5},
            {"period": "القرن الثالث", "meaning": "توسع المعنى", "evidence_count": 8},
            {"period": "القرن السابع", "meaning": "استقرار المصطلح", "evidence_count": 12},
        ]
        
        evolution = ConceptEvolution(
            evolution_id=f"EVOL-{uuid.uuid4().hex[:8].upper()}",
            concept_id=concept_id,
            stages=stages,
            total_span_years=700,
            evolution_type=EvolutionType.EXPANSION,
        )
        
        return AgentResult(
            success=True, output=evolution, confidence=0.7,
        )
    
    async def _find_connections(self, message: AgentMessage) -> AgentResult:
        """Find connections between two entities."""
        source_id = message.payload.get("source_id")
        target_id = message.payload.get("target_id")
        
        # TODO: Implement path finding in lineage graph
        connections = {
            "source_id": source_id,
            "target_id": target_id,
            "path_exists": True,
            "path_length": 3,
            "intermediate_nodes": [],
        }
        
        return AgentResult(
            success=True, output=connections, confidence=0.6,
        )
