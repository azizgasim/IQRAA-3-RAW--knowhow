"""
BigQuery Table Definitions for IQRA v1.3
=========================================
21 tables across 2 datasets: ops_logs and kb_store
"""

# Dataset: iqra_ops_logs
# Operational logging and monitoring tables

RUN_LOG_SCHEMA = [
    {"name": "run_id", "type": "STRING", "mode": "REQUIRED", "description": "Unique run identifier"},
    {"name": "session_id", "type": "STRING", "mode": "REQUIRED"},
    {"name": "user_id", "type": "STRING", "mode": "NULLABLE"},
    {"name": "query_text", "type": "STRING", "mode": "REQUIRED"},
    {"name": "query_type", "type": "STRING", "mode": "REQUIRED"},
    {"name": "playbook_id", "type": "STRING", "mode": "REQUIRED"},
    {"name": "status", "type": "STRING", "mode": "REQUIRED"},  # pending/running/completed/failed
    {"name": "start_time", "type": "TIMESTAMP", "mode": "REQUIRED"},
    {"name": "end_time", "type": "TIMESTAMP", "mode": "NULLABLE"},
    {"name": "duration_ms", "type": "INTEGER", "mode": "NULLABLE"},
    {"name": "total_cost_usd", "type": "FLOAT", "mode": "NULLABLE"},
    {"name": "total_tokens", "type": "INTEGER", "mode": "NULLABLE"},
    {"name": "gates_passed", "type": "STRING", "mode": "REPEATED"},
    {"name": "gates_failed", "type": "STRING", "mode": "REPEATED"},
    {"name": "human_review_required", "type": "BOOLEAN", "mode": "NULLABLE"},
    {"name": "final_confidence", "type": "FLOAT", "mode": "NULLABLE"},
    {"name": "created_at", "type": "TIMESTAMP", "mode": "REQUIRED"},
]

AGENT_LOG_SCHEMA = [
    {"name": "log_id", "type": "STRING", "mode": "REQUIRED"},
    {"name": "run_id", "type": "STRING", "mode": "REQUIRED"},
    {"name": "agent_id", "type": "STRING", "mode": "REQUIRED"},
    {"name": "step_id", "type": "STRING", "mode": "NULLABLE"},
    {"name": "action", "type": "STRING", "mode": "REQUIRED"},
    {"name": "status", "type": "STRING", "mode": "REQUIRED"},
    {"name": "input_summary", "type": "STRING", "mode": "NULLABLE"},
    {"name": "output_summary", "type": "STRING", "mode": "NULLABLE"},
    {"name": "confidence", "type": "FLOAT", "mode": "NULLABLE"},
    {"name": "tokens_used", "type": "INTEGER", "mode": "NULLABLE"},
    {"name": "cost_usd", "type": "FLOAT", "mode": "NULLABLE"},
    {"name": "latency_ms", "type": "INTEGER", "mode": "NULLABLE"},
    {"name": "error_code", "type": "STRING", "mode": "NULLABLE"},
    {"name": "error_message", "type": "STRING", "mode": "NULLABLE"},
    {"name": "timestamp", "type": "TIMESTAMP", "mode": "REQUIRED"},
]

GATE_LOG_SCHEMA = [
    {"name": "log_id", "type": "STRING", "mode": "REQUIRED"},
    {"name": "run_id", "type": "STRING", "mode": "REQUIRED"},
    {"name": "gate_id", "type": "STRING", "mode": "REQUIRED"},
    {"name": "gate_name", "type": "STRING", "mode": "REQUIRED"},
    {"name": "passed", "type": "BOOLEAN", "mode": "REQUIRED"},
    {"name": "overall_score", "type": "FLOAT", "mode": "REQUIRED"},
    {"name": "check_results", "type": "JSON", "mode": "NULLABLE"},
    {"name": "blocking", "type": "BOOLEAN", "mode": "REQUIRED"},
    {"name": "reviewer_agent", "type": "STRING", "mode": "NULLABLE"},
    {"name": "duration_ms", "type": "INTEGER", "mode": "NULLABLE"},
    {"name": "timestamp", "type": "TIMESTAMP", "mode": "REQUIRED"},
]

ERROR_REGISTRY_SCHEMA = [
    {"name": "error_id", "type": "STRING", "mode": "REQUIRED"},
    {"name": "run_id", "type": "STRING", "mode": "NULLABLE"},
    {"name": "agent_id", "type": "STRING", "mode": "REQUIRED"},
    {"name": "error_category", "type": "STRING", "mode": "REQUIRED"},
    {"name": "error_code", "type": "STRING", "mode": "NULLABLE"},
    {"name": "error_message", "type": "STRING", "mode": "REQUIRED"},
    {"name": "stack_trace", "type": "STRING", "mode": "NULLABLE"},
    {"name": "context", "type": "JSON", "mode": "NULLABLE"},
    {"name": "severity", "type": "STRING", "mode": "REQUIRED"},
    {"name": "resolved", "type": "BOOLEAN", "mode": "REQUIRED"},
    {"name": "resolution_notes", "type": "STRING", "mode": "NULLABLE"},
    {"name": "pattern_id", "type": "STRING", "mode": "NULLABLE"},
    {"name": "created_at", "type": "TIMESTAMP", "mode": "REQUIRED"},
    {"name": "resolved_at", "type": "TIMESTAMP", "mode": "NULLABLE"},
]

ERROR_PATTERNS_SCHEMA = [
    {"name": "pattern_id", "type": "STRING", "mode": "REQUIRED"},
    {"name": "category", "type": "STRING", "mode": "REQUIRED"},
    {"name": "description_ar", "type": "STRING", "mode": "REQUIRED"},
    {"name": "description_en", "type": "STRING", "mode": "NULLABLE"},
    {"name": "affected_agents", "type": "STRING", "mode": "REPEATED"},
    {"name": "frequency", "type": "INTEGER", "mode": "REQUIRED"},
    {"name": "sample_error_ids", "type": "STRING", "mode": "REPEATED"},
    {"name": "root_cause_hypothesis", "type": "STRING", "mode": "NULLABLE"},
    {"name": "improvement_proposal_id", "type": "STRING", "mode": "NULLABLE"},
    {"name": "status", "type": "STRING", "mode": "REQUIRED"},
    {"name": "first_seen", "type": "TIMESTAMP", "mode": "REQUIRED"},
    {"name": "last_seen", "type": "TIMESTAMP", "mode": "REQUIRED"},
    {"name": "created_at", "type": "TIMESTAMP", "mode": "REQUIRED"},
]

HUMAN_REVIEW_QUEUE_SCHEMA = [
    {"name": "review_id", "type": "STRING", "mode": "REQUIRED"},
    {"name": "run_id", "type": "STRING", "mode": "REQUIRED"},
    {"name": "item_type", "type": "STRING", "mode": "REQUIRED"},  # theory/evidence/concept
    {"name": "item_id", "type": "STRING", "mode": "REQUIRED"},
    {"name": "review_level", "type": "STRING", "mode": "REQUIRED"},  # L1/L2/L3
    {"name": "reason", "type": "STRING", "mode": "REQUIRED"},
    {"name": "priority", "type": "INTEGER", "mode": "REQUIRED"},
    {"name": "status", "type": "STRING", "mode": "REQUIRED"},  # pending/in_review/approved/rejected
    {"name": "assigned_to", "type": "STRING", "mode": "NULLABLE"},
    {"name": "content_snapshot", "type": "JSON", "mode": "NULLABLE"},
    {"name": "reviewer_notes", "type": "STRING", "mode": "NULLABLE"},
    {"name": "decision", "type": "STRING", "mode": "NULLABLE"},
    {"name": "created_at", "type": "TIMESTAMP", "mode": "REQUIRED"},
    {"name": "reviewed_at", "type": "TIMESTAMP", "mode": "NULLABLE"},
]

PLAYBOOK_LOG_SCHEMA = [
    {"name": "log_id", "type": "STRING", "mode": "REQUIRED"},
    {"name": "run_id", "type": "STRING", "mode": "REQUIRED"},
    {"name": "playbook_id", "type": "STRING", "mode": "REQUIRED"},
    {"name": "playbook_version", "type": "STRING", "mode": "REQUIRED"},
    {"name": "steps_total", "type": "INTEGER", "mode": "REQUIRED"},
    {"name": "steps_completed", "type": "INTEGER", "mode": "REQUIRED"},
    {"name": "steps_failed", "type": "INTEGER", "mode": "REQUIRED"},
    {"name": "execution_path", "type": "JSON", "mode": "NULLABLE"},
    {"name": "created_at", "type": "TIMESTAMP", "mode": "REQUIRED"},
]

COST_LOG_SCHEMA = [
    {"name": "log_id", "type": "STRING", "mode": "REQUIRED"},
    {"name": "run_id", "type": "STRING", "mode": "REQUIRED"},
    {"name": "agent_id", "type": "STRING", "mode": "REQUIRED"},
    {"name": "model", "type": "STRING", "mode": "REQUIRED"},
    {"name": "input_tokens", "type": "INTEGER", "mode": "REQUIRED"},
    {"name": "output_tokens", "type": "INTEGER", "mode": "REQUIRED"},
    {"name": "cost_usd", "type": "FLOAT", "mode": "REQUIRED"},
    {"name": "timestamp", "type": "TIMESTAMP", "mode": "REQUIRED"},
]

# Dataset: iqra_kb_store
# Knowledge base tables

WORKS_SCHEMA = [
    {"name": "work_id", "type": "STRING", "mode": "REQUIRED"},
    {"name": "title_ar", "type": "STRING", "mode": "REQUIRED"},
    {"name": "title_en", "type": "STRING", "mode": "NULLABLE"},
    {"name": "author_ids", "type": "STRING", "mode": "REPEATED"},
    {"name": "creation_hijri_start", "type": "INTEGER", "mode": "NULLABLE"},
    {"name": "creation_hijri_end", "type": "INTEGER", "mode": "NULLABLE"},
    {"name": "creation_gregorian_start", "type": "INTEGER", "mode": "NULLABLE"},
    {"name": "creation_gregorian_end", "type": "INTEGER", "mode": "NULLABLE"},
    {"name": "subject_tags", "type": "STRING", "mode": "REPEATED"},
    {"name": "work_type", "type": "STRING", "mode": "REQUIRED"},
    {"name": "language", "type": "STRING", "mode": "REQUIRED"},
    {"name": "description_ar", "type": "STRING", "mode": "NULLABLE"},
    {"name": "created_at", "type": "TIMESTAMP", "mode": "REQUIRED"},
    {"name": "updated_at", "type": "TIMESTAMP", "mode": "REQUIRED"},
]

EXPRESSIONS_SCHEMA = [
    {"name": "expression_id", "type": "STRING", "mode": "REQUIRED"},
    {"name": "work_id", "type": "STRING", "mode": "REQUIRED"},
    {"name": "language", "type": "STRING", "mode": "REQUIRED"},
    {"name": "expression_type", "type": "STRING", "mode": "REQUIRED"},
    {"name": "translator_ids", "type": "STRING", "mode": "REPEATED"},
    {"name": "expression_date", "type": "STRING", "mode": "NULLABLE"},
    {"name": "notes", "type": "STRING", "mode": "NULLABLE"},
    {"name": "created_at", "type": "TIMESTAMP", "mode": "REQUIRED"},
]

MANIFESTATIONS_SCHEMA = [
    {"name": "manifestation_id", "type": "STRING", "mode": "REQUIRED"},
    {"name": "expression_id", "type": "STRING", "mode": "REQUIRED"},
    {"name": "publisher", "type": "STRING", "mode": "NULLABLE"},
    {"name": "publication_place", "type": "STRING", "mode": "NULLABLE"},
    {"name": "publication_year", "type": "INTEGER", "mode": "NULLABLE"},
    {"name": "edition", "type": "STRING", "mode": "NULLABLE"},
    {"name": "editor_ids", "type": "STRING", "mode": "REPEATED"},
    {"name": "isbn", "type": "STRING", "mode": "NULLABLE"},
    {"name": "total_volumes", "type": "INTEGER", "mode": "NULLABLE"},
    {"name": "total_pages", "type": "INTEGER", "mode": "NULLABLE"},
    {"name": "format", "type": "STRING", "mode": "REQUIRED"},
    {"name": "created_at", "type": "TIMESTAMP", "mode": "REQUIRED"},
]

ITEMS_SCHEMA = [
    {"name": "item_id", "type": "STRING", "mode": "REQUIRED"},
    {"name": "manifestation_id", "type": "STRING", "mode": "REQUIRED"},
    {"name": "library", "type": "STRING", "mode": "NULLABLE"},
    {"name": "collection", "type": "STRING", "mode": "NULLABLE"},
    {"name": "call_number", "type": "STRING", "mode": "NULLABLE"},
    {"name": "digital_url", "type": "STRING", "mode": "NULLABLE"},
    {"name": "access_type", "type": "STRING", "mode": "REQUIRED"},
    {"name": "digitized", "type": "BOOLEAN", "mode": "REQUIRED"},
    {"name": "condition", "type": "STRING", "mode": "NULLABLE"},
    {"name": "verified_date", "type": "DATE", "mode": "NULLABLE"},
    {"name": "created_at", "type": "TIMESTAMP", "mode": "REQUIRED"},
]

EVIDENCE_UNITS_SCHEMA = [
    {"name": "evidence_id", "type": "STRING", "mode": "REQUIRED"},
    {"name": "work_id", "type": "STRING", "mode": "REQUIRED"},
    {"name": "expression_id", "type": "STRING", "mode": "NULLABLE"},
    {"name": "manifestation_id", "type": "STRING", "mode": "NULLABLE"},
    {"name": "item_id", "type": "STRING", "mode": "NULLABLE"},
    {"name": "volume", "type": "INTEGER", "mode": "NULLABLE"},
    {"name": "page_start", "type": "INTEGER", "mode": "NULLABLE"},
    {"name": "page_end", "type": "INTEGER", "mode": "NULLABLE"},
    {"name": "line_start", "type": "INTEGER", "mode": "NULLABLE"},
    {"name": "line_end", "type": "INTEGER", "mode": "NULLABLE"},
    {"name": "quote_ar", "type": "STRING", "mode": "REQUIRED"},
    {"name": "quote_normalized", "type": "STRING", "mode": "REQUIRED"},
    {"name": "context_before", "type": "STRING", "mode": "NULLABLE"},
    {"name": "context_after", "type": "STRING", "mode": "NULLABLE"},
    {"name": "source_type", "type": "STRING", "mode": "REQUIRED"},
    {"name": "verification_status", "type": "STRING", "mode": "REQUIRED"},
    {"name": "linguistic_analysis_id", "type": "STRING", "mode": "NULLABLE"},
    {"name": "confidence", "type": "FLOAT", "mode": "REQUIRED"},
    {"name": "created_by", "type": "STRING", "mode": "REQUIRED"},
    {"name": "created_at", "type": "TIMESTAMP", "mode": "REQUIRED"},
    {"name": "updated_at", "type": "TIMESTAMP", "mode": "REQUIRED"},
]

CONCEPT_CARDS_SCHEMA = [
    {"name": "concept_id", "type": "STRING", "mode": "REQUIRED"},
    {"name": "term_ar", "type": "STRING", "mode": "REQUIRED"},
    {"name": "term_normalized", "type": "STRING", "mode": "REQUIRED"},
    {"name": "term_en", "type": "STRING", "mode": "NULLABLE"},
    {"name": "root_ar", "type": "STRING", "mode": "NULLABLE"},
    {"name": "morphological_pattern", "type": "STRING", "mode": "NULLABLE"},
    {"name": "definitions", "type": "JSON", "mode": "REQUIRED"},
    {"name": "semantic_field", "type": "STRING", "mode": "REPEATED"},
    {"name": "related_concepts", "type": "JSON", "mode": "NULLABLE"},
    {"name": "usage_contexts", "type": "STRING", "mode": "REPEATED"},
    {"name": "historical_evolution", "type": "JSON", "mode": "NULLABLE"},
    {"name": "confidence", "type": "FLOAT", "mode": "REQUIRED"},
    {"name": "status", "type": "STRING", "mode": "REQUIRED"},
    {"name": "created_by", "type": "STRING", "mode": "REQUIRED"},
    {"name": "created_at", "type": "TIMESTAMP", "mode": "REQUIRED"},
    {"name": "updated_at", "type": "TIMESTAMP", "mode": "REQUIRED"},
    {"name": "version", "type": "INTEGER", "mode": "REQUIRED"},
]

THEORY_CARDS_SCHEMA = [
    {"name": "theory_id", "type": "STRING", "mode": "REQUIRED"},
    {"name": "title_ar", "type": "STRING", "mode": "REQUIRED"},
    {"name": "title_en", "type": "STRING", "mode": "NULLABLE"},
    {"name": "abstract_ar", "type": "STRING", "mode": "NULLABLE"},
    {"name": "hypothesis", "type": "JSON", "mode": "REQUIRED"},
    {"name": "evidence_ids", "type": "STRING", "mode": "REPEATED"},
    {"name": "concept_ids", "type": "STRING", "mode": "REPEATED"},
    {"name": "supporting_arguments", "type": "JSON", "mode": "NULLABLE"},
    {"name": "counter_arguments", "type": "JSON", "mode": "NULLABLE"},
    {"name": "methodology", "type": "JSON", "mode": "NULLABLE"},
    {"name": "implications", "type": "JSON", "mode": "NULLABLE"},
    {"name": "related_theories", "type": "JSON", "mode": "NULLABLE"},
    {"name": "confidence", "type": "FLOAT", "mode": "REQUIRED"},
    {"name": "status", "type": "STRING", "mode": "REQUIRED"},
    {"name": "peer_reviews", "type": "JSON", "mode": "NULLABLE"},
    {"name": "created_by", "type": "STRING", "mode": "REQUIRED"},
    {"name": "created_at", "type": "TIMESTAMP", "mode": "REQUIRED"},
    {"name": "updated_at", "type": "TIMESTAMP", "mode": "REQUIRED"},
    {"name": "version", "type": "INTEGER", "mode": "REQUIRED"},
]

LINEAGE_LINKS_SCHEMA = [
    {"name": "link_id", "type": "STRING", "mode": "REQUIRED"},
    {"name": "source_id", "type": "STRING", "mode": "REQUIRED"},
    {"name": "source_type", "type": "STRING", "mode": "REQUIRED"},
    {"name": "target_id", "type": "STRING", "mode": "REQUIRED"},
    {"name": "target_type", "type": "STRING", "mode": "REQUIRED"},
    {"name": "influence_type", "type": "STRING", "mode": "REQUIRED"},
    {"name": "strength", "type": "FLOAT", "mode": "REQUIRED"},
    {"name": "period_id", "type": "STRING", "mode": "NULLABLE"},
    {"name": "evidence_ids", "type": "STRING", "mode": "REPEATED"},
    {"name": "description_ar", "type": "STRING", "mode": "NULLABLE"},
    {"name": "created_at", "type": "TIMESTAMP", "mode": "REQUIRED"},
]

SCHOLARS_SCHEMA = [
    {"name": "scholar_id", "type": "STRING", "mode": "REQUIRED"},
    {"name": "name_ar", "type": "STRING", "mode": "REQUIRED"},
    {"name": "name_en", "type": "STRING", "mode": "NULLABLE"},
    {"name": "birth_hijri", "type": "INTEGER", "mode": "NULLABLE"},
    {"name": "death_hijri", "type": "INTEGER", "mode": "NULLABLE"},
    {"name": "birth_gregorian", "type": "INTEGER", "mode": "NULLABLE"},
    {"name": "death_gregorian", "type": "INTEGER", "mode": "NULLABLE"},
    {"name": "school_of_thought", "type": "STRING", "mode": "NULLABLE"},
    {"name": "specializations", "type": "STRING", "mode": "REPEATED"},
    {"name": "teacher_ids", "type": "STRING", "mode": "REPEATED"},
    {"name": "student_ids", "type": "STRING", "mode": "REPEATED"},
    {"name": "work_ids", "type": "STRING", "mode": "REPEATED"},
    {"name": "biography_ar", "type": "STRING", "mode": "NULLABLE"},
    {"name": "wikidata_id", "type": "STRING", "mode": "NULLABLE"},
    {"name": "created_at", "type": "TIMESTAMP", "mode": "REQUIRED"},
    {"name": "updated_at", "type": "TIMESTAMP", "mode": "REQUIRED"},
]

SEMANTIC_INDEX_SCHEMA = [
    {"name": "chunk_id", "type": "STRING", "mode": "REQUIRED"},
    {"name": "source_id", "type": "STRING", "mode": "REQUIRED"},
    {"name": "source_type", "type": "STRING", "mode": "REQUIRED"},
    {"name": "chunk_type", "type": "STRING", "mode": "REQUIRED"},
    {"name": "text", "type": "STRING", "mode": "REQUIRED"},
    {"name": "text_normalized", "type": "STRING", "mode": "REQUIRED"},
    {"name": "embedding", "type": "FLOAT64", "mode": "REPEATED"},
    {"name": "position", "type": "INTEGER", "mode": "REQUIRED"},
    {"name": "metadata", "type": "JSON", "mode": "NULLABLE"},
    {"name": "created_at", "type": "TIMESTAMP", "mode": "REQUIRED"},
]

# All schemas registry
ALL_SCHEMAS = {
    # ops_logs dataset
    "run_log": RUN_LOG_SCHEMA,
    "agent_log": AGENT_LOG_SCHEMA,
    "gate_log": GATE_LOG_SCHEMA,
    "error_registry": ERROR_REGISTRY_SCHEMA,
    "error_patterns": ERROR_PATTERNS_SCHEMA,
    "human_review_queue": HUMAN_REVIEW_QUEUE_SCHEMA,
    "playbook_log": PLAYBOOK_LOG_SCHEMA,
    "cost_log": COST_LOG_SCHEMA,
    # kb_store dataset
    "works": WORKS_SCHEMA,
    "expressions": EXPRESSIONS_SCHEMA,
    "manifestations": MANIFESTATIONS_SCHEMA,
    "items": ITEMS_SCHEMA,
    "evidence_units": EVIDENCE_UNITS_SCHEMA,
    "concept_cards": CONCEPT_CARDS_SCHEMA,
    "theory_cards": THEORY_CARDS_SCHEMA,
    "lineage_links": LINEAGE_LINKS_SCHEMA,
    "scholars": SCHOLARS_SCHEMA,
    "semantic_index": SEMANTIC_INDEX_SCHEMA,
}
