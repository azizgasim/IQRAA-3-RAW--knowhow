"""
Linguist Agent (اللغوي)
========================
Layer 0: Pre-processing
Arabic NLP specialist for morphological analysis, syntax, NER, and diacritization.
"""

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any
from enum import Enum
import logging
import re
import uuid

from src.shared.base_agent import (
    BaseAgent, AgentConfig, AgentMessage, AgentResult, AutonomyLevel,
)

logger = logging.getLogger(__name__)


class POSTag(Enum):
    """Arabic Part-of-Speech tags."""
    NOUN = "noun"
    VERB = "verb"
    PARTICLE = "particle"
    ADJECTIVE = "adj"
    ADVERB = "adv"
    PRONOUN = "pron"
    PREPOSITION = "prep"
    CONJUNCTION = "conj"
    PUNCTUATION = "punct"
    NUMBER = "num"
    UNKNOWN = "unk"


class EntityType(Enum):
    """Named Entity types for Islamic texts."""
    PERSON = "person"
    SCHOLAR = "scholar"
    PROPHET = "prophet"
    COMPANION = "companion"
    LOCATION = "location"
    BOOK = "book"
    CONCEPT = "concept"
    SCHOOL = "school"
    EVENT = "event"
    DATE_HIJRI = "date_hijri"
    QURAN_REF = "quran_ref"
    HADITH_REF = "hadith_ref"


@dataclass
class MorphologicalResult:
    """Result of morphological analysis for a single token."""
    token: str
    token_normalized: str
    lemma: str
    root: str
    pattern: str
    pos: POSTag
    features: Dict[str, str] = field(default_factory=dict)
    confidence: float = 1.0
    
    def to_dict(self) -> dict:
        return {
            "token": self.token, "token_normalized": self.token_normalized,
            "lemma": self.lemma, "root": self.root, "pattern": self.pattern,
            "pos": self.pos.value, "features": self.features, "confidence": self.confidence,
        }


@dataclass
class NamedEntity:
    """A recognized named entity."""
    text: str
    text_normalized: str
    entity_type: EntityType
    start_idx: int
    end_idx: int
    wikidata_id: Optional[str] = None
    confidence: float = 1.0
    
    def to_dict(self) -> dict:
        return {
            "text": self.text, "text_normalized": self.text_normalized,
            "entity_type": self.entity_type.value, "start_idx": self.start_idx,
            "end_idx": self.end_idx, "wikidata_id": self.wikidata_id, "confidence": self.confidence,
        }


@dataclass
class LinguisticAnalysis:
    """Complete linguistic analysis result."""
    analysis_id: str
    original_text: str
    normalized_text: str
    diacritized_text: str
    tokens: List[MorphologicalResult]
    entities: List[NamedEntity]
    language_detected: str
    confidence_overall: float
    
    def to_dict(self) -> dict:
        return {
            "analysis_id": self.analysis_id, "original_text": self.original_text,
            "normalized_text": self.normalized_text, "diacritized_text": self.diacritized_text,
            "tokens": [t.to_dict() for t in self.tokens],
            "entities": [e.to_dict() for e in self.entities],
            "language_detected": self.language_detected, "confidence_overall": self.confidence_overall,
        }


LINGUIST_CONFIG = AgentConfig(
    agent_id="AGT-01-LINGUIST",
    arabic_name="اللغوي",
    layer="Pre-processing (Layer 0)",
    autonomy_level=AutonomyLevel.L2_ADVISOR,
    llm_model="gemini-1.5-pro",
    temperature=0.1,
    timeout_seconds=60,
)


class LinguistAgent(BaseAgent):
    """Arabic NLP preprocessing agent."""
    
    def __init__(self, config: AgentConfig = LINGUIST_CONFIG):
        super().__init__(config)
        
    def validate_input(self, payload: dict) -> tuple[bool, Optional[str]]:
        if "text" not in payload:
            return False, "Missing required field: text"
        text = payload.get("text", "")
        if not isinstance(text, str) or len(text.strip()) == 0:
            return False, "Text must be a non-empty string"
        arabic_pattern = re.compile(r'[\u0600-\u06FF]+')
        if not arabic_pattern.search(text):
            return False, "Text must contain Arabic characters"
        return True, None
    
    def validate_output(self, result: AgentResult) -> tuple[bool, Optional[str]]:
        if not result.success:
            return True, None
        if not isinstance(result.output, LinguisticAnalysis):
            return False, "Output must be LinguisticAnalysis"
        if len(result.output.tokens) == 0:
            return False, "Analysis must have at least one token"
        return True, None
    
    async def process(self, message: AgentMessage) -> AgentResult:
        text = message.payload.get("text", "")
        self.logger.info(f"Processing text: {text[:100]}...")
        
        normalized = self._normalize_arabic(text)
        tokens = self._morphological_analysis(normalized)
        entities = self._extract_entities(normalized)
        diacritized = normalized  # TODO: Implement diacritization
        lang = "ar-classic" if any(m in text for m in ['قال', 'رحمه الله']) else "ar"
        confidence = sum(t.confidence for t in tokens) / len(tokens) if tokens else 0.5
        
        analysis = LinguisticAnalysis(
            analysis_id=f"LING-{uuid.uuid4().hex[:12].upper()}",
            original_text=text, normalized_text=normalized,
            diacritized_text=diacritized, tokens=tokens,
            entities=entities, language_detected=lang, confidence_overall=confidence,
        )
        
        return AgentResult(success=True, output=analysis, confidence=confidence,
            metadata={"token_count": len(tokens), "entity_count": len(entities)})
    
    def _normalize_arabic(self, text: str) -> str:
        text = re.sub(r'\u0640', '', text)  # Remove tatweel
        text = re.sub(r'[إأآا]', 'ا', text)  # Normalize alef
        text = re.sub(r'ى', 'ي', text)  # Normalize alef maksura
        text = re.sub(r'ة', 'ه', text)  # Normalize taa marbuta
        text = re.sub(r'[\u064B-\u065F\u0670]', '', text)  # Remove diacritics
        return re.sub(r'\s+', ' ', text).strip()
    
    def _morphological_analysis(self, text: str) -> List[MorphologicalResult]:
        tokens = text.split()
        results = []
        for token in tokens:
            root = re.sub(r'[اويى]', '', token)[:3]
            pos = POSTag.PREPOSITION if token in ['في', 'من', 'إلى', 'على'] else POSTag.NOUN
            results.append(MorphologicalResult(
                token=token, token_normalized=token, lemma=token,
                root=root, pattern="فعل", pos=pos, confidence=0.8
            ))
        return results
    
    def _extract_entities(self, text: str) -> List[NamedEntity]:
        entities = []
        patterns = [
            (r'سورة\s+(\w+)', EntityType.QURAN_REF),
            (r'الشيخ\s+(\w+)', EntityType.SCHOLAR),
            (r'الإمام\s+(\w+)', EntityType.SCHOLAR),
        ]
        for pattern, etype in patterns:
            for match in re.finditer(pattern, text):
                entities.append(NamedEntity(
                    text=match.group(0), text_normalized=match.group(0),
                    entity_type=etype, start_idx=match.start(), end_idx=match.end(), confidence=0.8
                ))
        return entities
