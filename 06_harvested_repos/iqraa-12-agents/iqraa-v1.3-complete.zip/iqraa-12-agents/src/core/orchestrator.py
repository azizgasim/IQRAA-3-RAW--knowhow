"""
Orchestrator Agent (المنسق)
============================
Layer 1: Governance
Central coordinator for all IQRA agents.

Responsibilities:
- Query classification and routing
- Task decomposition and planning
- Agent coordination
- State management
- Gate enforcement
- Memory lifecycle management
"""

from dataclasses import dataclass, field
from typing import Any, Optional, List, Dict
from enum import Enum
import logging
import uuid

from src.shared.base_agent import (
    BaseAgent, AgentConfig, AgentMessage, AgentResult, AutonomyLevel,
)

logger = logging.getLogger(__name__)


class QueryType(Enum):
    """Types of queries IQRA can handle."""
    EVIDENCE_LOOKUP = "evidence_lookup"
    CONCEPT_ANALYSIS = "concept_analysis"
    GENEALOGY_TRACE = "genealogy_trace"
    COMPARISON = "comparison"
    THEORY_BUILD = "theory_build"
    METHOD_PURIFY = "method_purify"
    EXPLORATION = "exploration"
    UNKNOWN = "unknown"


class PlaybookType(Enum):
    """Available playbooks for task execution."""
    PB_01_EVIDENCE = "PB-01"
    PB_02_CONCEPT = "PB-02"
    PB_03_GENEALOGY = "PB-03"
    PB_04_COMPARISON = "PB-04"
    PB_05_FALSIFICATION = "PB-05"
    PB_06_PURIFICATION = "PB-06"
    PB_07_THEORY = "PB-07"
    PB_08_SPARK = "PB-08"
    PB_09_CONTEXT = "PB-09"
    PB_10_EXPORT = "PB-10"
    PB_11_MEMORY = "PB-11"
    PB_12_IMPROVEMENT = "PB-12"


@dataclass
class ExecutionStep:
    """A single step in the execution plan."""
    step_id: str
    agent_id: str
    action: str
    inputs: Dict[str, Any] = field(default_factory=dict)
    dependencies: List[str] = field(default_factory=list)
    gate_after: Optional[str] = None
    timeout_seconds: int = 60
    
    def to_dict(self) -> dict:
        return {
            "step_id": self.step_id, "agent_id": self.agent_id,
            "action": self.action, "inputs": self.inputs,
            "dependencies": self.dependencies, "gate_after": self.gate_after,
            "timeout_seconds": self.timeout_seconds,
        }


@dataclass
class ExecutionPlan:
    """Complete plan for executing a query."""
    plan_id: str
    query_type: QueryType
    playbook: PlaybookType
    steps: List[ExecutionStep] = field(default_factory=list)
    estimated_cost_usd: float = 0.0
    estimated_time_seconds: int = 0
    
    def to_dict(self) -> dict:
        return {
            "plan_id": self.plan_id, "query_type": self.query_type.value,
            "playbook": self.playbook.value, "steps": [s.to_dict() for s in self.steps],
            "estimated_cost_usd": self.estimated_cost_usd,
            "estimated_time_seconds": self.estimated_time_seconds,
        }


# Playbook definitions
PLAYBOOK_TEMPLATES = {
    PlaybookType.PB_01_EVIDENCE: {
        "name": "Evidence Retrieval",
        "agents": ["AGT-01-LINGUIST", "AGT-05-EVIDENCER", "AGT-03-GUARDIAN"],
        "gates": ["G-0", "G-1", "G-5"],
    },
    PlaybookType.PB_02_CONCEPT: {
        "name": "Concept Analysis",
        "agents": ["AGT-01-LINGUIST", "AGT-05-EVIDENCER", "AGT-06-ANALYST", "AGT-03-GUARDIAN"],
        "gates": ["G-0", "G-1", "G-2", "G-5"],
    },
    PlaybookType.PB_03_GENEALOGY: {
        "name": "Genealogy Trace",
        "agents": ["AGT-01-LINGUIST", "AGT-05-EVIDENCER", "AGT-07-GENEALOGIST", "AGT-03-GUARDIAN"],
        "gates": ["G-0", "G-1", "G-3", "G-5"],
    },
    PlaybookType.PB_07_THEORY: {
        "name": "Theory Building",
        "agents": ["AGT-01-LINGUIST", "AGT-05-EVIDENCER", "AGT-06-ANALYST", 
                   "AGT-09-THEORIST", "AGT-10-PURIFIER", "AGT-03-GUARDIAN"],
        "gates": ["G-0", "G-1", "G-2", "G-4", "G-5"],
    },
}


ORCHESTRATOR_CONFIG = AgentConfig(
    agent_id="AGT-02-ORCHESTRATOR",
    arabic_name="المنسق",
    layer="Governance (Layer 1)",
    autonomy_level=AutonomyLevel.L3_DECIDER,
    llm_model="gemini-1.5-pro",
    temperature=0.3,
    timeout_seconds=30,
)


class OrchestratorAgent(BaseAgent):
    """The Orchestrator coordinates all other agents."""
    
    def __init__(self, config: AgentConfig = ORCHESTRATOR_CONFIG):
        super().__init__(config)
        self.active_plans: Dict[str, ExecutionPlan] = {}
        
    def validate_input(self, payload: dict) -> tuple[bool, Optional[str]]:
        if "query" not in payload:
            return False, "Missing required field: query"
        if not isinstance(payload["query"], str) or len(payload["query"].strip()) == 0:
            return False, "Query must be a non-empty string"
        return True, None
    
    def validate_output(self, result: AgentResult) -> tuple[bool, Optional[str]]:
        if not result.success:
            return True, None
        if not isinstance(result.output, ExecutionPlan):
            return False, "Output must be an ExecutionPlan"
        if len(result.output.steps) == 0:
            return False, "ExecutionPlan must have at least one step"
        return True, None
    
    async def process(self, message: AgentMessage) -> AgentResult:
        query = message.payload.get("query", "")
        context = message.payload.get("context", {})
        
        self.logger.info(f"Processing query: {query[:100]}...")
        
        # Step 1: Classify query
        query_type = self._classify_query(query)
        self.logger.info(f"Query classified as: {query_type.value}")
        
        # Step 2: Select playbook
        playbook = self._select_playbook(query_type)
        self.logger.info(f"Selected playbook: {playbook.value}")
        
        # Step 3: Generate execution plan
        plan = self._generate_plan(query, query_type, playbook, message.run_id)
        
        # Step 4: Store plan
        self.active_plans[plan.plan_id] = plan
        
        return AgentResult(
            success=True, output=plan, confidence=0.85,
            metadata={"query_type": query_type.value, "playbook": playbook.value, "step_count": len(plan.steps)}
        )
    
    def _classify_query(self, query: str) -> QueryType:
        query_lower = query.lower()
        
        keywords_map = {
            QueryType.EVIDENCE_LOOKUP: ["دليل", "evidence", "cite", "مصدر", "برهان", "حجة"],
            QueryType.CONCEPT_ANALYSIS: ["مفهوم", "concept", "تعريف", "define", "معنى"],
            QueryType.GENEALOGY_TRACE: ["تاريخ", "genealogy", "أصل", "تطور", "نشأة"],
            QueryType.COMPARISON: ["مقارنة", "compare", "فرق", "difference", "بين"],
            QueryType.THEORY_BUILD: ["نظرية", "theory", "بناء", "construct", "تأسيس"],
            QueryType.METHOD_PURIFY: ["منهج", "method", "تطهير", "purify", "نقد"],
        }
        
        for qtype, keywords in keywords_map.items():
            if any(kw in query_lower for kw in keywords):
                return qtype
        return QueryType.EXPLORATION
    
    def _select_playbook(self, query_type: QueryType) -> PlaybookType:
        mapping = {
            QueryType.EVIDENCE_LOOKUP: PlaybookType.PB_01_EVIDENCE,
            QueryType.CONCEPT_ANALYSIS: PlaybookType.PB_02_CONCEPT,
            QueryType.GENEALOGY_TRACE: PlaybookType.PB_03_GENEALOGY,
            QueryType.COMPARISON: PlaybookType.PB_04_COMPARISON,
            QueryType.THEORY_BUILD: PlaybookType.PB_07_THEORY,
            QueryType.METHOD_PURIFY: PlaybookType.PB_06_PURIFICATION,
            QueryType.EXPLORATION: PlaybookType.PB_08_SPARK,
            QueryType.UNKNOWN: PlaybookType.PB_02_CONCEPT,
        }
        return mapping.get(query_type, PlaybookType.PB_02_CONCEPT)
    
    def _generate_plan(self, query: str, query_type: QueryType, 
                       playbook: PlaybookType, run_id: str) -> ExecutionPlan:
        plan_id = f"PLAN-{uuid.uuid4().hex[:8].upper()}"
        template = PLAYBOOK_TEMPLATES.get(playbook, PLAYBOOK_TEMPLATES[PlaybookType.PB_02_CONCEPT])
        
        steps = []
        prev_step_id = None
        
        for i, agent_id in enumerate(template["agents"]):
            step_id = f"{plan_id}-S{i+1}"
            gate = template["gates"][i] if i < len(template["gates"]) else None
            
            step = ExecutionStep(
                step_id=step_id,
                agent_id=agent_id,
                action=self._get_agent_action(agent_id),
                inputs={"query": query} if i == 0 else {},
                dependencies=[prev_step_id] if prev_step_id else [],
                gate_after=gate,
                timeout_seconds=60,
            )
            steps.append(step)
            prev_step_id = step_id
        
        return ExecutionPlan(
            plan_id=plan_id, query_type=query_type, playbook=playbook,
            steps=steps, estimated_cost_usd=len(steps) * 0.15,
            estimated_time_seconds=sum(s.timeout_seconds for s in steps),
        )
    
    def _get_agent_action(self, agent_id: str) -> str:
        actions = {
            "AGT-01-LINGUIST": "analyze_text",
            "AGT-02-ORCHESTRATOR": "coordinate",
            "AGT-03-GUARDIAN": "audit",
            "AGT-04-ARCHIVIST": "retrieve",
            "AGT-05-EVIDENCER": "collect_evidence",
            "AGT-06-ANALYST": "analyze_concept",
            "AGT-07-GENEALOGIST": "trace_lineage",
            "AGT-08-SCOUT": "detect_patterns",
            "AGT-09-THEORIST": "build_theory",
            "AGT-10-PURIFIER": "purify_method",
            "AGT-11-IMPROVER": "improve_system",
        }
        return actions.get(agent_id, "process")
