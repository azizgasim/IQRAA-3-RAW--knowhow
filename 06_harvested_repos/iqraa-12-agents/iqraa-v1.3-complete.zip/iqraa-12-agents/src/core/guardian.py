"""
Guardian Agent (الحارس)
========================
Layer 1: Governance
Quality guardian for gate enforcement, audit logging, and export control.

Responsibilities:
- Gate evaluation and enforcement
- Quality auditing
- Bias detection
- Export control
- Compliance checking
"""

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any
from enum import Enum
from datetime import datetime
import logging
import uuid

from src.shared.base_agent import (
    BaseAgent, AgentConfig, AgentMessage, AgentResult, AutonomyLevel,
)

logger = logging.getLogger(__name__)


class GateID(Enum):
    """Quality gate identifiers."""
    G0_INPUT = "G-0"
    G1_EVIDENCE = "G-1"
    G2_CONCEPT = "G-2"
    G3_GENEALOGY = "G-3"
    G4_THEORY = "G-4"
    G5_EXPORT = "G-5"


class CheckSeverity(Enum):
    """Severity levels for check failures."""
    ERROR = "error"
    WARNING = "warning"
    INFO = "info"


@dataclass
class CheckResult:
    """Result of a single quality check."""
    check_id: str
    check_name: str
    passed: bool
    score: float
    message: str
    severity: CheckSeverity = CheckSeverity.INFO
    
    def to_dict(self) -> dict:
        return {
            "check_id": self.check_id, "check_name": self.check_name,
            "passed": self.passed, "score": self.score,
            "message": self.message, "severity": self.severity.value,
        }


@dataclass
class GateResult:
    """Complete result of a gate evaluation."""
    gate_id: str
    gate_name: str
    passed: bool
    overall_score: float
    checks: List[CheckResult]
    timestamp: datetime = field(default_factory=datetime.utcnow)
    duration_ms: int = 0
    blocking: bool = True
    
    def to_dict(self) -> dict:
        return {
            "gate_id": self.gate_id, "gate_name": self.gate_name,
            "passed": self.passed, "overall_score": self.overall_score,
            "checks": [c.to_dict() for c in self.checks],
            "timestamp": self.timestamp.isoformat(),
            "duration_ms": self.duration_ms, "blocking": self.blocking,
        }


@dataclass
class AuditLog:
    """Audit log entry."""
    audit_id: str
    run_id: str
    agent_id: str
    action: str
    timestamp: datetime
    details: Dict[str, Any]
    gate_results: List[GateResult] = field(default_factory=list)
    
    def to_dict(self) -> dict:
        return {
            "audit_id": self.audit_id, "run_id": self.run_id,
            "agent_id": self.agent_id, "action": self.action,
            "timestamp": self.timestamp.isoformat(), "details": self.details,
            "gate_results": [g.to_dict() for g in self.gate_results],
        }


# Gate configurations
GATE_CONFIGS = {
    GateID.G0_INPUT: {
        "name": "بوابة الإدخال",
        "checks": [
            {"id": "G0-C1", "name": "morphological_completeness", "threshold": 0.95},
            {"id": "G0-C2", "name": "diacritization_accuracy", "threshold": 0.90},
            {"id": "G0-C3", "name": "ner_coverage", "threshold": 0.85},
        ],
        "blocking": True,
    },
    GateID.G1_EVIDENCE: {
        "name": "بوابة الأدلة",
        "checks": [
            {"id": "G1-C1", "name": "frbr_chain_complete", "threshold": 1.0},
            {"id": "G1-C2", "name": "quote_accuracy", "threshold": 0.98},
            {"id": "G1-C3", "name": "page_reference_valid", "threshold": 1.0},
            {"id": "G1-C4", "name": "source_authority", "threshold": 0.80},
        ],
        "blocking": True,
    },
    GateID.G2_CONCEPT: {
        "name": "بوابة المفاهيم",
        "checks": [
            {"id": "G2-C1", "name": "definition_sourced", "threshold": 1.0},
            {"id": "G2-C2", "name": "semantic_consistency", "threshold": 0.90},
            {"id": "G2-C3", "name": "term_normalized", "threshold": 1.0},
        ],
        "blocking": False,
    },
    GateID.G3_GENEALOGY: {
        "name": "بوابة الأنساب",
        "checks": [
            {"id": "G3-C1", "name": "temporal_consistency", "threshold": 1.0},
            {"id": "G3-C2", "name": "influence_evidenced", "threshold": 0.85},
            {"id": "G3-C3", "name": "no_circular_links", "threshold": 1.0},
        ],
        "blocking": False,
    },
    GateID.G4_THEORY: {
        "name": "بوابة النظريات",
        "checks": [
            {"id": "G4-C1", "name": "hypothesis_clear", "threshold": 0.90},
            {"id": "G4-C2", "name": "evidence_sufficient", "threshold": 1.0},
            {"id": "G4-C3", "name": "counterarguments_addressed", "threshold": 0.80},
        ],
        "blocking": True,
    },
    GateID.G5_EXPORT: {
        "name": "بوابة التصدير",
        "checks": [
            {"id": "G5-C1", "name": "no_hallucination", "threshold": 1.0},
            {"id": "G5-C2", "name": "bias_check", "threshold": 0.90},
            {"id": "G5-C3", "name": "completeness", "threshold": 0.85},
            {"id": "G5-C4", "name": "citation_format", "threshold": 1.0},
        ],
        "blocking": True,
    },
}


GUARDIAN_CONFIG = AgentConfig(
    agent_id="AGT-03-GUARDIAN",
    arabic_name="الحارس",
    layer="Governance (Layer 1)",
    autonomy_level=AutonomyLevel.L3_DECIDER,
    llm_model="gemini-1.5-pro",
    temperature=0.2,
    timeout_seconds=30,
)


class GuardianAgent(BaseAgent):
    """Quality guardian agent for gate enforcement and auditing."""
    
    def __init__(self, config: AgentConfig = GUARDIAN_CONFIG):
        super().__init__(config)
        self.audit_logs: List[AuditLog] = []
        
    def validate_input(self, payload: dict) -> tuple[bool, Optional[str]]:
        if "action" not in payload:
            return False, "Missing required field: action"
        action = payload.get("action")
        if action not in ["evaluate_gate", "audit", "export_check"]:
            return False, f"Invalid action: {action}"
        return True, None
    
    def validate_output(self, result: AgentResult) -> tuple[bool, Optional[str]]:
        if not result.success:
            return True, None
        return True, None
    
    async def process(self, message: AgentMessage) -> AgentResult:
        action = message.payload.get("action")
        
        if action == "evaluate_gate":
            return await self._evaluate_gate(message)
        elif action == "audit":
            return await self._create_audit(message)
        elif action == "export_check":
            return await self._export_check(message)
        
        return AgentResult(success=False, error=f"Unknown action: {action}")
    
    async def _evaluate_gate(self, message: AgentMessage) -> AgentResult:
        """Evaluate a quality gate."""
        gate_id_str = message.payload.get("gate_id", "G-5")
        data = message.payload.get("data", {})
        
        try:
            gate_id = GateID(gate_id_str)
        except ValueError:
            return AgentResult(success=False, error=f"Invalid gate ID: {gate_id_str}")
        
        start_time = datetime.utcnow()
        config = GATE_CONFIGS[gate_id]
        checks = []
        
        for check_config in config["checks"]:
            score = self._run_check(check_config, data)
            passed = score >= check_config["threshold"]
            
            checks.append(CheckResult(
                check_id=check_config["id"],
                check_name=check_config["name"],
                passed=passed,
                score=score,
                message="Passed" if passed else f"Below threshold ({score:.2f} < {check_config['threshold']})",
                severity=CheckSeverity.ERROR if not passed and config["blocking"] else CheckSeverity.WARNING,
            ))
        
        overall_score = sum(c.score for c in checks) / len(checks) if checks else 0
        all_passed = all(c.passed for c in checks)
        
        duration = int((datetime.utcnow() - start_time).total_seconds() * 1000)
        
        gate_result = GateResult(
            gate_id=gate_id.value,
            gate_name=config["name"],
            passed=all_passed,
            overall_score=overall_score,
            checks=checks,
            duration_ms=duration,
            blocking=config["blocking"],
        )
        
        return AgentResult(
            success=True,
            output=gate_result,
            confidence=overall_score,
            metadata={"gate_passed": all_passed, "blocking": config["blocking"]},
        )
    
    def _run_check(self, check_config: dict, data: dict) -> float:
        """Run a specific check and return score."""
        check_name = check_config["name"]
        
        # Placeholder implementations
        check_handlers = {
            "morphological_completeness": lambda d: 0.96,
            "diacritization_accuracy": lambda d: 0.92,
            "ner_coverage": lambda d: 0.88,
            "frbr_chain_complete": lambda d: 1.0 if d.get("frbr_complete") else 0.5,
            "quote_accuracy": lambda d: 0.99,
            "page_reference_valid": lambda d: 1.0,
            "source_authority": lambda d: 0.85,
            "definition_sourced": lambda d: 1.0 if d.get("evidence_ids") else 0.0,
            "semantic_consistency": lambda d: 0.95,
            "term_normalized": lambda d: 1.0,
            "temporal_consistency": lambda d: 1.0,
            "influence_evidenced": lambda d: 0.90,
            "no_circular_links": lambda d: 1.0,
            "hypothesis_clear": lambda d: 0.92,
            "evidence_sufficient": lambda d: 1.0 if len(d.get("evidence_ids", [])) >= 3 else 0.5,
            "counterarguments_addressed": lambda d: 0.85,
            "no_hallucination": lambda d: 1.0,
            "bias_check": lambda d: 0.95,
            "completeness": lambda d: 0.90,
            "citation_format": lambda d: 1.0,
        }
        
        handler = check_handlers.get(check_name, lambda d: 0.8)
        return handler(data)
    
    async def _create_audit(self, message: AgentMessage) -> AgentResult:
        """Create an audit log entry."""
        audit = AuditLog(
            audit_id=f"AUDIT-{uuid.uuid4().hex[:8].upper()}",
            run_id=message.run_id,
            agent_id=message.payload.get("agent_id", "unknown"),
            action=message.payload.get("audit_action", "unknown"),
            timestamp=datetime.utcnow(),
            details=message.payload.get("details", {}),
        )
        self.audit_logs.append(audit)
        
        return AgentResult(success=True, output=audit, confidence=1.0)
    
    async def _export_check(self, message: AgentMessage) -> AgentResult:
        """Final export quality check (G-5)."""
        message.payload["gate_id"] = "G-5"
        return await self._evaluate_gate(message)
