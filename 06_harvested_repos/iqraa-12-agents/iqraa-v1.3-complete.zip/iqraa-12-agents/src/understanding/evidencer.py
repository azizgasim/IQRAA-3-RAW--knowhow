"""
Evidencer Agent (المحقق)
=========================
Layer 2: Understanding
Evidence specialist for FRBR citations, source verification, and quote extraction.

Responsibilities:
- Evidence collection and verification
- FRBR citation chain validation
- Quote extraction and context
- Source authority assessment
"""

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any
from enum import Enum
from datetime import datetime
import logging
import uuid
import re

from src.shared.base_agent import (
    BaseAgent, AgentConfig, AgentMessage, AgentResult, AutonomyLevel,
)

logger = logging.getLogger(__name__)


class SourceType(Enum):
    """Types of sources."""
    PRIMARY = "primary"
    SECONDARY = "secondary"
    TERTIARY = "tertiary"


class VerificationStatus(Enum):
    """Verification status of evidence."""
    VERIFIED = "verified"
    UNVERIFIED = "unverified"
    DISPUTED = "disputed"
    PENDING = "pending"


@dataclass
class FRBRChain:
    """FRBR bibliographic chain."""
    work_id: Optional[str] = None
    expression_id: Optional[str] = None
    manifestation_id: Optional[str] = None
    item_id: Optional[str] = None
    
    def is_complete(self) -> bool:
        return all([self.work_id, self.expression_id, self.manifestation_id])
    
    def to_dict(self) -> dict:
        return {
            "work_id": self.work_id, "expression_id": self.expression_id,
            "manifestation_id": self.manifestation_id, "item_id": self.item_id,
            "complete": self.is_complete(),
        }


@dataclass
class EvidenceUnit:
    """A unit of evidence with full citation."""
    evidence_id: str
    frbr: FRBRChain
    quote_ar: str
    quote_normalized: str
    volume: Optional[int] = None
    page_start: Optional[int] = None
    page_end: Optional[int] = None
    line_start: Optional[int] = None
    line_end: Optional[int] = None
    context_before: str = ""
    context_after: str = ""
    source_type: SourceType = SourceType.PRIMARY
    verification_status: VerificationStatus = VerificationStatus.UNVERIFIED
    confidence: float = 0.8
    linguistic_analysis_id: Optional[str] = None
    
    def to_dict(self) -> dict:
        return {
            "evidence_id": self.evidence_id, "frbr": self.frbr.to_dict(),
            "quote_ar": self.quote_ar, "quote_normalized": self.quote_normalized,
            "volume": self.volume, "page_start": self.page_start, "page_end": self.page_end,
            "line_start": self.line_start, "line_end": self.line_end,
            "context_before": self.context_before, "context_after": self.context_after,
            "source_type": self.source_type.value,
            "verification_status": self.verification_status.value,
            "confidence": self.confidence, "linguistic_analysis_id": self.linguistic_analysis_id,
        }


@dataclass
class EvidenceCollection:
    """Collection of evidence for a query."""
    collection_id: str
    query: str
    evidence_units: List[EvidenceUnit]
    total_found: int
    coverage_score: float
    
    def to_dict(self) -> dict:
        return {
            "collection_id": self.collection_id, "query": self.query,
            "evidence_units": [e.to_dict() for e in self.evidence_units],
            "total_found": self.total_found, "coverage_score": self.coverage_score,
        }


EVIDENCER_CONFIG = AgentConfig(
    agent_id="AGT-05-EVIDENCER",
    arabic_name="المحقق",
    layer="Understanding (Layer 2)",
    autonomy_level=AutonomyLevel.L2_ADVISOR,
    llm_model="gemini-1.5-pro",
    temperature=0.2,
    timeout_seconds=90,
)


class EvidencerAgent(BaseAgent):
    """Evidence collection and verification agent."""
    
    def __init__(self, config: AgentConfig = EVIDENCER_CONFIG):
        super().__init__(config)
        
    def validate_input(self, payload: dict) -> tuple[bool, Optional[str]]:
        if "action" not in payload:
            return False, "Missing required field: action"
        action = payload.get("action")
        if action not in ["collect", "verify", "extract_quote", "build_citation"]:
            return False, f"Invalid action: {action}"
        return True, None
    
    def validate_output(self, result: AgentResult) -> tuple[bool, Optional[str]]:
        if not result.success:
            return True, None
        if isinstance(result.output, EvidenceCollection):
            if result.output.coverage_score < 0.5:
                return False, "Coverage score too low"
        return True, None
    
    async def process(self, message: AgentMessage) -> AgentResult:
        action = message.payload.get("action")
        
        if action == "collect":
            return await self._collect_evidence(message)
        elif action == "verify":
            return await self._verify_evidence(message)
        elif action == "extract_quote":
            return await self._extract_quote(message)
        elif action == "build_citation":
            return await self._build_citation(message)
        
        return AgentResult(success=False, error=f"Unknown action: {action}")
    
    async def _collect_evidence(self, message: AgentMessage) -> AgentResult:
        """Collect evidence for a query."""
        query = message.payload.get("query", "")
        concept_id = message.payload.get("concept_id")
        max_results = message.payload.get("max_results", 10)
        
        self.logger.info(f"Collecting evidence for: {query[:50]}...")
        
        # TODO: Implement actual evidence collection from BigQuery/RAG
        # Placeholder: Create sample evidence
        evidence_units = []
        
        # Simulate finding evidence
        for i in range(min(3, max_results)):
            evidence = EvidenceUnit(
                evidence_id=f"EVID-{uuid.uuid4().hex[:12].upper()}",
                frbr=FRBRChain(
                    work_id=f"WORK-{uuid.uuid4().hex[:8].upper()}",
                    expression_id=f"EXPR-{uuid.uuid4().hex[:8].upper()}",
                    manifestation_id=f"MANIF-{uuid.uuid4().hex[:8].upper()}",
                ),
                quote_ar=f"نص الاقتباس رقم {i+1} المتعلق بالاستعلام",
                quote_normalized=f"نص الاقتباس رقم {i+1}",
                volume=1,
                page_start=100 + i * 10,
                page_end=100 + i * 10 + 5,
                confidence=0.85 - (i * 0.05),
            )
            evidence_units.append(evidence)
        
        collection = EvidenceCollection(
            collection_id=f"COLL-{uuid.uuid4().hex[:8].upper()}",
            query=query,
            evidence_units=evidence_units,
            total_found=len(evidence_units),
            coverage_score=0.85,
        )
        
        return AgentResult(
            success=True, output=collection,
            confidence=collection.coverage_score,
            metadata={"evidence_count": len(evidence_units)},
        )
    
    async def _verify_evidence(self, message: AgentMessage) -> AgentResult:
        """Verify an evidence unit."""
        evidence_id = message.payload.get("evidence_id")
        
        # TODO: Implement actual verification against original sources
        verification = {
            "evidence_id": evidence_id,
            "verified": True,
            "frbr_complete": True,
            "quote_matches": True,
            "page_valid": True,
            "confidence": 0.95,
        }
        
        return AgentResult(
            success=True, output=verification, confidence=0.95,
        )
    
    async def _extract_quote(self, message: AgentMessage) -> AgentResult:
        """Extract a quote with context."""
        text = message.payload.get("text", "")
        start = message.payload.get("start", 0)
        end = message.payload.get("end", len(text))
        context_size = message.payload.get("context_size", 100)
        
        quote = text[start:end]
        context_before = text[max(0, start - context_size):start]
        context_after = text[end:end + context_size]
        
        return AgentResult(
            success=True,
            output={
                "quote": quote,
                "context_before": context_before,
                "context_after": context_after,
                "normalized": self._normalize_quote(quote),
            },
            confidence=0.9,
        )
    
    async def _build_citation(self, message: AgentMessage) -> AgentResult:
        """Build a formatted citation."""
        frbr = message.payload.get("frbr", {})
        page = message.payload.get("page")
        volume = message.payload.get("volume")
        
        # Build citation string
        # Format: المؤلف، العنوان، المحقق (الناشر، السنة)، ج/ص
        citation_parts = []
        
        if frbr.get("work_title"):
            citation_parts.append(frbr["work_title"])
        
        location = []
        if volume:
            location.append(f"ج{volume}")
        if page:
            location.append(f"ص{page}")
        
        if location:
            citation_parts.append("/".join(location))
        
        citation = "، ".join(citation_parts) if citation_parts else "مصدر غير محدد"
        
        return AgentResult(
            success=True,
            output={"citation": citation, "frbr": frbr},
            confidence=1.0 if frbr.get("work_id") else 0.5,
        )
    
    def _normalize_quote(self, quote: str) -> str:
        """Normalize Arabic quote for matching."""
        quote = re.sub(r'\u0640', '', quote)  # Remove tatweel
        quote = re.sub(r'[إأآا]', 'ا', quote)  # Normalize alef
        quote = re.sub(r'[\u064B-\u065F]', '', quote)  # Remove diacritics
        return quote.strip()
