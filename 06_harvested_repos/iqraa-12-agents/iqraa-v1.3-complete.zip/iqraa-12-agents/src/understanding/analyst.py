"""
Analyst Agent (المحلل)
=======================
Layer 2: Understanding
Epistemological analyst for concept cards, definitions, and classifications.

Responsibilities:
- Concept card creation
- Definition extraction and analysis
- Semantic classification
- Epistemological categorization
"""

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any
from enum import Enum
from datetime import datetime
import logging
import uuid

from src.shared.base_agent import (
    BaseAgent, AgentConfig, AgentMessage, AgentResult, AutonomyLevel,
)

logger = logging.getLogger(__name__)


class DefinitionType(Enum):
    """Types of definitions."""
    LINGUISTIC = "linguistic"  # لغوي
    TECHNICAL = "technical"  # اصطلاحي
    CONTEXTUAL = "contextual"  # سياقي
    MODERN = "modern"  # معاصر


class RelationType(Enum):
    """Types of concept relationships."""
    SYNONYM = "synonym"  # مرادف
    ANTONYM = "antonym"  # ضد
    HYPERNYM = "hypernym"  # أعم
    HYPONYM = "hyponym"  # أخص
    RELATED = "related"  # مرتبط
    DERIVED_FROM = "derived_from"  # مشتق من
    LEADS_TO = "leads_to"  # يؤدي إلى


@dataclass
class Definition:
    """A single definition of a concept."""
    definition_id: str
    definition_ar: str
    definition_en: Optional[str] = None
    definition_type: DefinitionType = DefinitionType.TECHNICAL
    source_evidence_id: Optional[str] = None
    definer_scholar_id: Optional[str] = None
    school_of_thought: Optional[str] = None
    confidence: float = 0.8
    
    def to_dict(self) -> dict:
        return {
            "definition_id": self.definition_id, "definition_ar": self.definition_ar,
            "definition_en": self.definition_en, "definition_type": self.definition_type.value,
            "source_evidence_id": self.source_evidence_id,
            "definer_scholar_id": self.definer_scholar_id,
            "school_of_thought": self.school_of_thought, "confidence": self.confidence,
        }


@dataclass
class ConceptRelation:
    """A relationship between concepts."""
    related_concept_id: str
    relation_type: RelationType
    strength: float = 0.5
    evidence_id: Optional[str] = None
    
    def to_dict(self) -> dict:
        return {
            "related_concept_id": self.related_concept_id,
            "relation_type": self.relation_type.value,
            "strength": self.strength, "evidence_id": self.evidence_id,
        }


@dataclass
class ConceptCard:
    """Complete concept card."""
    concept_id: str
    term_ar: str
    term_normalized: str
    term_en: Optional[str] = None
    root_ar: Optional[str] = None
    morphological_pattern: Optional[str] = None
    definitions: List[Definition] = field(default_factory=list)
    semantic_field: List[str] = field(default_factory=list)
    related_concepts: List[ConceptRelation] = field(default_factory=list)
    usage_contexts: List[str] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.utcnow)
    status: str = "draft"
    confidence: float = 0.8
    
    def to_dict(self) -> dict:
        return {
            "concept_id": self.concept_id, "term_ar": self.term_ar,
            "term_normalized": self.term_normalized, "term_en": self.term_en,
            "root_ar": self.root_ar, "morphological_pattern": self.morphological_pattern,
            "definitions": [d.to_dict() for d in self.definitions],
            "semantic_field": self.semantic_field,
            "related_concepts": [r.to_dict() for r in self.related_concepts],
            "usage_contexts": self.usage_contexts,
            "created_at": self.created_at.isoformat(), "status": self.status,
            "confidence": self.confidence,
        }


ANALYST_CONFIG = AgentConfig(
    agent_id="AGT-06-ANALYST",
    arabic_name="المحلل",
    layer="Understanding (Layer 2)",
    autonomy_level=AutonomyLevel.L2_ADVISOR,
    llm_model="gemini-1.5-pro",
    temperature=0.4,
    timeout_seconds=90,
)


class AnalystAgent(BaseAgent):
    """Epistemological analysis agent."""
    
    def __init__(self, config: AgentConfig = ANALYST_CONFIG):
        super().__init__(config)
        
    def validate_input(self, payload: dict) -> tuple[bool, Optional[str]]:
        if "action" not in payload:
            return False, "Missing required field: action"
        action = payload.get("action")
        valid_actions = ["create_concept", "extract_definitions", "find_relations", "classify"]
        if action not in valid_actions:
            return False, f"Invalid action: {action}"
        return True, None
    
    def validate_output(self, result: AgentResult) -> tuple[bool, Optional[str]]:
        if not result.success:
            return True, None
        if isinstance(result.output, ConceptCard):
            if len(result.output.definitions) == 0:
                return False, "Concept card must have at least one definition"
        return True, None
    
    async def process(self, message: AgentMessage) -> AgentResult:
        action = message.payload.get("action")
        
        if action == "create_concept":
            return await self._create_concept(message)
        elif action == "extract_definitions":
            return await self._extract_definitions(message)
        elif action == "find_relations":
            return await self._find_relations(message)
        elif action == "classify":
            return await self._classify_concept(message)
        
        return AgentResult(success=False, error=f"Unknown action: {action}")
    
    async def _create_concept(self, message: AgentMessage) -> AgentResult:
        """Create a new concept card."""
        term_ar = message.payload.get("term_ar", "")
        evidence_ids = message.payload.get("evidence_ids", [])
        linguistic_analysis = message.payload.get("linguistic_analysis", {})
        
        self.logger.info(f"Creating concept card for: {term_ar}")
        
        # Extract root and pattern from linguistic analysis
        root_ar = linguistic_analysis.get("root", "")
        pattern = linguistic_analysis.get("pattern", "")
        
        # Normalize term
        term_normalized = self._normalize_term(term_ar)
        
        # Create definitions (placeholder - would use LLM in production)
        definitions = [
            Definition(
                definition_id=f"DEF-{uuid.uuid4().hex[:8].upper()}",
                definition_ar=f"تعريف مصطلح {term_ar} في السياق الإسلامي",
                definition_type=DefinitionType.TECHNICAL,
                source_evidence_id=evidence_ids[0] if evidence_ids else None,
                confidence=0.8,
            )
        ]
        
        concept = ConceptCard(
            concept_id=f"CONC-{uuid.uuid4().hex[:8].upper()}",
            term_ar=term_ar,
            term_normalized=term_normalized,
            root_ar=root_ar,
            morphological_pattern=pattern,
            definitions=definitions,
            semantic_field=self._infer_semantic_field(term_ar),
            usage_contexts=["fiqh", "aqeedah"],
            confidence=0.75,
        )
        
        return AgentResult(
            success=True, output=concept, confidence=concept.confidence,
            metadata={"definition_count": len(definitions)},
        )
    
    async def _extract_definitions(self, message: AgentMessage) -> AgentResult:
        """Extract definitions from evidence."""
        evidence_texts = message.payload.get("evidence_texts", [])
        term_ar = message.payload.get("term_ar", "")
        
        definitions = []
        
        # TODO: Use LLM to extract actual definitions
        for i, text in enumerate(evidence_texts[:3]):
            definitions.append(Definition(
                definition_id=f"DEF-{uuid.uuid4().hex[:8].upper()}",
                definition_ar=f"التعريف المستخرج رقم {i+1}",
                definition_type=DefinitionType.TECHNICAL,
                confidence=0.7,
            ))
        
        return AgentResult(
            success=True, output={"definitions": [d.to_dict() for d in definitions]},
            confidence=0.75,
        )
    
    async def _find_relations(self, message: AgentMessage) -> AgentResult:
        """Find related concepts."""
        concept_id = message.payload.get("concept_id")
        term_ar = message.payload.get("term_ar", "")
        
        # TODO: Query BigQuery for related concepts
        relations = [
            ConceptRelation(
                related_concept_id=f"CONC-{uuid.uuid4().hex[:8].upper()}",
                relation_type=RelationType.RELATED,
                strength=0.7,
            )
        ]
        
        return AgentResult(
            success=True, output={"relations": [r.to_dict() for r in relations]},
            confidence=0.7,
        )
    
    async def _classify_concept(self, message: AgentMessage) -> AgentResult:
        """Classify concept into domains."""
        term_ar = message.payload.get("term_ar", "")
        definitions = message.payload.get("definitions", [])
        
        # Classify into Islamic knowledge domains
        domains = self._infer_semantic_field(term_ar)
        
        return AgentResult(
            success=True, output={"domains": domains, "primary_domain": domains[0] if domains else None},
            confidence=0.8,
        )
    
    def _normalize_term(self, term: str) -> str:
        """Normalize Arabic term."""
        import re
        term = re.sub(r'[إأآا]', 'ا', term)
        term = re.sub(r'ى', 'ي', term)
        term = re.sub(r'ة', 'ه', term)
        term = re.sub(r'[\u064B-\u065F]', '', term)
        return term.strip()
    
    def _infer_semantic_field(self, term: str) -> List[str]:
        """Infer semantic field from term."""
        fields = []
        
        keywords = {
            "fiqh": ["حكم", "فقه", "حلال", "حرام", "واجب", "مستحب"],
            "aqeedah": ["إيمان", "توحيد", "عقيدة", "الله", "رب"],
            "hadith": ["حديث", "رواية", "إسناد", "راوي"],
            "tafsir": ["آية", "سورة", "تفسير", "قرآن"],
            "usul": ["أصول", "قياس", "إجماع", "دليل"],
        }
        
        for field, kws in keywords.items():
            if any(kw in term for kw in kws):
                fields.append(field)
        
        return fields if fields else ["general"]
