"""
Improver Agent (المحسّن)
=========================
Layer 5: Meta-Governance
Auto-improvement agent for error learning and system enhancement.

Responsibilities:
- Analyze error patterns
- Propose agent improvements
- Update playbooks
- Generate improvement reports
- Manage feedback loops
"""

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any
from enum import Enum
from datetime import datetime
import logging
import uuid

from src.shared.base_agent import (
    BaseAgent, AgentConfig, AgentMessage, AgentResult, AutonomyLevel,
)

logger = logging.getLogger(__name__)


class ErrorCategory(Enum):
    """Categories of errors."""
    HALLUCINATION = "hallucination"
    CITATION_ERROR = "citation_error"
    LOGIC_ERROR = "logic_error"
    GATE_FAILURE = "gate_failure"
    TIMEOUT = "timeout"
    VALIDATION_ERROR = "validation_error"
    HUMAN_REJECTION = "human_rejection"


class ImprovementType(Enum):
    """Types of improvements."""
    PROMPT_UPDATE = "prompt_update"
    THRESHOLD_ADJUSTMENT = "threshold_adjustment"
    PLAYBOOK_MODIFICATION = "playbook_modification"
    AGENT_CONFIG_CHANGE = "agent_config_change"
    NEW_CHECK_ADDITION = "new_check_addition"


class ImprovementStatus(Enum):
    """Status of improvement proposals."""
    PROPOSED = "proposed"
    UNDER_REVIEW = "under_review"
    APPROVED = "approved"
    IMPLEMENTED = "implemented"
    REJECTED = "rejected"


@dataclass
class ErrorPattern:
    """A detected error pattern."""
    pattern_id: str
    category: ErrorCategory
    description_ar: str
    frequency: int
    affected_agents: List[str]
    sample_error_ids: List[str]
    root_cause_hypothesis: Optional[str] = None
    first_seen: datetime = field(default_factory=datetime.utcnow)
    last_seen: datetime = field(default_factory=datetime.utcnow)
    
    def to_dict(self) -> dict:
        return {
            "pattern_id": self.pattern_id, "category": self.category.value,
            "description_ar": self.description_ar, "frequency": self.frequency,
            "affected_agents": self.affected_agents, "sample_error_ids": self.sample_error_ids,
            "root_cause_hypothesis": self.root_cause_hypothesis,
            "first_seen": self.first_seen.isoformat(), "last_seen": self.last_seen.isoformat(),
        }


@dataclass
class ImprovementProposal:
    """A proposed improvement."""
    proposal_id: str
    improvement_type: ImprovementType
    title_ar: str
    description_ar: str
    target_agent: Optional[str] = None
    target_playbook: Optional[str] = None
    source_pattern_ids: List[str] = field(default_factory=list)
    expected_impact: str = "medium"
    implementation_steps: List[str] = field(default_factory=list)
    status: ImprovementStatus = ImprovementStatus.PROPOSED
    created_at: datetime = field(default_factory=datetime.utcnow)
    
    def to_dict(self) -> dict:
        return {
            "proposal_id": self.proposal_id, "improvement_type": self.improvement_type.value,
            "title_ar": self.title_ar, "description_ar": self.description_ar,
            "target_agent": self.target_agent, "target_playbook": self.target_playbook,
            "source_pattern_ids": self.source_pattern_ids, "expected_impact": self.expected_impact,
            "implementation_steps": self.implementation_steps, "status": self.status.value,
            "created_at": self.created_at.isoformat(),
        }


@dataclass
class ImprovementReport:
    """Periodic improvement report."""
    report_id: str
    period_start: datetime
    period_end: datetime
    total_errors: int
    patterns_detected: int
    proposals_generated: int
    proposals_implemented: int
    system_health_score: float
    highlights: List[str] = field(default_factory=list)
    concerns: List[str] = field(default_factory=list)
    
    def to_dict(self) -> dict:
        return {
            "report_id": self.report_id,
            "period_start": self.period_start.isoformat(),
            "period_end": self.period_end.isoformat(),
            "total_errors": self.total_errors, "patterns_detected": self.patterns_detected,
            "proposals_generated": self.proposals_generated,
            "proposals_implemented": self.proposals_implemented,
            "system_health_score": self.system_health_score,
            "highlights": self.highlights, "concerns": self.concerns,
        }


IMPROVER_CONFIG = AgentConfig(
    agent_id="AGT-11-IMPROVER",
    arabic_name="المحسّن",
    layer="Meta-Governance (Layer 5)",
    autonomy_level=AutonomyLevel.L3_DECIDER,
    llm_model="gemini-1.5-pro",
    temperature=0.4,
    timeout_seconds=180,
)


class ImproverAgent(BaseAgent):
    """System auto-improvement agent."""
    
    def __init__(self, config: AgentConfig = IMPROVER_CONFIG):
        super().__init__(config)
        
    def validate_input(self, payload: dict) -> tuple[bool, Optional[str]]:
        if "action" not in payload:
            return False, "Missing required field: action"
        action = payload.get("action")
        valid_actions = [
            "analyze_errors", "detect_patterns", "propose_improvements",
            "update_playbook", "generate_report", "feedback_loop"
        ]
        if action not in valid_actions:
            return False, f"Invalid action: {action}"
        return True, None
    
    def validate_output(self, result: AgentResult) -> tuple[bool, Optional[str]]:
        return True, None
    
    async def process(self, message: AgentMessage) -> AgentResult:
        action = message.payload.get("action")
        
        if action == "analyze_errors":
            return await self._analyze_errors(message)
        elif action == "detect_patterns":
            return await self._detect_patterns(message)
        elif action == "propose_improvements":
            return await self._propose_improvements(message)
        elif action == "update_playbook":
            return await self._update_playbook(message)
        elif action == "generate_report":
            return await self._generate_report(message)
        elif action == "feedback_loop":
            return await self._feedback_loop(message)
        
        return AgentResult(success=False, error=f"Unknown action: {action}")
    
    async def _analyze_errors(self, message: AgentMessage) -> AgentResult:
        """Analyze error registry."""
        time_range_hours = message.payload.get("time_range_hours", 24)
        
        self.logger.info(f"Analyzing errors from last {time_range_hours} hours")
        
        # TODO: Query BigQuery error_registry
        analysis = {
            "time_range_hours": time_range_hours,
            "total_errors": 15,
            "by_category": {
                "hallucination": 3,
                "citation_error": 5,
                "gate_failure": 4,
                "timeout": 3,
            },
            "by_agent": {
                "AGT-05-EVIDENCER": 6,
                "AGT-06-ANALYST": 4,
                "AGT-09-THEORIST": 5,
            },
            "trend": "stable",
        }
        
        return AgentResult(
            success=True, output=analysis, confidence=0.9,
        )
    
    async def _detect_patterns(self, message: AgentMessage) -> AgentResult:
        """Detect error patterns."""
        error_data = message.payload.get("error_data", {})
        min_frequency = message.payload.get("min_frequency", 3)
        
        patterns = []
        
        pattern = ErrorPattern(
            pattern_id=f"EPAT-{uuid.uuid4().hex[:8].upper()}",
            category=ErrorCategory.CITATION_ERROR,
            description_ar="أخطاء متكررة في التحقق من المصادر",
            frequency=5,
            affected_agents=["AGT-05-EVIDENCER"],
            sample_error_ids=["ERR-001", "ERR-003", "ERR-007"],
            root_cause_hypothesis="عتبة التحقق منخفضة جداً",
        )
        patterns.append(pattern)
        
        return AgentResult(
            success=True,
            output={"patterns": [p.to_dict() for p in patterns]},
            confidence=0.75,
            metadata={"pattern_count": len(patterns)},
        )
    
    async def _propose_improvements(self, message: AgentMessage) -> AgentResult:
        """Propose improvements based on patterns."""
        patterns = message.payload.get("patterns", [])
        
        proposals = []
        
        for pattern in patterns[:3]:
            proposal = ImprovementProposal(
                proposal_id=f"PROP-{uuid.uuid4().hex[:8].upper()}",
                improvement_type=ImprovementType.THRESHOLD_ADJUSTMENT,
                title_ar="تعديل عتبة التحقق",
                description_ar=f"رفع عتبة التحقق بناءً على النمط {pattern.get('pattern_id', 'unknown')}",
                target_agent=pattern.get("affected_agents", ["unknown"])[0] if pattern.get("affected_agents") else None,
                source_pattern_ids=[pattern.get("pattern_id", "")],
                expected_impact="high",
                implementation_steps=[
                    "مراجعة العتبة الحالية",
                    "اختبار العتبة الجديدة",
                    "تطبيق التغيير تدريجياً",
                ],
            )
            proposals.append(proposal)
        
        return AgentResult(
            success=True,
            output={"proposals": [p.to_dict() for p in proposals]},
            confidence=0.7,
            requires_human_review=True,
            review_reason="Improvement proposals require human approval",
        )
    
    async def _update_playbook(self, message: AgentMessage) -> AgentResult:
        """Update a playbook based on lessons learned."""
        playbook_id = message.payload.get("playbook_id")
        changes = message.payload.get("changes", [])
        
        update = {
            "playbook_id": playbook_id,
            "update_id": f"PBU-{uuid.uuid4().hex[:8].upper()}",
            "changes_applied": len(changes),
            "new_version": "1.1",
            "changelog": changes,
        }
        
        return AgentResult(
            success=True, output=update, confidence=0.9,
            requires_human_review=True,
            review_reason="Playbook updates require human approval",
        )
    
    async def _generate_report(self, message: AgentMessage) -> AgentResult:
        """Generate improvement report."""
        period_days = message.payload.get("period_days", 7)
        
        now = datetime.utcnow()
        period_start = datetime(now.year, now.month, now.day - period_days)
        
        report = ImprovementReport(
            report_id=f"RPT-{uuid.uuid4().hex[:8].upper()}",
            period_start=period_start,
            period_end=now,
            total_errors=45,
            patterns_detected=5,
            proposals_generated=8,
            proposals_implemented=3,
            system_health_score=0.85,
            highlights=[
                "انخفاض أخطاء الاقتباس بنسبة 30%",
                "تحسن وقت الاستجابة",
            ],
            concerns=[
                "ارتفاع طفيف في أخطاء المنطق",
            ],
        )
        
        return AgentResult(
            success=True, output=report, confidence=0.95,
        )
    
    async def _feedback_loop(self, message: AgentMessage) -> AgentResult:
        """Process feedback and trigger improvements."""
        feedback_type = message.payload.get("feedback_type", "error")
        feedback_data = message.payload.get("data", {})
        
        response = {
            "feedback_processed": True,
            "feedback_type": feedback_type,
            "actions_triggered": [],
        }
        
        # Determine actions based on feedback
        if feedback_type == "error":
            response["actions_triggered"].append("error_logged")
            # Check if pattern threshold reached
            response["actions_triggered"].append("pattern_check_scheduled")
            
        elif feedback_type == "human_rejection":
            response["actions_triggered"].append("rejection_recorded")
            response["actions_triggered"].append("improvement_proposal_triggered")
        
        return AgentResult(
            success=True, output=response, confidence=1.0,
        )
