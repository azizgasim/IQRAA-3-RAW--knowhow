"""
Theorist Agent (المنظّر)
=========================
Layer 4: Building
Theory builder for hypothesis formation and framework construction.

Responsibilities:
- Build theory cards
- Form hypotheses
- Construct frameworks
- Synthesize findings
"""

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any
from enum import Enum
from datetime import datetime
import logging
import uuid

from src.shared.base_agent import (
    BaseAgent, AgentConfig, AgentMessage, AgentResult, AutonomyLevel,
)

logger = logging.getLogger(__name__)


class HypothesisType(Enum):
    """Types of hypotheses."""
    DESCRIPTIVE = "descriptive"
    EXPLANATORY = "explanatory"
    PREDICTIVE = "predictive"
    NORMATIVE = "normative"


class ArgumentType(Enum):
    """Types of arguments."""
    DEDUCTIVE = "deductive"
    INDUCTIVE = "inductive"
    ANALOGICAL = "analogical"
    TEXTUAL = "textual"
    HISTORICAL = "historical"


@dataclass
class Hypothesis:
    """A hypothesis statement."""
    hypothesis_id: str
    statement_ar: str
    statement_en: Optional[str] = None
    hypothesis_type: HypothesisType = HypothesisType.DESCRIPTIVE
    scope: Optional[str] = None
    falsifiable: bool = True
    
    def to_dict(self) -> dict:
        return {
            "hypothesis_id": self.hypothesis_id, "statement_ar": self.statement_ar,
            "statement_en": self.statement_en, "hypothesis_type": self.hypothesis_type.value,
            "scope": self.scope, "falsifiable": self.falsifiable,
        }


@dataclass
class Argument:
    """A supporting or counter argument."""
    argument_id: str
    argument_ar: str
    argument_type: ArgumentType
    evidence_ids: List[str] = field(default_factory=list)
    strength: float = 0.5
    is_counter: bool = False
    rebuttal_ar: Optional[str] = None
    
    def to_dict(self) -> dict:
        return {
            "argument_id": self.argument_id, "argument_ar": self.argument_ar,
            "argument_type": self.argument_type.value, "evidence_ids": self.evidence_ids,
            "strength": self.strength, "is_counter": self.is_counter, "rebuttal_ar": self.rebuttal_ar,
        }


@dataclass
class TheoryCard:
    """Complete theory card."""
    theory_id: str
    title_ar: str
    title_en: Optional[str] = None
    abstract_ar: Optional[str] = None
    hypothesis: Optional[Hypothesis] = None
    evidence_ids: List[str] = field(default_factory=list)
    concept_ids: List[str] = field(default_factory=list)
    supporting_arguments: List[Argument] = field(default_factory=list)
    counter_arguments: List[Argument] = field(default_factory=list)
    methodology: Dict[str, Any] = field(default_factory=dict)
    implications: List[Dict[str, str]] = field(default_factory=list)
    confidence: float = 0.5
    status: str = "draft"
    created_at: datetime = field(default_factory=datetime.utcnow)
    
    def to_dict(self) -> dict:
        return {
            "theory_id": self.theory_id, "title_ar": self.title_ar, "title_en": self.title_en,
            "abstract_ar": self.abstract_ar,
            "hypothesis": self.hypothesis.to_dict() if self.hypothesis else None,
            "evidence_ids": self.evidence_ids, "concept_ids": self.concept_ids,
            "supporting_arguments": [a.to_dict() for a in self.supporting_arguments],
            "counter_arguments": [a.to_dict() for a in self.counter_arguments],
            "methodology": self.methodology, "implications": self.implications,
            "confidence": self.confidence, "status": self.status,
            "created_at": self.created_at.isoformat(),
        }


THEORIST_CONFIG = AgentConfig(
    agent_id="AGT-09-THEORIST",
    arabic_name="المنظّر",
    layer="Building (Layer 4)",
    autonomy_level=AutonomyLevel.L3_DECIDER,
    llm_model="gemini-1.5-pro",
    temperature=0.6,
    timeout_seconds=180,
)


class TheoristAgent(BaseAgent):
    """Theory building agent."""
    
    def __init__(self, config: AgentConfig = THEORIST_CONFIG):
        super().__init__(config)
        
    def validate_input(self, payload: dict) -> tuple[bool, Optional[str]]:
        if "action" not in payload:
            return False, "Missing required field: action"
        action = payload.get("action")
        valid_actions = ["build_theory", "form_hypothesis", "construct_argument", "synthesize"]
        if action not in valid_actions:
            return False, f"Invalid action: {action}"
        return True, None
    
    def validate_output(self, result: AgentResult) -> tuple[bool, Optional[str]]:
        if not result.success:
            return True, None
        if isinstance(result.output, TheoryCard):
            if len(result.output.evidence_ids) < 3:
                return False, "Theory must have at least 3 evidence units"
        return True, None
    
    async def process(self, message: AgentMessage) -> AgentResult:
        action = message.payload.get("action")
        
        if action == "build_theory":
            return await self._build_theory(message)
        elif action == "form_hypothesis":
            return await self._form_hypothesis(message)
        elif action == "construct_argument":
            return await self._construct_argument(message)
        elif action == "synthesize":
            return await self._synthesize(message)
        
        return AgentResult(success=False, error=f"Unknown action: {action}")
    
    async def _build_theory(self, message: AgentMessage) -> AgentResult:
        """Build a complete theory card."""
        title_ar = message.payload.get("title_ar", "")
        evidence_ids = message.payload.get("evidence_ids", [])
        concept_ids = message.payload.get("concept_ids", [])
        
        self.logger.info(f"Building theory: {title_ar}")
        
        # Create hypothesis
        hypothesis = Hypothesis(
            hypothesis_id=f"HYP-{uuid.uuid4().hex[:8].upper()}",
            statement_ar=f"فرضية: {title_ar}",
            hypothesis_type=HypothesisType.EXPLANATORY,
            falsifiable=True,
        )
        
        # Create supporting arguments
        arguments = []
        for i, eid in enumerate(evidence_ids[:3]):
            arg = Argument(
                argument_id=f"ARG-{uuid.uuid4().hex[:8].upper()}",
                argument_ar=f"الحجة الداعمة رقم {i+1}",
                argument_type=ArgumentType.TEXTUAL,
                evidence_ids=[eid],
                strength=0.8 - (i * 0.1),
            )
            arguments.append(arg)
        
        theory = TheoryCard(
            theory_id=f"THEO-{uuid.uuid4().hex[:8].upper()}",
            title_ar=title_ar,
            abstract_ar=f"ملخص النظرية حول {title_ar}",
            hypothesis=hypothesis,
            evidence_ids=evidence_ids,
            concept_ids=concept_ids,
            supporting_arguments=arguments,
            methodology={"approach": "textual_analysis", "limitations": []},
            confidence=0.7,
            status="draft",
        )
        
        return AgentResult(
            success=True, output=theory, confidence=theory.confidence,
            metadata={"evidence_count": len(evidence_ids), "argument_count": len(arguments)},
        )
    
    async def _form_hypothesis(self, message: AgentMessage) -> AgentResult:
        """Form a hypothesis from observations."""
        observations = message.payload.get("observations", [])
        hypothesis_type = message.payload.get("type", "explanatory")
        
        hypothesis = Hypothesis(
            hypothesis_id=f"HYP-{uuid.uuid4().hex[:8].upper()}",
            statement_ar="فرضية مبنية على الملاحظات",
            hypothesis_type=HypothesisType(hypothesis_type),
            falsifiable=True,
        )
        
        return AgentResult(
            success=True, output=hypothesis.to_dict(), confidence=0.65,
        )
    
    async def _construct_argument(self, message: AgentMessage) -> AgentResult:
        """Construct an argument."""
        claim_ar = message.payload.get("claim_ar", "")
        evidence_ids = message.payload.get("evidence_ids", [])
        argument_type = message.payload.get("type", "textual")
        
        argument = Argument(
            argument_id=f"ARG-{uuid.uuid4().hex[:8].upper()}",
            argument_ar=claim_ar,
            argument_type=ArgumentType(argument_type),
            evidence_ids=evidence_ids,
            strength=0.7 if evidence_ids else 0.3,
        )
        
        return AgentResult(
            success=True, output=argument.to_dict(), confidence=argument.strength,
        )
    
    async def _synthesize(self, message: AgentMessage) -> AgentResult:
        """Synthesize multiple theories or findings."""
        theory_ids = message.payload.get("theory_ids", [])
        
        synthesis = {
            "synthesis_id": f"SYN-{uuid.uuid4().hex[:8].upper()}",
            "source_theories": theory_ids,
            "unified_thesis_ar": "التركيب الموحد للنظريات",
            "areas_of_agreement": [],
            "areas_of_disagreement": [],
            "research_gaps": [],
        }
        
        return AgentResult(
            success=True, output=synthesis, confidence=0.6,
        )
