"""
Purifier Agent (المطهّر)
=========================
Layer 4: Building
Method purifier for bias detection and logical validation.

Responsibilities:
- Detect methodological bias
- Validate logical consistency
- Audit methodology
- Ensure epistemological rigor
"""

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any
from enum import Enum
from datetime import datetime
import logging
import uuid

from src.shared.base_agent import (
    BaseAgent, AgentConfig, AgentMessage, AgentResult, AutonomyLevel,
)

logger = logging.getLogger(__name__)


class BiasType(Enum):
    """Types of bias."""
    CONFIRMATION = "confirmation"
    SELECTION = "selection"
    ANACHRONISM = "anachronism"
    PRESENTISM = "presentism"
    CULTURAL = "cultural"
    THEOLOGICAL = "theological"
    LINGUISTIC = "linguistic"


class LogicalFallacy(Enum):
    """Types of logical fallacies."""
    CIRCULAR_REASONING = "circular_reasoning"
    FALSE_DICHOTOMY = "false_dichotomy"
    AD_HOMINEM = "ad_hominem"
    STRAW_MAN = "straw_man"
    APPEAL_TO_AUTHORITY = "appeal_to_authority"
    HASTY_GENERALIZATION = "hasty_generalization"
    POST_HOC = "post_hoc"


class Severity(Enum):
    """Severity levels."""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


@dataclass
class BiasDetection:
    """A detected bias."""
    bias_id: str
    bias_type: BiasType
    description_ar: str
    location: str
    severity: Severity
    evidence: str
    suggestion_ar: str
    confidence: float = 0.5
    
    def to_dict(self) -> dict:
        return {
            "bias_id": self.bias_id, "bias_type": self.bias_type.value,
            "description_ar": self.description_ar, "location": self.location,
            "severity": self.severity.value, "evidence": self.evidence,
            "suggestion_ar": self.suggestion_ar, "confidence": self.confidence,
        }


@dataclass
class LogicalIssue:
    """A detected logical issue."""
    issue_id: str
    fallacy_type: Optional[LogicalFallacy] = None
    description_ar: str = ""
    argument_id: Optional[str] = None
    severity: Severity = Severity.MEDIUM
    correction_ar: Optional[str] = None
    
    def to_dict(self) -> dict:
        return {
            "issue_id": self.issue_id, 
            "fallacy_type": self.fallacy_type.value if self.fallacy_type else None,
            "description_ar": self.description_ar, "argument_id": self.argument_id,
            "severity": self.severity.value, "correction_ar": self.correction_ar,
        }


@dataclass
class MethodologyAudit:
    """Result of methodology audit."""
    audit_id: str
    target_id: str
    target_type: str
    biases_detected: List[BiasDetection] = field(default_factory=list)
    logical_issues: List[LogicalIssue] = field(default_factory=list)
    methodology_score: float = 0.5
    rigor_score: float = 0.5
    recommendations: List[str] = field(default_factory=list)
    passed: bool = False
    
    def to_dict(self) -> dict:
        return {
            "audit_id": self.audit_id, "target_id": self.target_id, "target_type": self.target_type,
            "biases_detected": [b.to_dict() for b in self.biases_detected],
            "logical_issues": [l.to_dict() for l in self.logical_issues],
            "methodology_score": self.methodology_score, "rigor_score": self.rigor_score,
            "recommendations": self.recommendations, "passed": self.passed,
        }


PURIFIER_CONFIG = AgentConfig(
    agent_id="AGT-10-PURIFIER",
    arabic_name="المطهّر",
    layer="Building (Layer 4)",
    autonomy_level=AutonomyLevel.L3_DECIDER,
    llm_model="gemini-1.5-pro",
    temperature=0.3,
    timeout_seconds=120,
)


class PurifierAgent(BaseAgent):
    """Methodology purification and validation agent."""
    
    def __init__(self, config: AgentConfig = PURIFIER_CONFIG):
        super().__init__(config)
        
    def validate_input(self, payload: dict) -> tuple[bool, Optional[str]]:
        if "action" not in payload:
            return False, "Missing required field: action"
        action = payload.get("action")
        valid_actions = ["detect_bias", "validate_logic", "audit_methodology", "purify"]
        if action not in valid_actions:
            return False, f"Invalid action: {action}"
        return True, None
    
    def validate_output(self, result: AgentResult) -> tuple[bool, Optional[str]]:
        return True, None
    
    async def process(self, message: AgentMessage) -> AgentResult:
        action = message.payload.get("action")
        
        if action == "detect_bias":
            return await self._detect_bias(message)
        elif action == "validate_logic":
            return await self._validate_logic(message)
        elif action == "audit_methodology":
            return await self._audit_methodology(message)
        elif action == "purify":
            return await self._purify(message)
        
        return AgentResult(success=False, error=f"Unknown action: {action}")
    
    async def _detect_bias(self, message: AgentMessage) -> AgentResult:
        """Detect biases in content."""
        content = message.payload.get("content", "")
        content_type = message.payload.get("content_type", "theory")
        
        self.logger.info(f"Detecting bias in {content_type}")
        
        biases = []
        
        # TODO: Implement actual bias detection using LLM
        bias_checks = [
            (BiasType.CONFIRMATION, "تحيز تأكيدي محتمل"),
            (BiasType.PRESENTISM, "إسقاط معاصر على النص القديم"),
        ]
        
        for bias_type, desc in bias_checks:
            # Placeholder detection
            if content:
                bias = BiasDetection(
                    bias_id=f"BIAS-{uuid.uuid4().hex[:8].upper()}",
                    bias_type=bias_type,
                    description_ar=desc,
                    location="general",
                    severity=Severity.MEDIUM,
                    evidence="تحليل آلي",
                    suggestion_ar="مراجعة المنهجية",
                    confidence=0.6,
                )
                biases.append(bias)
                break  # Only add one for placeholder
        
        return AgentResult(
            success=True,
            output={"biases": [b.to_dict() for b in biases]},
            confidence=0.7,
            metadata={"bias_count": len(biases)},
        )
    
    async def _validate_logic(self, message: AgentMessage) -> AgentResult:
        """Validate logical consistency."""
        arguments = message.payload.get("arguments", [])
        
        issues = []
        
        # TODO: Implement actual logic validation
        for i, arg in enumerate(arguments[:3]):
            if not arg.get("evidence_ids"):
                issue = LogicalIssue(
                    issue_id=f"LOG-{uuid.uuid4().hex[:8].upper()}",
                    fallacy_type=LogicalFallacy.HASTY_GENERALIZATION,
                    description_ar="حجة بدون دليل كافٍ",
                    argument_id=arg.get("argument_id"),
                    severity=Severity.HIGH,
                    correction_ar="إضافة أدلة داعمة",
                )
                issues.append(issue)
        
        return AgentResult(
            success=True,
            output={"logical_issues": [i.to_dict() for i in issues]},
            confidence=0.75,
        )
    
    async def _audit_methodology(self, message: AgentMessage) -> AgentResult:
        """Perform full methodology audit."""
        target_id = message.payload.get("target_id")
        target_type = message.payload.get("target_type", "theory")
        content = message.payload.get("content", {})
        
        self.logger.info(f"Auditing methodology for {target_type}: {target_id}")
        
        # Detect biases
        biases = []
        bias = BiasDetection(
            bias_id=f"BIAS-{uuid.uuid4().hex[:8].upper()}",
            bias_type=BiasType.SELECTION,
            description_ar="احتمال تحيز في اختيار المصادر",
            location="sources",
            severity=Severity.LOW,
            evidence="تحليل أولي",
            suggestion_ar="توسيع نطاق المصادر",
            confidence=0.5,
        )
        biases.append(bias)
        
        # Check logical issues
        logical_issues = []
        
        # Calculate scores
        methodology_score = 0.8 - (len(biases) * 0.1)
        rigor_score = 0.75
        
        audit = MethodologyAudit(
            audit_id=f"AUDIT-{uuid.uuid4().hex[:8].upper()}",
            target_id=target_id,
            target_type=target_type,
            biases_detected=biases,
            logical_issues=logical_issues,
            methodology_score=methodology_score,
            rigor_score=rigor_score,
            recommendations=["مراجعة المصادر", "تعزيز الأدلة"],
            passed=methodology_score >= 0.7 and rigor_score >= 0.7,
        )
        
        return AgentResult(
            success=True, output=audit, confidence=audit.methodology_score,
            metadata={"passed": audit.passed},
        )
    
    async def _purify(self, message: AgentMessage) -> AgentResult:
        """Purify content by addressing detected issues."""
        content = message.payload.get("content", {})
        audit_id = message.payload.get("audit_id")
        
        purified = {
            "purification_id": f"PUR-{uuid.uuid4().hex[:8].upper()}",
            "original_audit_id": audit_id,
            "issues_addressed": 0,
            "remaining_issues": 0,
            "purified_content": content,
            "changes_made": [],
        }
        
        return AgentResult(
            success=True, output=purified, confidence=0.8,
        )
