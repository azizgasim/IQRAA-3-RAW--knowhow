"""
Base Agent Class for IQRA System v1.3
=====================================
All agents inherit from this base class.
Provides standardized interfaces, validation, and error handling.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Optional, Dict, List
from enum import Enum
import uuid
import logging
import asyncio

logger = logging.getLogger(__name__)


class AutonomyLevel(Enum):
    """
    Agent autonomy levels.
    
    L1: Follows instructions exactly, no deviation
    L2: Can suggest alternatives, waits for approval
    L3: Makes decisions within defined scope
    L4: Can initiate new directions and propose changes
    """
    L1_EXECUTOR = 1
    L2_ADVISOR = 2
    L3_DECIDER = 3
    L4_INITIATOR = 4


class AgentState(Enum):
    """Agent lifecycle states."""
    IDLE = "idle"
    PROCESSING = "processing"
    WAITING_GATE = "waiting_gate"
    WAITING_HUMAN = "waiting_human"
    ERROR = "error"
    COMPLETED = "completed"


@dataclass
class AgentConfig:
    """Configuration for an agent."""
    agent_id: str
    arabic_name: str
    layer: str
    autonomy_level: AutonomyLevel
    llm_model: Optional[str] = None
    temperature: float = 0.3
    max_tokens: int = 8192
    timeout_seconds: int = 60
    max_retries: int = 3
    enabled: bool = True
    
    # v1.3: Additional config
    require_human_review: bool = False
    confidence_threshold: float = 0.7
    cache_ttl_seconds: int = 3600


@dataclass
class AgentMessage:
    """Standard message format for inter-agent communication."""
    message_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    run_id: str = ""
    session_id: str = ""
    from_agent: str = ""
    to_agent: str = ""
    message_type: str = "request"  # request/response/event/error
    payload: Dict[str, Any] = field(default_factory=dict)
    timestamp: datetime = field(default_factory=datetime.utcnow)
    correlation_id: str = ""
    trace_id: str = ""
    parent_message_id: Optional[str] = None
    priority: int = 5  # 1-10, 1 = highest
    
    def to_dict(self) -> dict:
        """Convert to dictionary for serialization."""
        return {
            "message_id": self.message_id,
            "run_id": self.run_id,
            "session_id": self.session_id,
            "from_agent": self.from_agent,
            "to_agent": self.to_agent,
            "message_type": self.message_type,
            "payload": self.payload,
            "timestamp": self.timestamp.isoformat(),
            "correlation_id": self.correlation_id,
            "trace_id": self.trace_id,
            "parent_message_id": self.parent_message_id,
            "priority": self.priority,
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> "AgentMessage":
        """Create from dictionary."""
        data = data.copy()
        if isinstance(data.get("timestamp"), str):
            data["timestamp"] = datetime.fromisoformat(data["timestamp"])
        return cls(**data)


@dataclass
class AgentResult:
    """Standard result format from agent execution."""
    success: bool
    output: Any = None
    error: Optional[str] = None
    error_code: Optional[str] = None
    confidence: float = 1.0
    metadata: Dict[str, Any] = field(default_factory=dict)
    latency_ms: int = 0
    tokens_used: int = 0
    cost_usd: float = 0.0
    
    # v1.3: Additional fields
    requires_human_review: bool = False
    review_reason: Optional[str] = None
    gate_results: Dict[str, Any] = field(default_factory=dict)
    cache_hit: bool = False
    
    def to_dict(self) -> dict:
        """Convert to dictionary for serialization."""
        return {
            "success": self.success,
            "output": self.output if not hasattr(self.output, 'to_dict') else self.output.to_dict(),
            "error": self.error,
            "error_code": self.error_code,
            "confidence": self.confidence,
            "metadata": self.metadata,
            "latency_ms": self.latency_ms,
            "tokens_used": self.tokens_used,
            "cost_usd": self.cost_usd,
            "requires_human_review": self.requires_human_review,
            "review_reason": self.review_reason,
            "gate_results": self.gate_results,
            "cache_hit": self.cache_hit,
        }


@dataclass
class GateCheckpoint:
    """Result of a gate check."""
    gate_id: str
    passed: bool
    score: float
    checks: List[Dict[str, Any]]
    timestamp: datetime = field(default_factory=datetime.utcnow)
    message: Optional[str] = None


class BaseAgent(ABC):
    """
    Abstract base class for all IQRA agents.
    
    Every agent must implement:
    - process(): Main processing logic
    - validate_input(): Input validation
    - validate_output(): Output validation
    
    v1.3 additions:
    - Human-in-the-loop support
    - Confidence-based routing
    - Error learning integration
    """
    
    def __init__(self, config: AgentConfig):
        self.config = config
        self.agent_id = config.agent_id
        self.arabic_name = config.arabic_name
        self.logger = logging.getLogger(f"iqra.agents.{config.agent_id}")
        self.state = AgentState.IDLE
        self._error_count = 0
        self._last_error: Optional[str] = None
        
    @abstractmethod
    async def process(self, message: AgentMessage) -> AgentResult:
        """
        Main processing method.
        
        Args:
            message: Input message with payload
            
        Returns:
            AgentResult with output or error
        """
        pass
    
    @abstractmethod
    def validate_input(self, payload: dict) -> tuple[bool, Optional[str]]:
        """
        Validate input payload.
        
        Args:
            payload: Input data to validate
            
        Returns:
            Tuple of (is_valid, error_message)
        """
        pass
    
    @abstractmethod
    def validate_output(self, result: AgentResult) -> tuple[bool, Optional[str]]:
        """
        Validate output result.
        
        Args:
            result: Output to validate
            
        Returns:
            Tuple of (is_valid, error_message)
        """
        pass
    
    async def execute(self, message: AgentMessage) -> AgentResult:
        """
        Execute agent with validation and error handling.
        
        This wraps process() with:
        - Input/output validation
        - Error handling and retry logic
        - Latency tracking
        - Human review flagging
        """
        start_time = datetime.utcnow()
        self.state = AgentState.PROCESSING
        
        try:
            # Validate input
            is_valid, error = self.validate_input(message.payload)
            if not is_valid:
                self.state = AgentState.ERROR
                return AgentResult(
                    success=False,
                    error=f"Input validation failed: {error}",
                    error_code="INPUT_VALIDATION_ERROR"
                )
            
            # Process with retry logic
            result = await self._process_with_retry(message)
            
            # Validate output
            is_valid, error = self.validate_output(result)
            if not is_valid:
                self.logger.warning(f"Output validation failed: {error}")
                result.metadata["validation_warning"] = error
            
            # Check if human review is needed
            result = self._check_human_review(result)
            
            # Calculate latency
            latency = (datetime.utcnow() - start_time).total_seconds() * 1000
            result.latency_ms = int(latency)
            
            self.state = AgentState.COMPLETED
            return result
            
        except asyncio.TimeoutError:
            self.state = AgentState.ERROR
            self._error_count += 1
            return AgentResult(
                success=False,
                error=f"Agent timed out after {self.config.timeout_seconds}s",
                error_code="TIMEOUT_ERROR",
                latency_ms=int((datetime.utcnow() - start_time).total_seconds() * 1000)
            )
            
        except Exception as e:
            self.state = AgentState.ERROR
            self._error_count += 1
            self._last_error = str(e)
            self.logger.error(f"Agent execution failed: {e}", exc_info=True)
            return AgentResult(
                success=False,
                error=str(e),
                error_code="EXECUTION_ERROR",
                latency_ms=int((datetime.utcnow() - start_time).total_seconds() * 1000)
            )
    
    async def _process_with_retry(self, message: AgentMessage) -> AgentResult:
        """Process with retry logic."""
        last_error = None
        
        for attempt in range(self.config.max_retries + 1):
            try:
                self.logger.info(f"Processing message {message.message_id} (attempt {attempt + 1})")
                
                # Apply timeout
                result = await asyncio.wait_for(
                    self.process(message),
                    timeout=self.config.timeout_seconds
                )
                
                if result.success:
                    return result
                    
                last_error = result.error
                
            except asyncio.TimeoutError:
                last_error = "Timeout"
                self.logger.warning(f"Attempt {attempt + 1} timed out")
                
            except Exception as e:
                last_error = str(e)
                self.logger.warning(f"Attempt {attempt + 1} failed: {e}")
            
            if attempt < self.config.max_retries:
                await asyncio.sleep(2 ** attempt)  # Exponential backoff
        
        return AgentResult(
            success=False,
            error=f"All {self.config.max_retries + 1} attempts failed. Last error: {last_error}",
            error_code="MAX_RETRIES_EXCEEDED"
        )
    
    def _check_human_review(self, result: AgentResult) -> AgentResult:
        """
        Check if human review is required.
        
        v1.3 Human-in-the-Loop logic:
        - Confidence < 0.5: Mandatory review
        - Confidence < 0.7: Flagged for review
        - Sensitive topics: Expert review
        """
        if not result.success:
            return result
        
        # Check confidence threshold
        if result.confidence < 0.5:
            result.requires_human_review = True
            result.review_reason = f"Low confidence ({result.confidence:.2f})"
            self.state = AgentState.WAITING_HUMAN
            
        elif result.confidence < self.config.confidence_threshold:
            result.requires_human_review = True
            result.review_reason = f"Below threshold ({result.confidence:.2f} < {self.config.confidence_threshold})"
            
        elif self.config.require_human_review:
            result.requires_human_review = True
            result.review_reason = "Agent configured for mandatory review"
        
        return result
    
    def get_status(self) -> Dict[str, Any]:
        """Get agent status."""
        return {
            "agent_id": self.agent_id,
            "arabic_name": self.arabic_name,
            "state": self.state.value,
            "enabled": self.config.enabled,
            "error_count": self._error_count,
            "last_error": self._last_error,
        }
    
    def reset(self):
        """Reset agent state."""
        self.state = AgentState.IDLE
        self._error_count = 0
        self._last_error = None
    
    def __repr__(self) -> str:
        return f"<{self.__class__.__name__} {self.agent_id} ({self.arabic_name})>"
