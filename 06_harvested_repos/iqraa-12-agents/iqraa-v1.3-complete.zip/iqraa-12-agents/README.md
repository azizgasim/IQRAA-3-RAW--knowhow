# 📚 IQRA - Islamic Qualitative Research Assistant
## نظام إقرأ للبحث الإسلامي النوعي v1.3

---

## 🎯 نظرة عامة

**إقرأ** نظام بحث إسلامي متعدد الوكلاء (11 وكيل) يعتمد على الذكاء الاصطناعي.

## 🤖 الوكلاء

| # | الوكيل | الطبقة | المهمة |
|---|--------|--------|--------|
| 1 | اللغوي | 0 | معالجة اللغة العربية |
| 2 | المنسق | 1 | تنسيق الوكلاء |
| 3 | الحارس | 1 | ضمان الجودة |
| 4 | الخازن | 2 | إدارة البيانات |
| 5 | المحقق | 2 | جمع الأدلة |
| 6 | المحلل | 2 | تحليل المفاهيم |
| 7 | الجينيالوجي | 3 | تتبع الأنساب |
| 8 | الرصّاد | 3 | اكتشاف الأنماط |
| 9 | المنظّر | 4 | بناء النظريات |
| 10 | المطهّر | 4 | تطهير المنهج |
| 11 | المحسّن | 5 | التحسين المستمر |

## 🚀 التشغيل

```bash
pip install -r requirements.txt
python main.py
```

## 📁 الهيكل

```
src/
├── preprocessing/linguist.py
├── core/orchestrator.py, guardian.py
├── understanding/archivist.py, evidencer.py, analyst.py
├── exploration/genealogist.py, scout.py
├── building/theorist.py, purifier.py
└── meta/improver.py
```

---
**عزيز قاسم** | MIT License
