"""
بوابة النظريات (G4) - Theories Gate
فحص جودة البناء النظري
"""

from typing import Dict, Any
from .base_gate import BaseGate, GateResult, GateStatus


class G4TheoriesGate(BaseGate):
    """
    بوابة النظريات - G4
    
    تفحص:
    - تماسك البناء النظري
    - قابلية الاختبار
    - عدم التناقض الداخلي
    """
    
    def __init__(self, threshold: float = 0.75):
        super().__init__(threshold)
        self.name = "G4_Theories"
        self.description = "فحص جودة البناء النظري"
    
    async def validate(self, data: Dict[str, Any]) -> GateResult:
        """فحص النظريات"""
        
        theory = data.get("theory", {})
        hypotheses = data.get("hypotheses", [])
        arguments = data.get("arguments", [])
        
        if not theory and not hypotheses:
            return self._create_result(
                GateStatus.SKIPPED,
                1.0,
                "لا توجد نظريات للفحص",
                {}
            )
        
        score = 0.0
        details = {}
        
        # فحص وجود فرضيات
        if hypotheses:
            score += 0.3
            details["hypotheses_count"] = len(hypotheses)
        
        # فحص وجود حجج داعمة
        if arguments:
            # كل حجة يجب أن تكون لها مقدمة ونتيجة
            valid_args = sum(
                1 for arg in arguments
                if arg.get("premises") and arg.get("conclusion")
            )
            arg_ratio = valid_args / len(arguments) if arguments else 0
            score += arg_ratio * 0.4
            details["valid_arguments"] = f"{arg_ratio:.0%}"
        
        # فحص قابلية الاختبار
        falsifiable = theory.get("falsifiable", False)
        if falsifiable:
            score += 0.3
            details["falsifiable"] = True
        else:
            details["falsifiable"] = False
        
        final_score = min(score, 1.0)
        status = GateStatus.PASSED if final_score >= self.threshold else GateStatus.WARNING
        message = "البناء النظري متماسك" if status == GateStatus.PASSED else "البناء يحتاج تقوية"
        
        return self._create_result(status, final_score, message, details)
