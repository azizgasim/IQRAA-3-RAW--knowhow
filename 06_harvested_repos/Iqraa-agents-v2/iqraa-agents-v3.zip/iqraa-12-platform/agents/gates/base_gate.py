"""
البوابة الأساسية - Base Gate
الصنف الأب لجميع البوابات
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, Optional
from dataclasses import dataclass
from datetime import datetime
from enum import Enum


class GateStatus(str, Enum):
    """حالة البوابة"""
    PASSED = "passed"
    FAILED = "failed"
    WARNING = "warning"
    SKIPPED = "skipped"


@dataclass
class GateResult:
    """نتيجة فحص البوابة"""
    gate_name: str
    status: GateStatus
    score: float  # 0.0 - 1.0
    passed: bool
    message: str
    details: Dict[str, Any]
    timestamp: str = None
    
    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.utcnow().isoformat()


class BaseGate(ABC):
    """
    البوابة الأساسية
    
    كل بوابة يجب أن:
    1. تحدد اسمها ووصفها
    2. تحدد عتبة النجاح
    3. تنفذ دالة validate
    """
    
    def __init__(self, threshold: float = 0.7):
        self.threshold = threshold
        self.name = self.__class__.__name__
        self.description = ""
    
    @abstractmethod
    async def validate(self, data: Dict[str, Any]) -> GateResult:
        """
        فحص البيانات
        
        Args:
            data: البيانات المراد فحصها
            
        Returns:
            GateResult: نتيجة الفحص
        """
        pass
    
    def _create_result(
        self,
        status: GateStatus,
        score: float,
        message: str,
        details: Dict[str, Any] = None
    ) -> GateResult:
        """إنشاء نتيجة"""
        return GateResult(
            gate_name=self.name,
            status=status,
            score=score,
            passed=score >= self.threshold,
            message=message,
            details=details or {}
        )
