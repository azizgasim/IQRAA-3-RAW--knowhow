"""
بوابة التصدير (G5) - Export Gate
الفحص النهائي قبل التصدير - مكافحة الهلوسة
"""

from typing import Dict, Any, List
from .base_gate import BaseGate, GateResult, GateStatus


class G5ExportGate(BaseGate):
    """
    بوابة التصدير - G5
    
    الفحص النهائي:
    - مكافحة الهلوسة
    - التحقق من الاقتباسات
    - فحص درجة الثقة
    - التأكد من الاعتراف بالحدود
    
    مبدأ الجدل J11: "من قال لا أدري فقد أفتى"
    """
    
    def __init__(self, threshold: float = 0.85):
        super().__init__(threshold)
        self.name = "G5_Export"
        self.description = "الفحص النهائي قبل التصدير - مكافحة الهلوسة"
    
    async def validate(self, data: Dict[str, Any]) -> GateResult:
        """الفحص النهائي"""
        
        output = data.get("output", {})
        confidence = data.get("confidence", 0.0)
        claims = data.get("claims", [])
        evidence = data.get("evidence", [])
        limits = data.get("limits", "")
        
        score = 0.0
        details = {}
        issues = []
        
        # ═══════════════════════════════════════════════════════
        # 1. فحص درجة الثقة
        # ═══════════════════════════════════════════════════════
        if confidence >= 0.7:
            score += 0.25
            details["confidence"] = f"{confidence:.0%} (جيدة)"
        elif confidence >= 0.5:
            score += 0.15
            details["confidence"] = f"{confidence:.0%} (متوسطة)"
            issues.append("الثقة متوسطة - يُنصح بمزيد من التحقق")
        else:
            score += 0.05
            details["confidence"] = f"{confidence:.0%} (منخفضة)"
            issues.append("الثقة منخفضة - يجب الاعتراف بالجهل")
        
        # ═══════════════════════════════════════════════════════
        # 2. فحص تغطية الأدلة للادعاءات
        # ═══════════════════════════════════════════════════════
        if claims:
            if evidence:
                coverage = len(evidence) / len(claims)
                if coverage >= 1.0:
                    score += 0.25
                    details["evidence_coverage"] = "كاملة"
                elif coverage >= 0.7:
                    score += 0.15
                    details["evidence_coverage"] = f"{coverage:.0%}"
                else:
                    score += 0.05
                    details["evidence_coverage"] = f"{coverage:.0%} (ناقصة)"
                    issues.append("بعض الادعاءات بدون أدلة كافية")
            else:
                details["evidence_coverage"] = "لا توجد أدلة!"
                issues.append("ادعاءات بدون أدلة - خطر هلوسة")
        else:
            score += 0.25  # لا ادعاءات = لا مشكلة
            details["claims"] = "لا توجد ادعاءات"
        
        # ═══════════════════════════════════════════════════════
        # 3. فحص الاعتراف بالحدود (J11, J12)
        # ═══════════════════════════════════════════════════════
        if limits:
            score += 0.25
            details["limits_acknowledged"] = True
        else:
            if confidence < 0.9:
                issues.append("لم يُذكر حدود المعرفة رغم عدم اليقين")
            details["limits_acknowledged"] = False
        
        # ═══════════════════════════════════════════════════════
        # 4. فحص الاقتباسات
        # ═══════════════════════════════════════════════════════
        quotes = data.get("quotes", [])
        if quotes:
            verified_quotes = data.get("verified_quotes", len(quotes))
            if verified_quotes == len(quotes):
                score += 0.25
                details["quotes_verified"] = "كل الاقتباسات موثقة"
            else:
                ratio = verified_quotes / len(quotes)
                score += ratio * 0.25
                details["quotes_verified"] = f"{ratio:.0%}"
                if ratio < 1.0:
                    issues.append("بعض الاقتباسات غير موثقة")
        else:
            score += 0.25  # لا اقتباسات = لا مشكلة
            details["quotes"] = "لا توجد اقتباسات"
        
        # ═══════════════════════════════════════════════════════
        # النتيجة النهائية
        # ═══════════════════════════════════════════════════════
        final_score = min(score, 1.0)
        details["issues"] = issues
        
        if final_score >= self.threshold:
            status = GateStatus.PASSED
            message = "✅ جاهز للتصدير"
        elif final_score >= 0.6:
            status = GateStatus.WARNING
            message = "⚠️ يمكن التصدير مع تحفظات"
        else:
            status = GateStatus.FAILED
            message = "❌ غير جاهز للتصدير - خطر هلوسة"
        
        return self._create_result(status, final_score, message, details)
    
    async def check_hallucination_risk(
        self,
        claims: List[Dict],
        evidence: List[Dict]
    ) -> Dict[str, Any]:
        """
        فحص خطر الهلوسة
        
        يكتشف:
        - ادعاءات بدون أدلة
        - ثقة عالية بدون مصادر
        - تناقضات
        """
        
        risk_score = 0.0
        risks = []
        
        # ادعاءات بدون أدلة
        unsupported = []
        for i, claim in enumerate(claims):
            has_evidence = any(
                e.get("supports_claim") == i or claim.get("id") in str(e)
                for e in evidence
            )
            if not has_evidence:
                unsupported.append(claim)
                risk_score += 0.2
        
        if unsupported:
            risks.append({
                "type": "unsupported_claims",
                "count": len(unsupported),
                "severity": "high"
            })
        
        return {
            "risk_score": min(risk_score, 1.0),
            "risks": risks,
            "is_safe": risk_score < 0.3
        }
