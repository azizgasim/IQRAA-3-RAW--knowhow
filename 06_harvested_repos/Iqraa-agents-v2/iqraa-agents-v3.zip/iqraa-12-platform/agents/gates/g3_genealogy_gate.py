"""
بوابة الجينيالوجيا (G3) - Genealogy Gate
فحص صحة التتبع التاريخي للأفكار
"""

from typing import Dict, Any
from .base_gate import BaseGate, GateResult, GateStatus


class G3GenealogyGate(BaseGate):
    """
    بوابة الجينيالوجيا - G3
    
    تفحص:
    - صحة السلسلة التاريخية
    - دقة الإسناد
    - اتصال التأثيرات
    """
    
    def __init__(self, threshold: float = 0.7):
        super().__init__(threshold)
        self.name = "G3_Genealogy"
        self.description = "فحص صحة التتبع التاريخي"
    
    async def validate(self, data: Dict[str, Any]) -> GateResult:
        """فحص الجينيالوجيا"""
        
        timeline = data.get("timeline", [])
        influences = data.get("influences", [])
        attributions = data.get("attributions", [])
        
        if not timeline and not influences:
            return self._create_result(
                GateStatus.SKIPPED,
                1.0,
                "لا يوجد تتبع تاريخي للفحص",
                {}
            )
        
        score = 0.0
        details = {}
        
        # فحص التسلسل الزمني
        if timeline:
            # التحقق من الترتيب الزمني
            is_ordered = all(
                timeline[i].get("date", 0) <= timeline[i+1].get("date", 0)
                for i in range(len(timeline)-1)
            ) if len(timeline) > 1 else True
            
            score += 0.4 if is_ordered else 0.1
            details["timeline_ordered"] = is_ordered
            details["timeline_length"] = len(timeline)
        
        # فحص التأثيرات
        if influences:
            # كل تأثير يجب أن يكون له مصدر ومتأثر
            valid_influences = sum(
                1 for inf in influences
                if inf.get("source") and inf.get("target")
            )
            influence_ratio = valid_influences / len(influences)
            score += influence_ratio * 0.3
            details["valid_influences"] = f"{influence_ratio:.0%}"
        
        # فحص الإسناد
        if attributions:
            score += 0.3
            details["attributions_count"] = len(attributions)
        
        final_score = min(score, 1.0)
        status = GateStatus.PASSED if final_score >= self.threshold else GateStatus.WARNING
        message = "التتبع صحيح" if status == GateStatus.PASSED else "التتبع يحتاج تدقيق"
        
        return self._create_result(status, final_score, message, details)
