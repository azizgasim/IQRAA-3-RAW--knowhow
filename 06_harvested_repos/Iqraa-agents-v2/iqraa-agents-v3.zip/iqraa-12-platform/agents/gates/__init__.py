"""
IQRAA Gates Package
حزمة البوابات - 6 بوابات للجودة والحوكمة

G0 - Input Gate: فحص المدخلات اللغوية
G1 - Evidence Gate: فحص الأدلة والمصادر
G2 - Concepts Gate: فحص المفاهيم والتعريفات
G3 - Genealogy Gate: فحص التتبع التاريخي
G4 - Theories Gate: فحص البناء النظري
G5 - Export Gate: الفحص النهائي ومكافحة الهلوسة
"""

from .base_gate import BaseGate, GateResult, GateStatus
from .g0_input_gate import G0InputGate
from .g1_evidence_gate import G1EvidenceGate
from .g2_concepts_gate import G2ConceptsGate
from .g3_genealogy_gate import G3GenealogyGate
from .g4_theories_gate import G4TheoriesGate
from .g5_export_gate import G5ExportGate

__all__ = [
    # Base
    "BaseGate",
    "GateResult",
    "GateStatus",
    
    # Gates
    "G0InputGate",
    "G1EvidenceGate",
    "G2ConceptsGate",
    "G3GenealogyGate",
    "G4TheoriesGate",
    "G5ExportGate",
]

# تسلسل البوابات الافتراضي
GATE_SEQUENCE = [
    ("G0", G0InputGate),
    ("G1", G1EvidenceGate),
    ("G2", G2ConceptsGate),
    ("G3", G3GenealogyGate),
    ("G4", G4TheoriesGate),
    ("G5", G5ExportGate),
]


def create_gate_pipeline(custom_thresholds: dict = None):
    """
    إنشاء خط أنابيب البوابات
    
    Args:
        custom_thresholds: عتبات مخصصة لكل بوابة
        
    Returns:
        قائمة البوابات المُهيأة
    """
    thresholds = custom_thresholds or {}
    
    gates = []
    for gate_id, gate_class in GATE_SEQUENCE:
        threshold = thresholds.get(gate_id, None)
        if threshold:
            gate = gate_class(threshold=threshold)
        else:
            gate = gate_class()
        gates.append((gate_id, gate))
    
    return gates
