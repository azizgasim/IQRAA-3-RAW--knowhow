"""
بوابة المفاهيم (G2) - Concepts Gate
فحص اتساق المفاهيم والتعريفات
"""

from typing import Dict, Any
from .base_gate import BaseGate, GateResult, GateStatus


class G2ConceptsGate(BaseGate):
    """
    بوابة المفاهيم - G2
    
    تفحص:
    - اتساق التعريفات
    - وضوح المفاهيم
    - عدم التناقض
    """
    
    def __init__(self, threshold: float = 0.75):
        super().__init__(threshold)
        self.name = "G2_Concepts"
        self.description = "فحص اتساق المفاهيم والتعريفات"
    
    async def validate(self, data: Dict[str, Any]) -> GateResult:
        """فحص المفاهيم"""
        
        concepts = data.get("concepts", [])
        definitions = data.get("definitions", {})
        
        if not concepts and not definitions:
            return self._create_result(
                GateStatus.SKIPPED,
                1.0,
                "لا توجد مفاهيم للفحص",
                {}
            )
        
        score = 0.0
        details = {}
        
        # فحص وجود تعريفات
        if definitions:
            defined_ratio = len(definitions) / max(len(concepts), 1)
            score += min(defined_ratio, 1.0) * 0.5
            details["definitions_coverage"] = f"{defined_ratio:.0%}"
        
        # فحص وضوح التعريفات (طول معقول)
        clear_definitions = 0
        for term, definition in definitions.items():
            if 20 <= len(str(definition)) <= 500:
                clear_definitions += 1
        
        if definitions:
            clarity_ratio = clear_definitions / len(definitions)
            score += clarity_ratio * 0.3
            details["clarity_ratio"] = f"{clarity_ratio:.0%}"
        
        # فحص عدم التكرار
        unique_concepts = len(set(concepts))
        if concepts:
            uniqueness = unique_concepts / len(concepts)
            score += uniqueness * 0.2
            details["uniqueness"] = f"{uniqueness:.0%}"
        
        final_score = min(score, 1.0)
        status = GateStatus.PASSED if final_score >= self.threshold else GateStatus.WARNING
        message = "المفاهيم متسقة" if status == GateStatus.PASSED else "المفاهيم تحتاج مراجعة"
        
        return self._create_result(status, final_score, message, details)
