"""
بوابة الإدخال (G0) - Input Gate
فحص جودة المدخلات اللغوية
"""

from typing import Dict, Any
from .base_gate import BaseGate, GateResult, GateStatus


class G0InputGate(BaseGate):
    """
    بوابة الإدخال - G0
    
    تفحص:
    - جودة التحليل الصرفي
    - دقة التشكيل
    - صحة استخراج الكيانات
    """
    
    def __init__(self, threshold: float = 0.8):
        super().__init__(threshold)
        self.name = "G0_Input"
        self.description = "فحص جودة المدخلات اللغوية"
    
    async def validate(self, data: Dict[str, Any]) -> GateResult:
        """فحص المدخلات"""
        
        score = 0.0
        details = {}
        
        # فحص وجود النص
        text = data.get("text", "")
        if not text:
            return self._create_result(
                GateStatus.FAILED,
                0.0,
                "لا يوجد نص للفحص",
                {"error": "missing_text"}
            )
        
        # فحص طول النص
        if len(text) < 10:
            score += 0.2
            details["length_check"] = "قصير جداً"
        elif len(text) > 10000:
            score += 0.5
            details["length_check"] = "طويل"
        else:
            score += 1.0
            details["length_check"] = "مناسب"
        
        # فحص اللغة العربية
        arabic_chars = sum(1 for c in text if '\u0600' <= c <= '\u06FF')
        arabic_ratio = arabic_chars / len(text) if text else 0
        
        if arabic_ratio > 0.5:
            score += 1.0
            details["arabic_ratio"] = f"{arabic_ratio:.0%}"
        else:
            score += 0.3
            details["arabic_ratio"] = f"{arabic_ratio:.0%} (منخفض)"
        
        # فحص التشكيل (وجود حركات)
        diacritics = sum(1 for c in text if '\u064B' <= c <= '\u0652')
        if diacritics > 0:
            score += 0.5
            details["diacritics"] = "موجودة"
        else:
            details["diacritics"] = "غير موجودة"
        
        # الدرجة النهائية
        final_score = min(score / 2.5, 1.0)
        
        status = GateStatus.PASSED if final_score >= self.threshold else GateStatus.FAILED
        message = "المدخلات جيدة" if status == GateStatus.PASSED else "المدخلات تحتاج تحسين"
        
        return self._create_result(status, final_score, message, details)
