"""
بوابة الأدلة (G1) - Evidence Gate
فحص جودة الأدلة والمصادر
"""

from typing import Dict, Any, List
from .base_gate import BaseGate, GateResult, GateStatus


class G1EvidenceGate(BaseGate):
    """
    بوابة الأدلة - G1
    
    تفحص:
    - وجود أدلة للادعاءات
    - جودة المصادر
    - صحة الاقتباسات
    """
    
    def __init__(self, threshold: float = 0.7):
        super().__init__(threshold)
        self.name = "G1_Evidence"
        self.description = "فحص جودة الأدلة والمصادر"
    
    async def validate(self, data: Dict[str, Any]) -> GateResult:
        """فحص الأدلة"""
        
        claims = data.get("claims", [])
        evidence = data.get("evidence", [])
        sources = data.get("sources", [])
        
        if not claims:
            return self._create_result(
                GateStatus.SKIPPED,
                1.0,
                "لا توجد ادعاءات للفحص",
                {}
            )
        
        score = 0.0
        details = {
            "claims_count": len(claims),
            "evidence_count": len(evidence),
            "sources_count": len(sources)
        }
        
        # نسبة الادعاءات المدعومة بأدلة
        if claims and evidence:
            coverage = min(len(evidence) / len(claims), 1.0)
            score += coverage * 0.5
            details["evidence_coverage"] = f"{coverage:.0%}"
        
        # جودة المصادر
        if sources:
            score += 0.3
            details["sources_present"] = True
        
        # فحص الاقتباسات
        quotes = data.get("quotes", [])
        if quotes:
            score += 0.2
            details["quotes_count"] = len(quotes)
        
        final_score = min(score, 1.0)
        status = GateStatus.PASSED if final_score >= self.threshold else GateStatus.FAILED
        message = "الأدلة كافية" if status == GateStatus.PASSED else "الأدلة غير كافية"
        
        return self._create_result(status, final_score, message, details)
