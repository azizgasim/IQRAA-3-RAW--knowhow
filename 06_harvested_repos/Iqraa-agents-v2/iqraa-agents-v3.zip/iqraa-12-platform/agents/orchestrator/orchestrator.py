"""
IQRAA Orchestrator - المنسق الرئيسي
مسؤول عن:
- قراءة نية المستخدم
- توزيع المهام على الوكلاء
- إدارة التدفق والحالة
- التحكم في البوابات
"""

from enum import Enum
from typing import Optional, List, Dict, Any, Callable
from pydantic import BaseModel, Field
from datetime import datetime
import asyncio
import logging
import uuid

from .schemas.messages import (
    Message, MessageType, AgentRole, Priority,
    ProposalMessage, DecisionMessage, Conversation
)
from .protocols.deliberation import (
    DeliberationProtocol, DeliberationState, DeliberationConfig
)

logger = logging.getLogger(__name__)


class TaskType(str, Enum):
    """أنواع المهام"""
    RESEARCH = "research"           # بحث
    ANALYSIS = "analysis"           # تحليل
    VERIFICATION = "verification"   # تحقق
    COMPARISON = "comparison"       # مقارنة
    GENEALOGY = "genealogy"         # تتبع جينيالوجي
    SYNTHESIS = "synthesis"         # تركيب
    CRITIQUE = "critique"           # نقد
    EXPLORATION = "exploration"     # استكشاف


class Dimension(str, Enum):
    """الأبعاد الستة"""
    ESSENCE = "الجوهر"              # What - ماذا
    CONTEXT = "السياق"              # When/Where - متى/أين
    NORMATIVITY = "المعيارية"       # Should - يجب
    RELATIONS = "العلائقية"         # With - مع
    CAUSALITY = "السببية"           # Why - لماذا
    ATTRIBUTION = "الإسناد"         # From - من


class Intent(BaseModel):
    """نية المستخدم المحللة"""
    
    query: str
    task_type: TaskType
    dimensions: List[Dimension]
    dimension_priorities: Dict[str, int] = Field(default_factory=dict)
    required_agents: List[AgentRole]
    complexity: float = Field(default=0.5, ge=0.0, le=1.0)
    estimated_time_seconds: int = 60
    keywords: List[str] = Field(default_factory=list)


class TaskState(str, Enum):
    """حالة المهمة"""
    PENDING = "pending"
    ANALYZING = "analyzing"
    ROUTING = "routing"
    EXECUTING = "executing"
    DELIBERATING = "deliberating"
    REVIEWING = "reviewing"
    COMPLETED = "completed"
    FAILED = "failed"
    ESCALATED = "escalated"


class Task(BaseModel):
    """مهمة"""
    
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    session_id: str
    
    query: str
    intent: Optional[Intent] = None
    state: TaskState = TaskState.PENDING
    
    assigned_agents: List[AgentRole] = Field(default_factory=list)
    current_agent: Optional[AgentRole] = None
    
    results: Dict[str, Any] = Field(default_factory=dict)
    errors: List[str] = Field(default_factory=list)
    
    created_at: datetime = Field(default_factory=datetime.utcnow)
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    
    # التكلفة
    tokens_used: int = 0
    estimated_cost_usd: float = 0.0
    
    # التداول
    deliberation_id: Optional[str] = None


class OrchestratorConfig(BaseModel):
    """إعدادات المنسق"""
    
    # حدود التنفيذ
    max_concurrent_tasks: int = 5
    task_timeout_seconds: int = 300
    max_retries: int = 3
    
    # البوابات
    enable_gates: bool = True
    gate_sequence: List[str] = Field(default_factory=lambda: [
        "G0_Input", "G1_Evidence", "G2_Concepts",
        "G3_Genealogy", "G4_Theories", "G5_Export"
    ])
    
    # التداول
    enable_deliberation: bool = True
    deliberation_config: DeliberationConfig = Field(default_factory=DeliberationConfig)
    
    # التكلفة
    max_cost_per_task_usd: float = 2.0
    cost_warning_threshold: float = 1.5


class Orchestrator:
    """
    المنسق الرئيسي لمنظومة إقرأ
    
    المسؤوليات:
    1. تحليل نية المستخدم
    2. توزيع المهام على الوكلاء
    3. إدارة التدفق
    4. تنسيق التداول
    5. مراقبة البوابات
    """
    
    def __init__(self, config: Optional[OrchestratorConfig] = None):
        self.config = config or OrchestratorConfig()
        self.deliberation_protocol = DeliberationProtocol(self.config.deliberation_config)
        
        # السجلات
        self.active_tasks: Dict[str, Task] = {}
        self.task_history: List[Task] = []
        self.conversations: Dict[str, Conversation] = {}
        
        # الوكلاء المسجلون
        self.registered_agents: Dict[AgentRole, Any] = {}
        
        # البوابات
        self.gates: Dict[str, Any] = {}
        
        logger.info("تم تهيئة المنسق")
    
    # ==================== تحليل النية ====================
    
    async def analyze_intent(self, query: str, context: Optional[Dict] = None) -> Intent:
        """
        تحليل نية المستخدم
        
        يحدد:
        1. نوع المهمة
        2. الأبعاد المطلوبة
        3. الوكلاء اللازمين
        """
        
        # استخراج الكلمات المفتاحية
        keywords = self._extract_keywords(query)
        
        # تحديد نوع المهمة
        task_type = self._detect_task_type(query, keywords)
        
        # تحديد الأبعاد
        dimensions = self._detect_dimensions(query, keywords)
        
        # تحديد الوكلاء
        required_agents = self._map_dimensions_to_agents(dimensions, task_type)
        
        # تقدير التعقيد
        complexity = self._estimate_complexity(query, dimensions, task_type)
        
        intent = Intent(
            query=query,
            task_type=task_type,
            dimensions=dimensions,
            dimension_priorities={d.value: i for i, d in enumerate(dimensions, 1)},
            required_agents=required_agents,
            complexity=complexity,
            estimated_time_seconds=int(complexity * 300),
            keywords=keywords
        )
        
        logger.info(f"تم تحليل النية: {task_type.value}, أبعاد: {len(dimensions)}, وكلاء: {len(required_agents)}")
        
        return intent
    
    def _extract_keywords(self, query: str) -> List[str]:
        """استخراج الكلمات المفتاحية"""
        # تنظيف وتقسيم
        words = query.replace("؟", "").replace("،", "").split()
        
        # إزالة الكلمات الشائعة
        stop_words = {"ما", "من", "في", "على", "إلى", "عن", "هل", "كيف", "لماذا", "أين", "متى"}
        keywords = [w for w in words if w not in stop_words and len(w) > 2]
        
        return keywords
    
    def _detect_task_type(self, query: str, keywords: List[str]) -> TaskType:
        """تحديد نوع المهمة"""
        
        # أنماط لكل نوع
        patterns = {
            TaskType.RESEARCH: ["ابحث", "جد", "اعثر", "ما هو", "من هو"],
            TaskType.ANALYSIS: ["حلل", "فسر", "اشرح", "ما معنى"],
            TaskType.VERIFICATION: ["تحقق", "هل صحيح", "أثبت", "دلل"],
            TaskType.COMPARISON: ["قارن", "الفرق", "أوجه", "بين"],
            TaskType.GENEALOGY: ["تتبع", "أصل", "سلسلة", "تطور"],
            TaskType.SYNTHESIS: ["اجمع", "لخص", "ركب", "استنتج"],
            TaskType.CRITIQUE: ["انقد", "قيم", "راجع", "عيوب"],
            TaskType.EXPLORATION: ["استكشف", "اكتشف", "تعمق"],
        }
        
        query_lower = query.lower()
        
        for task_type, triggers in patterns.items():
            if any(t in query_lower for t in triggers):
                return task_type
        
        # افتراضي: بحث
        return TaskType.RESEARCH
    
    def _detect_dimensions(self, query: str, keywords: List[str]) -> List[Dimension]:
        """تحديد الأبعاد المطلوبة"""
        
        dimensions = []
        query_lower = query.lower()
        
        # أنماط الأبعاد
        dimension_patterns = {
            Dimension.ESSENCE: ["ما هو", "معنى", "تعريف", "مفهوم", "حقيقة"],
            Dimension.CONTEXT: ["متى", "أين", "في عصر", "في زمن", "مكان"],
            Dimension.NORMATIVITY: ["يجب", "حكم", "جائز", "حرام", "مشروع"],
            Dimension.RELATIONS: ["علاقة", "صلة", "ارتباط", "مع", "بين"],
            Dimension.CAUSALITY: ["لماذا", "سبب", "علة", "بسبب", "نتيجة"],
            Dimension.ATTRIBUTION: ["قال", "روى", "نقل", "سند", "مصدر"],
        }
        
        for dimension, triggers in dimension_patterns.items():
            if any(t in query_lower for t in triggers):
                dimensions.append(dimension)
        
        # على الأقل بُعد واحد
        if not dimensions:
            dimensions.append(Dimension.ESSENCE)
        
        return dimensions
    
    def _map_dimensions_to_agents(
        self, 
        dimensions: List[Dimension], 
        task_type: TaskType
    ) -> List[AgentRole]:
        """ربط الأبعاد بالوكلاء"""
        
        # خريطة الأبعاد -> الوكلاء
        dimension_agents = {
            Dimension.ESSENCE: [AgentRole.LINGUIST, AgentRole.ARCHIVIST],
            Dimension.CONTEXT: [AgentRole.ARCHIVIST, AgentRole.ANALYST],
            Dimension.NORMATIVITY: [AgentRole.VERIFIER, AgentRole.PURIFIER],
            Dimension.RELATIONS: [AgentRole.ANALYST, AgentRole.GENEALOGIST],
            Dimension.CAUSALITY: [AgentRole.THEORIST, AgentRole.ANALYST],
            Dimension.ATTRIBUTION: [AgentRole.VERIFIER, AgentRole.GENEALOGIST],
        }
        
        agents = set()
        
        # إضافة وكلاء الأبعاد
        for dim in dimensions:
            agents.update(dimension_agents.get(dim, []))
        
        # وكلاء إلزاميون
        agents.add(AgentRole.ORCHESTRATOR)
        agents.add(AgentRole.GUARDIAN)
        
        return list(agents)
    
    def _estimate_complexity(
        self, 
        query: str, 
        dimensions: List[Dimension],
        task_type: TaskType
    ) -> float:
        """تقدير تعقيد المهمة"""
        
        complexity = 0.3  # أساسي
        
        # عدد الأبعاد
        complexity += len(dimensions) * 0.1
        
        # طول الاستعلام
        if len(query) > 100:
            complexity += 0.1
        if len(query) > 200:
            complexity += 0.1
        
        # نوع المهمة
        complex_types = [TaskType.GENEALOGY, TaskType.SYNTHESIS, TaskType.CRITIQUE]
        if task_type in complex_types:
            complexity += 0.2
        
        return min(complexity, 1.0)
    
    # ==================== إدارة المهام ====================
    
    async def create_task(self, query: str, session_id: str) -> Task:
        """إنشاء مهمة جديدة"""
        
        # تحليل النية
        intent = await self.analyze_intent(query)
        
        task = Task(
            session_id=session_id,
            query=query,
            intent=intent,
            assigned_agents=intent.required_agents
        )
        
        self.active_tasks[task.id] = task
        
        logger.info(f"تم إنشاء مهمة: {task.id}")
        
        return task
    
    async def execute_task(self, task_id: str) -> Dict[str, Any]:
        """تنفيذ مهمة"""
        
        task = self.active_tasks.get(task_id)
        if not task:
            raise ValueError(f"مهمة غير موجودة: {task_id}")
        
        task.state = TaskState.EXECUTING
        task.started_at = datetime.utcnow()
        
        try:
            # 1. تمرير عبر البوابات
            if self.config.enable_gates:
                gate_result = await self._process_gates(task)
                if not gate_result["passed"]:
                    task.state = TaskState.FAILED
                    task.errors.append(gate_result["reason"])
                    return {"success": False, "error": gate_result["reason"]}
            
            # 2. توزيع على الوكلاء
            results = await self._distribute_to_agents(task)
            
            # 3. تداول إذا لزم
            if self.config.enable_deliberation and len(task.assigned_agents) > 2:
                deliberation_result = await self._run_deliberation(task, results)
                results["deliberation"] = deliberation_result
            
            # 4. تجميع النتائج
            final_result = await self._aggregate_results(task, results)
            
            task.state = TaskState.COMPLETED
            task.completed_at = datetime.utcnow()
            task.results = final_result
            
            # نقل للتاريخ
            self.task_history.append(task)
            del self.active_tasks[task_id]
            
            return {"success": True, "result": final_result}
            
        except Exception as e:
            task.state = TaskState.FAILED
            task.errors.append(str(e))
            logger.error(f"فشل تنفيذ المهمة {task_id}: {e}")
            return {"success": False, "error": str(e)}
    
    async def _process_gates(self, task: Task) -> Dict[str, Any]:
        """تمرير المهمة عبر البوابات"""
        
        for gate_name in self.config.gate_sequence:
            gate = self.gates.get(gate_name)
            if gate:
                result = await gate.validate(task)
                if not result.get("passed", True):
                    return {
                        "passed": False,
                        "gate": gate_name,
                        "reason": result.get("reason", "فشل البوابة")
                    }
        
        return {"passed": True}
    
    async def _distribute_to_agents(self, task: Task) -> Dict[str, Any]:
        """توزيع المهمة على الوكلاء"""
        
        results = {}
        
        for agent_role in task.assigned_agents:
            agent = self.registered_agents.get(agent_role)
            if agent:
                task.current_agent = agent_role
                
                try:
                    result = await agent.process(task.query, task.intent)
                    results[agent_role.value] = result
                except Exception as e:
                    logger.error(f"خطأ من الوكيل {agent_role.value}: {e}")
                    results[agent_role.value] = {"error": str(e)}
        
        return results
    
    async def _run_deliberation(
        self, 
        task: Task, 
        agent_results: Dict[str, Any]
    ) -> Dict[str, Any]:
        """تشغيل التداول بين الوكلاء"""
        
        # إنشاء جلسة تداول
        state = await self.deliberation_protocol.start_deliberation(
            task_id=task.id,
            participants=task.assigned_agents,
            initial_context=agent_results
        )
        
        task.deliberation_id = state.id
        
        # محاكاة التداول (في الإنتاج سيكون تفاعلياً)
        # ...
        
        return self.deliberation_protocol.get_deliberation_summary(state)
    
    async def _aggregate_results(
        self, 
        task: Task, 
        results: Dict[str, Any]
    ) -> Dict[str, Any]:
        """تجميع نتائج الوكلاء"""
        
        return {
            "task_id": task.id,
            "query": task.query,
            "intent": task.intent.dict() if task.intent else None,
            "agent_results": results,
            "execution_time_seconds": (
                (task.completed_at or datetime.utcnow()) - task.started_at
            ).total_seconds() if task.started_at else 0,
            "tokens_used": task.tokens_used,
            "cost_usd": task.estimated_cost_usd
        }
    
    # ==================== إدارة الوكلاء ====================
    
    def register_agent(self, role: AgentRole, agent: Any):
        """تسجيل وكيل"""
        self.registered_agents[role] = agent
        logger.info(f"تم تسجيل الوكيل: {role.value}")
    
    def register_gate(self, name: str, gate: Any):
        """تسجيل بوابة"""
        self.gates[name] = gate
        logger.info(f"تم تسجيل البوابة: {name}")
    
    # ==================== الإحصائيات ====================
    
    def get_stats(self) -> Dict[str, Any]:
        """الحصول على إحصائيات المنسق"""
        return {
            "active_tasks": len(self.active_tasks),
            "completed_tasks": len(self.task_history),
            "registered_agents": len(self.registered_agents),
            "registered_gates": len(self.gates),
            "agents": [a.value for a in self.registered_agents.keys()],
            "gates": list(self.gates.keys())
        }
