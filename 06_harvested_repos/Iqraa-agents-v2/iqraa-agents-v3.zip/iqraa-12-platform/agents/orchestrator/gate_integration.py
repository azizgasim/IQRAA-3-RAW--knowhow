"""
ربط البوابات بالمنسق
Gate-Orchestrator Integration

يربط البوابات الست بالمنسق لتشكيل خط أنابيب الجودة
"""

from typing import Dict, Any, List, Optional
from dataclasses import dataclass
from datetime import datetime
import asyncio
import logging

from ..gates import (
    BaseGate, GateResult, GateStatus,
    G0InputGate, G1EvidenceGate, G2ConceptsGate,
    G3GenealogyGate, G4TheoriesGate, G5ExportGate,
    GATE_SEQUENCE
)

logger = logging.getLogger(__name__)


@dataclass
class PipelineResult:
    """نتيجة خط الأنابيب"""
    
    task_id: str
    passed: bool
    overall_score: float
    gate_results: List[GateResult]
    failed_gates: List[str]
    warnings: List[str]
    execution_time_ms: float
    timestamp: str = None
    
    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.utcnow().isoformat()


class GatePipeline:
    """
    خط أنابيب البوابات
    
    يمرر البيانات عبر البوابات الست بالترتيب:
    G0 → G1 → G2 → G3 → G4 → G5
    """
    
    def __init__(
        self,
        custom_thresholds: Dict[str, float] = None,
        fail_fast: bool = False,
        skip_on_warning: bool = False
    ):
        """
        تهيئة خط الأنابيب
        
        Args:
            custom_thresholds: عتبات مخصصة لكل بوابة
            fail_fast: إيقاف عند أول فشل
            skip_on_warning: تخطي البوابات التي تعطي تحذير
        """
        self.fail_fast = fail_fast
        self.skip_on_warning = skip_on_warning
        
        # إنشاء البوابات
        thresholds = custom_thresholds or {}
        self.gates: List[tuple] = []
        
        for gate_id, gate_class in GATE_SEQUENCE:
            threshold = thresholds.get(gate_id)
            gate = gate_class(threshold=threshold) if threshold else gate_class()
            self.gates.append((gate_id, gate))
        
        logger.info(f"تم تهيئة خط الأنابيب مع {len(self.gates)} بوابات")
    
    async def process(
        self,
        task_id: str,
        data: Dict[str, Any]
    ) -> PipelineResult:
        """
        معالجة البيانات عبر جميع البوابات
        
        Args:
            task_id: معرف المهمة
            data: البيانات المراد فحصها
            
        Returns:
            PipelineResult: نتيجة خط الأنابيب
        """
        
        start_time = datetime.utcnow()
        
        gate_results = []
        failed_gates = []
        warnings = []
        total_score = 0.0
        
        for gate_id, gate in self.gates:
            try:
                # تنفيذ الفحص
                result = await gate.validate(data)
                gate_results.append(result)
                total_score += result.score
                
                # تسجيل النتيجة
                logger.info(
                    f"[{task_id}] {gate_id}: {result.status.value} "
                    f"({result.score:.0%}) - {result.message}"
                )
                
                # التعامل مع الفشل
                if result.status == GateStatus.FAILED:
                    failed_gates.append(gate_id)
                    if self.fail_fast:
                        logger.warning(f"[{task_id}] إيقاف عند {gate_id} (fail_fast)")
                        break
                
                # التعامل مع التحذيرات
                elif result.status == GateStatus.WARNING:
                    warnings.append(f"{gate_id}: {result.message}")
                    if self.skip_on_warning:
                        continue
                
            except Exception as e:
                logger.error(f"[{task_id}] خطأ في {gate_id}: {e}")
                failed_gates.append(gate_id)
                gate_results.append(GateResult(
                    gate_name=gate_id,
                    status=GateStatus.FAILED,
                    score=0.0,
                    passed=False,
                    message=f"خطأ: {str(e)}",
                    details={"error": str(e)}
                ))
                
                if self.fail_fast:
                    break
        
        # حساب النتيجة النهائية
        end_time = datetime.utcnow()
        execution_time = (end_time - start_time).total_seconds() * 1000
        
        overall_score = total_score / len(self.gates) if self.gates else 0.0
        passed = len(failed_gates) == 0
        
        return PipelineResult(
            task_id=task_id,
            passed=passed,
            overall_score=overall_score,
            gate_results=gate_results,
            failed_gates=failed_gates,
            warnings=warnings,
            execution_time_ms=execution_time
        )
    
    async def process_with_jadal(
        self,
        task_id: str,
        data: Dict[str, Any],
        jadal_enforcer
    ) -> PipelineResult:
        """
        معالجة مع تطبيق مبادئ الجدل
        
        يضيف فحص الامتثال لمبادئ الجدل قبل التصدير
        """
        
        # تشغيل البوابات العادية
        result = await self.process(task_id, data)
        
        # فحص الامتثال للجدل قبل G5
        if result.passed and jadal_enforcer:
            output_message = {
                "content": data.get("output", {}).get("text", ""),
                "confidence": data.get("confidence", 0.0),
                "type": "FINAL_OUTPUT",
                "purpose": "INFORM"
            }
            
            is_valid, reason, suggestions = jadal_enforcer.validate_before_send(
                output_message,
                "export_pipeline",
                {"task_id": task_id}
            )
            
            if not is_valid:
                result.passed = False
                result.failed_gates.append("JADAL_CHECK")
                result.warnings.append(f"مخالفة جدلية: {reason}")
        
        return result
    
    def get_gate(self, gate_id: str) -> Optional[BaseGate]:
        """الحصول على بوابة بمعرفها"""
        for gid, gate in self.gates:
            if gid == gate_id:
                return gate
        return None
    
    def get_statistics(self) -> Dict[str, Any]:
        """إحصائيات خط الأنابيب"""
        return {
            "gates_count": len(self.gates),
            "gates": [gid for gid, _ in self.gates],
            "fail_fast": self.fail_fast,
            "skip_on_warning": self.skip_on_warning
        }


class OrchestratorGateIntegration:
    """
    تكامل المنسق مع البوابات
    
    يوفر واجهة موحدة للمنسق للتعامل مع البوابات
    """
    
    def __init__(self, orchestrator, pipeline: GatePipeline = None):
        self.orchestrator = orchestrator
        self.pipeline = pipeline or GatePipeline()
        
        # تسجيل البوابات في المنسق
        for gate_id, gate in self.pipeline.gates:
            orchestrator.register_gate(gate_id, gate)
    
    async def validate_task_input(
        self,
        task_id: str,
        query: str,
        context: Dict[str, Any] = None
    ) -> GateResult:
        """
        فحص مدخلات المهمة (G0)
        """
        gate = self.pipeline.get_gate("G0")
        if gate:
            return await gate.validate({
                "text": query,
                "context": context or {}
            })
        return None
    
    async def validate_task_output(
        self,
        task_id: str,
        output: Dict[str, Any]
    ) -> GateResult:
        """
        فحص مخرجات المهمة (G5)
        """
        gate = self.pipeline.get_gate("G5")
        if gate:
            return await gate.validate(output)
        return None
    
    async def run_full_pipeline(
        self,
        task_id: str,
        data: Dict[str, Any]
    ) -> PipelineResult:
        """
        تشغيل خط الأنابيب الكامل
        """
        return await self.pipeline.process(task_id, data)
    
    def get_gate_status(self) -> Dict[str, str]:
        """
        حالة جميع البوابات
        """
        return {
            gate_id: "active" for gate_id, _ in self.pipeline.gates
        }


# دالة مساعدة للإنشاء السريع
def create_integrated_orchestrator(orchestrator_config=None):
    """
    إنشاء منسق متكامل مع البوابات
    """
    from ..orchestrator import Orchestrator, OrchestratorConfig
    
    config = orchestrator_config or OrchestratorConfig()
    orchestrator = Orchestrator(config)
    
    pipeline = GatePipeline()
    integration = OrchestratorGateIntegration(orchestrator, pipeline)
    
    return orchestrator, integration
