"""
IQRAA Message Schema
نموذج الرسائل للتواصل بين الوكلاء

Based on Wooldridge's Communication Acts:
- كل رسالة لها نوع محدد
- كل رسالة تحمل مبرراً
- كل رسالة لها أثر متوقع
"""

from enum import Enum
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime
import uuid


class MessageType(str, Enum):
    """أنواع الرسائل - Communication Acts"""
    PROPOSE = "propose"      # اقتراح حل أو مسار
    OBJECT = "object"        # اعتراض مبرر
    REFINE = "refine"        # تنقيح أو تحسين
    ESCALATE = "escalate"    # إحالة لسلطة أعلى
    DECIDE = "decide"        # قرار نهائي
    INFORM = "inform"        # إخبار بمعلومة
    REQUEST = "request"      # طلب مساعدة
    CONFIRM = "confirm"      # تأكيد استلام/موافقة
    REJECT = "reject"        # رفض مبرر


class Priority(str, Enum):
    """أولوية الرسالة"""
    LOW = "low"
    NORMAL = "normal"
    HIGH = "high"
    CRITICAL = "critical"


class AgentRole(str, Enum):
    """أدوار الوكلاء"""
    ORCHESTRATOR = "orchestrator"    # المنسق
    GUARDIAN = "guardian"            # الحارس
    LINGUIST = "linguist"            # اللغوي
    ARCHIVIST = "archivist"          # الخازن
    VERIFIER = "verifier"            # المحقق
    ANALYST = "analyst"              # المحلل
    GENEALOGIST = "genealogist"      # الجينيالوجي
    OBSERVER = "observer"            # الرصّاد
    THEORIST = "theorist"            # المنظّر
    PURIFIER = "purifier"            # المطهّر
    IMPROVER = "improver"            # المحسّن


class Message(BaseModel):
    """نموذج الرسالة الأساسي"""
    
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    type: MessageType
    from_agent: AgentRole
    to_agent: AgentRole
    
    # المحتوى
    content: str
    data: Optional[Dict[str, Any]] = None
    
    # السياق
    task_id: str
    session_id: str
    parent_message_id: Optional[str] = None
    
    # المبرر والأثر
    justification: str = Field(..., description="سبب إرسال هذه الرسالة")
    expected_effect: str = Field(..., description="الأثر المتوقع من هذه الرسالة")
    
    # البيانات الوصفية
    priority: Priority = Priority.NORMAL
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    ttl_seconds: int = Field(default=300, description="مدة صلاحية الرسالة بالثواني")
    
    # التتبع
    confidence: float = Field(default=0.0, ge=0.0, le=1.0)
    evidence_refs: List[str] = Field(default_factory=list)
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }


class ProposalMessage(Message):
    """رسالة اقتراح"""
    type: MessageType = MessageType.PROPOSE
    
    proposal_content: str
    alternatives: List[str] = Field(default_factory=list)
    pros: List[str] = Field(default_factory=list)
    cons: List[str] = Field(default_factory=list)


class ObjectionMessage(Message):
    """رسالة اعتراض"""
    type: MessageType = MessageType.OBJECT
    
    objection_reason: str
    evidence_against: List[str] = Field(default_factory=list)
    suggested_alternative: Optional[str] = None


class RefinementMessage(Message):
    """رسالة تنقيح"""
    type: MessageType = MessageType.REFINE
    
    original_content: str
    refined_content: str
    changes_made: List[str] = Field(default_factory=list)
    improvement_score: float = Field(default=0.0, ge=0.0, le=1.0)


class EscalationMessage(Message):
    """رسالة إحالة"""
    type: MessageType = MessageType.ESCALATE
    
    escalation_reason: str
    current_state: Dict[str, Any] = Field(default_factory=dict)
    attempted_solutions: List[str] = Field(default_factory=list)
    recommended_action: Optional[str] = None


class DecisionMessage(Message):
    """رسالة قرار"""
    type: MessageType = MessageType.DECIDE
    
    decision: str
    rationale: str
    affected_agents: List[AgentRole] = Field(default_factory=list)
    is_final: bool = False
    can_be_appealed: bool = True
    appeal_deadline_seconds: int = Field(default=60)


class MessageEnvelope(BaseModel):
    """غلاف الرسالة للنقل"""
    
    message: Message
    routing_key: str
    retry_count: int = 0
    max_retries: int = 3
    created_at: datetime = Field(default_factory=datetime.utcnow)
    delivered_at: Optional[datetime] = None
    acknowledged_at: Optional[datetime] = None


class Conversation(BaseModel):
    """محادثة كاملة بين الوكلاء"""
    
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    task_id: str
    session_id: str
    
    participants: List[AgentRole]
    messages: List[Message] = Field(default_factory=list)
    
    started_at: datetime = Field(default_factory=datetime.utcnow)
    ended_at: Optional[datetime] = None
    
    status: str = "active"  # active, completed, escalated, timeout
    outcome: Optional[str] = None
    
    def add_message(self, message: Message):
        """إضافة رسالة للمحادثة"""
        self.messages.append(message)
    
    def get_last_message(self) -> Optional[Message]:
        """الحصول على آخر رسالة"""
        return self.messages[-1] if self.messages else None
    
    def get_messages_by_type(self, msg_type: MessageType) -> List[Message]:
        """الحصول على رسائل من نوع معين"""
        return [m for m in self.messages if m.type == msg_type]
    
    def get_messages_from_agent(self, agent: AgentRole) -> List[Message]:
        """الحصول على رسائل وكيل معين"""
        return [m for m in self.messages if m.from_agent == agent]
