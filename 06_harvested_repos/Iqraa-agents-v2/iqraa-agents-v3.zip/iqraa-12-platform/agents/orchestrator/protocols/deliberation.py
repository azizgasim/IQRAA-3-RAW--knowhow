"""
IQRAA Deliberation Protocol
بروتوكول التداول بين الوكلاء

المبادئ:
- التواصل غير المنضبط يقلل الذكاء الجماعي
- كل رسالة لها شروط وأثر ونهاية
- لا حوار مفتوح بلا نهاية
"""

from enum import Enum
from typing import Optional, List, Dict, Any, Callable
from pydantic import BaseModel, Field
from datetime import datetime, timedelta
import asyncio
import logging

from ..schemas.messages import (
    Message, MessageType, AgentRole, Priority,
    ProposalMessage, ObjectionMessage, RefinementMessage,
    EscalationMessage, DecisionMessage, Conversation
)

logger = logging.getLogger(__name__)


class DeliberationPhase(str, Enum):
    """مراحل التداول"""
    PROPOSAL = "proposal"           # مرحلة الاقتراحات
    DISCUSSION = "discussion"       # مرحلة النقاش
    OBJECTION = "objection"         # مرحلة الاعتراضات
    REFINEMENT = "refinement"       # مرحلة التنقيح
    VOTING = "voting"               # مرحلة التصويت
    DECISION = "decision"           # مرحلة القرار
    CLOSED = "closed"               # مغلق


class DeliberationRule(BaseModel):
    """قاعدة تداول"""
    
    name: str
    phase: DeliberationPhase
    condition: str  # وصف الشرط
    action: str     # وصف الإجراء
    priority: int = 0


class DeliberationConfig(BaseModel):
    """إعدادات التداول"""
    
    # الحدود الزمنية
    max_duration_seconds: int = 300  # 5 دقائق كحد أقصى
    phase_timeout_seconds: int = 60   # دقيقة لكل مرحلة
    
    # حدود الرسائل
    max_messages_per_agent: int = 5
    max_total_messages: int = 30
    max_objections: int = 3
    max_refinements: int = 3
    
    # قواعد التصويت
    min_agreement_ratio: float = 0.6  # 60% للموافقة
    quorum_ratio: float = 0.5         # 50% نصاب
    
    # الإحالة
    auto_escalate_on_timeout: bool = True
    auto_escalate_on_deadlock: bool = True


class DeliberationState(BaseModel):
    """حالة التداول"""
    
    id: str
    task_id: str
    phase: DeliberationPhase = DeliberationPhase.PROPOSAL
    
    participants: List[AgentRole]
    proposals: List[ProposalMessage] = Field(default_factory=list)
    objections: List[ObjectionMessage] = Field(default_factory=list)
    refinements: List[RefinementMessage] = Field(default_factory=list)
    votes: Dict[str, bool] = Field(default_factory=dict)  # agent_id -> vote
    
    started_at: datetime = Field(default_factory=datetime.utcnow)
    phase_started_at: datetime = Field(default_factory=datetime.utcnow)
    
    message_count: Dict[str, int] = Field(default_factory=dict)  # agent -> count
    
    final_decision: Optional[DecisionMessage] = None
    outcome: Optional[str] = None


class DeliberationProtocol:
    """
    بروتوكول التداول الرئيسي
    
    يدير:
    - تسلسل المراحل
    - صلاحيات التحدث
    - حل الخلافات
    - اتخاذ القرار
    """
    
    def __init__(self, config: Optional[DeliberationConfig] = None):
        self.config = config or DeliberationConfig()
        self.rules: List[DeliberationRule] = self._init_rules()
        self._message_handlers: Dict[MessageType, Callable] = {}
        
    def _init_rules(self) -> List[DeliberationRule]:
        """تهيئة قواعد التداول"""
        return [
            DeliberationRule(
                name="proposal_required",
                phase=DeliberationPhase.PROPOSAL,
                condition="لا يوجد اقتراح",
                action="انتظار اقتراح من وكيل معتمد",
                priority=10
            ),
            DeliberationRule(
                name="objection_limit",
                phase=DeliberationPhase.OBJECTION,
                condition=f"عدد الاعتراضات > {self.config.max_objections}",
                action="إغلاق مرحلة الاعتراضات والانتقال للتنقيح",
                priority=8
            ),
            DeliberationRule(
                name="timeout_escalation",
                phase=DeliberationPhase.DISCUSSION,
                condition="تجاوز المهلة الزمنية",
                action="إحالة للمنسق لاتخاذ قرار",
                priority=9
            ),
            DeliberationRule(
                name="deadlock_resolution",
                phase=DeliberationPhase.VOTING,
                condition="تعادل الأصوات",
                action="إحالة للحارس أو المنسق",
                priority=10
            ),
            DeliberationRule(
                name="consensus_reached",
                phase=DeliberationPhase.VOTING,
                condition=f"نسبة الموافقة >= {self.config.min_agreement_ratio}",
                action="اعتماد القرار وإغلاق التداول",
                priority=10
            ),
        ]
    
    async def start_deliberation(
        self, 
        task_id: str,
        participants: List[AgentRole],
        initial_context: Dict[str, Any]
    ) -> DeliberationState:
        """بدء جلسة تداول جديدة"""
        
        state = DeliberationState(
            id=f"delib_{task_id}_{datetime.utcnow().strftime('%Y%m%d%H%M%S')}",
            task_id=task_id,
            participants=participants,
            message_count={agent.value: 0 for agent in participants}
        )
        
        logger.info(f"بدء تداول جديد: {state.id}")
        return state
    
    def can_send_message(
        self, 
        state: DeliberationState, 
        agent: AgentRole,
        message_type: MessageType
    ) -> tuple[bool, str]:
        """
        التحقق من صلاحية الوكيل لإرسال رسالة
        
        Returns:
            (allowed, reason)
        """
        # التحقق من المشاركة
        if agent not in state.participants:
            return False, "الوكيل ليس مشاركاً في هذا التداول"
        
        # التحقق من حد الرسائل
        agent_count = state.message_count.get(agent.value, 0)
        if agent_count >= self.config.max_messages_per_agent:
            return False, f"تجاوز الحد الأقصى للرسائل ({self.config.max_messages_per_agent})"
        
        # التحقق من المرحلة
        phase_allowed = self._check_phase_permission(state.phase, message_type)
        if not phase_allowed:
            return False, f"نوع الرسالة غير مسموح في المرحلة {state.phase.value}"
        
        # التحقق من المهلة
        if self._is_phase_timeout(state):
            return False, "انتهت المهلة الزمنية للمرحلة"
        
        return True, "مسموح"
    
    def _check_phase_permission(
        self, 
        phase: DeliberationPhase, 
        message_type: MessageType
    ) -> bool:
        """التحقق من صلاحية نوع الرسالة في المرحلة"""
        
        permissions = {
            DeliberationPhase.PROPOSAL: [MessageType.PROPOSE, MessageType.INFORM],
            DeliberationPhase.DISCUSSION: [MessageType.INFORM, MessageType.REQUEST, MessageType.REFINE],
            DeliberationPhase.OBJECTION: [MessageType.OBJECT, MessageType.CONFIRM],
            DeliberationPhase.REFINEMENT: [MessageType.REFINE, MessageType.PROPOSE],
            DeliberationPhase.VOTING: [MessageType.CONFIRM, MessageType.REJECT],
            DeliberationPhase.DECISION: [MessageType.DECIDE],
            DeliberationPhase.CLOSED: [],
        }
        
        return message_type in permissions.get(phase, [])
    
    def _is_phase_timeout(self, state: DeliberationState) -> bool:
        """التحقق من انتهاء مهلة المرحلة"""
        elapsed = (datetime.utcnow() - state.phase_started_at).total_seconds()
        return elapsed > self.config.phase_timeout_seconds
    
    def _is_deliberation_timeout(self, state: DeliberationState) -> bool:
        """التحقق من انتهاء مهلة التداول"""
        elapsed = (datetime.utcnow() - state.started_at).total_seconds()
        return elapsed > self.config.max_duration_seconds
    
    async def process_message(
        self,
        state: DeliberationState,
        message: Message
    ) -> tuple[DeliberationState, Optional[Message]]:
        """
        معالجة رسالة واردة
        
        Returns:
            (updated_state, response_message)
        """
        # التحقق من الصلاحية
        allowed, reason = self.can_send_message(state, message.from_agent, message.type)
        if not allowed:
            logger.warning(f"رسالة مرفوضة من {message.from_agent}: {reason}")
            return state, self._create_rejection(message, reason)
        
        # تحديث العداد
        state.message_count[message.from_agent.value] = \
            state.message_count.get(message.from_agent.value, 0) + 1
        
        # معالجة حسب النوع
        if message.type == MessageType.PROPOSE:
            state.proposals.append(message)
        elif message.type == MessageType.OBJECT:
            state.objections.append(message)
        elif message.type == MessageType.REFINE:
            state.refinements.append(message)
        elif message.type == MessageType.DECIDE:
            state.final_decision = message
            state.phase = DeliberationPhase.CLOSED
        
        # تحديث المرحلة إذا لزم
        state = await self._update_phase(state)
        
        return state, None
    
    async def _update_phase(self, state: DeliberationState) -> DeliberationState:
        """تحديث مرحلة التداول"""
        
        # التحقق من المهلة
        if self._is_deliberation_timeout(state):
            if self.config.auto_escalate_on_timeout:
                state.phase = DeliberationPhase.DECISION
                state.outcome = "timeout_escalation"
            return state
        
        # منطق الانتقال
        if state.phase == DeliberationPhase.PROPOSAL:
            if len(state.proposals) > 0:
                state.phase = DeliberationPhase.DISCUSSION
                state.phase_started_at = datetime.utcnow()
                
        elif state.phase == DeliberationPhase.DISCUSSION:
            if self._is_phase_timeout(state):
                state.phase = DeliberationPhase.OBJECTION
                state.phase_started_at = datetime.utcnow()
                
        elif state.phase == DeliberationPhase.OBJECTION:
            if len(state.objections) >= self.config.max_objections or self._is_phase_timeout(state):
                state.phase = DeliberationPhase.REFINEMENT
                state.phase_started_at = datetime.utcnow()
                
        elif state.phase == DeliberationPhase.REFINEMENT:
            if len(state.refinements) >= self.config.max_refinements or self._is_phase_timeout(state):
                state.phase = DeliberationPhase.VOTING
                state.phase_started_at = datetime.utcnow()
                
        elif state.phase == DeliberationPhase.VOTING:
            if self._check_voting_complete(state):
                state.phase = DeliberationPhase.DECISION
                state.phase_started_at = datetime.utcnow()
        
        return state
    
    def _check_voting_complete(self, state: DeliberationState) -> bool:
        """التحقق من اكتمال التصويت"""
        total_participants = len(state.participants)
        total_votes = len(state.votes)
        
        # التحقق من النصاب
        if total_votes < total_participants * self.config.quorum_ratio:
            return False
        
        return True
    
    def calculate_voting_result(self, state: DeliberationState) -> tuple[bool, float]:
        """
        حساب نتيجة التصويت
        
        Returns:
            (approved, agreement_ratio)
        """
        if not state.votes:
            return False, 0.0
        
        yes_votes = sum(1 for v in state.votes.values() if v)
        total_votes = len(state.votes)
        
        ratio = yes_votes / total_votes
        approved = ratio >= self.config.min_agreement_ratio
        
        return approved, ratio
    
    def _create_rejection(self, original: Message, reason: str) -> Message:
        """إنشاء رسالة رفض"""
        return Message(
            type=MessageType.REJECT,
            from_agent=AgentRole.ORCHESTRATOR,
            to_agent=original.from_agent,
            content=f"تم رفض الرسالة: {reason}",
            task_id=original.task_id,
            session_id=original.session_id,
            parent_message_id=original.id,
            justification="مخالفة قواعد التداول",
            expected_effect="إعلام الوكيل بسبب الرفض"
        )
    
    def get_deliberation_summary(self, state: DeliberationState) -> Dict[str, Any]:
        """الحصول على ملخص التداول"""
        return {
            "id": state.id,
            "task_id": state.task_id,
            "phase": state.phase.value,
            "duration_seconds": (datetime.utcnow() - state.started_at).total_seconds(),
            "participants": [p.value for p in state.participants],
            "proposals_count": len(state.proposals),
            "objections_count": len(state.objections),
            "refinements_count": len(state.refinements),
            "votes": state.votes,
            "outcome": state.outcome,
            "has_decision": state.final_decision is not None
        }
