"""
ربط مبادئ الجدل ببروتوكول التداول
Jadal-Deliberation Integration

يطبق المبادئ الثلاثين على:
- فحص الرسائل قبل الإرسال
- تقييم جودة الحوار
- اكتشاف المخالفات والمغالطات
- توجيه الوكلاء نحو السلوك الأمثل
"""

from typing import Optional, List, Dict, Any, Tuple
from datetime import datetime
import logging

from .jadal_constitution import (
    JADAL_PRINCIPLES,
    FORBIDDEN_FALLACIES,
    PRINCIPLES_BY_CATEGORY,
    JadalEvaluator,
    JadalCompliance,
    PrincipleViolation,
    IGNORANCE_THRESHOLD,
    RELEVANCE_THRESHOLD,
    QUOTE_ACCURACY_THRESHOLD,
    MAX_RECONCILIATION_ATTEMPTS,
)

logger = logging.getLogger(__name__)


class JadalEnforcedDeliberation:
    """
    تداول مُلزَم بمبادئ الجدل
    
    يضيف طبقة من الحوكمة الأخلاقية والمنهجية
    على بروتوكول التداول الأساسي
    """
    
    def __init__(self):
        self.evaluator = JadalEvaluator()
        self.violation_log: List[PrincipleViolation] = []
        self.reconciliation_attempts: Dict[str, int] = {}
    
    # ═══════════════════════════════════════════════════════════════
    # فحص ما قبل الإرسال (Pre-Send Validation)
    # ═══════════════════════════════════════════════════════════════
    
    def validate_before_send(
        self, 
        message: Dict[str, Any],
        sender_id: str,
        context: Dict[str, Any]
    ) -> Tuple[bool, str, List[str]]:
        """
        فحص الرسالة قبل إرسالها
        
        Returns:
            (is_valid, reason, suggestions)
        """
        
        violations = []
        suggestions = []
        
        # ─────────────────────────────────────────────────────────
        # فحص J01: المقصد
        # ─────────────────────────────────────────────────────────
        if message.get("purpose") == "SILENCE_OPPONENT":
            violations.append("J01")
            suggestions.append("غيّر المقصد إلى 'طلب_الحق' أو 'التبيين'")
        
        # ─────────────────────────────────────────────────────────
        # فحص J05: السؤال المجمل
        # ─────────────────────────────────────────────────────────
        if message.get("type") == "REQUEST":
            if self._is_ambiguous_question(message.get("content", "")):
                violations.append("J05")
                suggestions.append("وضّح السؤال قبل الإرسال أو اطلب استفصالاً")
        
        # ─────────────────────────────────────────────────────────
        # فحص J11: الثقة والجهل
        # ─────────────────────────────────────────────────────────
        confidence = message.get("confidence", 1.0)
        content = message.get("content", "")
        
        if confidence < IGNORANCE_THRESHOLD:
            if "لا أدري" not in content and "غير متأكد" not in content:
                violations.append("J11")
                suggestions.append(f"الثقة {confidence:.0%} منخفضة - أضف 'لا أدري' أو 'غير متأكد'")
        
        # ─────────────────────────────────────────────────────────
        # فحص J17: الصلة بالموضوع
        # ─────────────────────────────────────────────────────────
        relevance = message.get("relevance", 1.0)
        if relevance < RELEVANCE_THRESHOLD:
            violations.append("J17")
            suggestions.append(f"الصلة بالموضوع {relevance:.0%} - أعد التركيز على محل النزاع")
        
        # ─────────────────────────────────────────────────────────
        # فحص J18: الاعتراض بلا تبرير
        # ─────────────────────────────────────────────────────────
        if message.get("type") == "OBJECT":
            if not message.get("justification"):
                violations.append("J18")
                suggestions.append("أضف تبريراً للاعتراض - المنع المجرد لا يكفي")
            
            # فحص J19: تحديد موضع الخلل
            if not message.get("flaw_location"):
                violations.append("J19")
                suggestions.append("حدد موضع الخلل بدقة في الحجة المعترض عليها")
        
        # ─────────────────────────────────────────────────────────
        # فحص المغالطات
        # ─────────────────────────────────────────────────────────
        fallacy = self.evaluator.detect_fallacy(message)
        if fallacy:
            violations.append(f"FALLACY:{fallacy}")
            suggestions.append(f"تم اكتشاف مغالطة '{fallacy}' - راجع الحجة")
        
        # ─────────────────────────────────────────────────────────
        # النتيجة
        # ─────────────────────────────────────────────────────────
        is_valid = len(violations) == 0
        
        if not is_valid:
            reason = f"مخالفات: {', '.join(violations)}"
            self._log_violations(violations, sender_id, message, context)
        else:
            reason = "الرسالة متوافقة مع آداب الجدل"
        
        return is_valid, reason, suggestions
    
    # ═══════════════════════════════════════════════════════════════
    # معالجة التعارض (Conflict Resolution)
    # ═══════════════════════════════════════════════════════════════
    
    def handle_conflict(
        self,
        position_a: Dict[str, Any],
        position_b: Dict[str, Any],
        conflict_id: str
    ) -> Dict[str, Any]:
        """
        معالجة التعارض وفق مبادئ الجدل
        
        المبادئ المطبقة:
        - J21: الجمع مقدم على الترجيح
        - J22: التوقف عند تعذر الحسم
        - J24: تحرير محل النزاع
        - J25: التحقق من الخلاف الحقيقي vs اللفظي
        """
        
        result = {
            "conflict_id": conflict_id,
            "resolution_type": None,
            "outcome": None,
            "principles_applied": [],
            "attempts": 0
        }
        
        # ─────────────────────────────────────────────────────────
        # J24: تحرير محل النزاع
        # ─────────────────────────────────────────────────────────
        dispute_point = self._identify_dispute_point(position_a, position_b)
        result["dispute_point"] = dispute_point
        result["principles_applied"].append("J24")
        
        # ─────────────────────────────────────────────────────────
        # J25: فحص الخلاف اللفظي
        # ─────────────────────────────────────────────────────────
        if self._is_verbal_dispute(position_a, position_b):
            result["resolution_type"] = "verbal_clarification"
            result["outcome"] = "الخلاف لفظي - الموقفان متفقان في المعنى"
            result["principles_applied"].append("J25")
            return result
        
        # ─────────────────────────────────────────────────────────
        # J21: محاولة الجمع
        # ─────────────────────────────────────────────────────────
        attempts = self.reconciliation_attempts.get(conflict_id, 0)
        
        if attempts < MAX_RECONCILIATION_ATTEMPTS:
            reconciliation = self._attempt_reconciliation(position_a, position_b)
            self.reconciliation_attempts[conflict_id] = attempts + 1
            result["attempts"] = attempts + 1
            
            if reconciliation["success"]:
                result["resolution_type"] = "reconciliation"
                result["outcome"] = reconciliation["unified_position"]
                result["principles_applied"].append("J21")
                return result
        
        # ─────────────────────────────────────────────────────────
        # J23: الترجيح بقوة الدليل
        # ─────────────────────────────────────────────────────────
        if attempts >= MAX_RECONCILIATION_ATTEMPTS:
            preference = self._prefer_by_evidence_strength(position_a, position_b)
            
            if preference["can_prefer"]:
                result["resolution_type"] = "preference"
                result["outcome"] = preference["preferred_position"]
                result["preference_reason"] = preference["reason"]
                result["principles_applied"].append("J23")
                return result
        
        # ─────────────────────────────────────────────────────────
        # J22: التوقف
        # ─────────────────────────────────────────────────────────
        result["resolution_type"] = "suspension"
        result["outcome"] = "تعذر الحسم - التوقف وطلب مزيد من الأدلة"
        result["principles_applied"].append("J22")
        
        return result
    
    # ═══════════════════════════════════════════════════════════════
    # فحص الاعتراض (Objection Validation)
    # ═══════════════════════════════════════════════════════════════
    
    def validate_objection(
        self,
        objection: Dict[str, Any],
        original_claim: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        فحص صحة الاعتراض
        
        المبادئ المطبقة:
        - J18: المنع المجرد لا يكفي
        - J19: تحديد موضع الخلل
        - J20: إبطال الدليل ≠ إبطال الدعوى
        """
        
        result = {
            "is_valid": True,
            "issues": [],
            "principles_violated": [],
            "quality_score": 100
        }
        
        # J18: هل الاعتراض مبرر؟
        if not objection.get("justification"):
            result["is_valid"] = False
            result["issues"].append("اعتراض بلا تبرير")
            result["principles_violated"].append("J18")
            result["quality_score"] -= 30
        
        # J19: هل حُدد موضع الخلل؟
        if not objection.get("flaw_specification"):
            result["issues"].append("لم يُحدد موضع الخلل بدقة")
            result["principles_violated"].append("J19")
            result["quality_score"] -= 20
        
        # J20: هل يخلط بين الدليل والدعوى؟
        if self._confuses_evidence_with_claim(objection, original_claim):
            result["issues"].append("خلط بين إبطال الدليل وإبطال الدعوى")
            result["principles_violated"].append("J20")
            result["quality_score"] -= 25
        
        return result
    
    # ═══════════════════════════════════════════════════════════════
    # تقييم جودة الحوار (Dialogue Quality Assessment)
    # ═══════════════════════════════════════════════════════════════
    
    def assess_dialogue_quality(
        self,
        messages: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        تقييم شامل لجودة الحوار
        """
        
        assessment = {
            "total_messages": len(messages),
            "overall_score": 0,
            "compliance_level": None,
            "category_scores": {},
            "top_violations": [],
            "recommendations": []
        }
        
        if not messages:
            return assessment
        
        # تقييم كل رسالة
        scores = []
        all_violations = []
        
        for msg in messages:
            eval_result = self.evaluator.evaluate_message(msg)
            scores.append(eval_result["score"])
            all_violations.extend(eval_result["violations"])
        
        # الدرجة الإجمالية
        assessment["overall_score"] = sum(scores) / len(scores)
        
        # مستوى الامتثال
        score = assessment["overall_score"]
        if score >= 90:
            assessment["compliance_level"] = JadalCompliance.EXEMPLARY.value
        elif score >= 70:
            assessment["compliance_level"] = JadalCompliance.COMPLIANT.value
        elif score >= 50:
            assessment["compliance_level"] = JadalCompliance.PARTIAL.value
        else:
            assessment["compliance_level"] = JadalCompliance.VIOLATION.value
        
        # أكثر المخالفات شيوعاً
        violation_counts = {}
        for v in all_violations:
            violation_counts[v] = violation_counts.get(v, 0) + 1
        
        assessment["top_violations"] = sorted(
            violation_counts.items(), 
            key=lambda x: x[1], 
            reverse=True
        )[:5]
        
        # التوصيات
        assessment["recommendations"] = self._generate_recommendations(
            assessment["top_violations"]
        )
        
        return assessment
    
    # ═══════════════════════════════════════════════════════════════
    # الدوال المساعدة
    # ═══════════════════════════════════════════════════════════════
    
    def _is_ambiguous_question(self, question: str) -> bool:
        """فحص غموض السؤال"""
        ambiguous_markers = ["ما رأيك", "ماذا عن", "كيف ترى", "ما الأفضل"]
        specific_markers = ["ما هو", "كم", "متى", "أين", "من قال", "ما الدليل"]
        
        has_ambiguous = any(m in question for m in ambiguous_markers)
        has_specific = any(m in question for m in specific_markers)
        
        return has_ambiguous and not has_specific
    
    def _identify_dispute_point(
        self, 
        pos_a: Dict, 
        pos_b: Dict
    ) -> str:
        """تحديد نقطة الخلاف"""
        claim_a = pos_a.get("claim", "")
        claim_b = pos_b.get("claim", "")
        
        # تحليل بسيط للاختلاف
        words_a = set(claim_a.split())
        words_b = set(claim_b.split())
        
        diff = words_a.symmetric_difference(words_b)
        
        return f"نقطة الخلاف في: {' '.join(diff)}" if diff else "غير محدد"
    
    def _is_verbal_dispute(self, pos_a: Dict, pos_b: Dict) -> bool:
        """فحص ما إذا كان الخلاف لفظياً فقط"""
        # إذا كانت النتائج العملية متطابقة
        outcome_a = pos_a.get("practical_outcome", "")
        outcome_b = pos_b.get("practical_outcome", "")
        
        return outcome_a == outcome_b and outcome_a != ""
    
    def _attempt_reconciliation(
        self, 
        pos_a: Dict, 
        pos_b: Dict
    ) -> Dict[str, Any]:
        """محاولة الجمع بين الموقفين"""
        
        # البحث عن نقاط الاتفاق
        evidence_a = set(pos_a.get("evidence", []))
        evidence_b = set(pos_b.get("evidence", []))
        
        common_evidence = evidence_a & evidence_b
        
        if common_evidence:
            return {
                "success": True,
                "unified_position": {
                    "claim": f"يمكن الجمع بينهما على أساس: {common_evidence}",
                    "common_ground": list(common_evidence)
                }
            }
        
        return {"success": False}
    
    def _prefer_by_evidence_strength(
        self, 
        pos_a: Dict, 
        pos_b: Dict
    ) -> Dict[str, Any]:
        """الترجيح بقوة الدليل"""
        
        strength_a = pos_a.get("evidence_strength", 0)
        strength_b = pos_b.get("evidence_strength", 0)
        
        if abs(strength_a - strength_b) > 0.2:  # فرق معتبر
            if strength_a > strength_b:
                return {
                    "can_prefer": True,
                    "preferred_position": pos_a,
                    "reason": f"قوة الدليل: {strength_a:.0%} vs {strength_b:.0%}"
                }
            else:
                return {
                    "can_prefer": True,
                    "preferred_position": pos_b,
                    "reason": f"قوة الدليل: {strength_b:.0%} vs {strength_a:.0%}"
                }
        
        return {"can_prefer": False, "reason": "الأدلة متقاربة القوة"}
    
    def _confuses_evidence_with_claim(
        self, 
        objection: Dict, 
        claim: Dict
    ) -> bool:
        """فحص الخلط بين الدليل والدعوى"""
        
        target = objection.get("target", "")
        claim_text = claim.get("claim", "")
        evidence_text = claim.get("evidence", "")
        
        # إذا كان الاعتراض يستهدف الدليل لكن يدعي إبطال الدعوى
        targets_evidence = any(e in target for e in evidence_text) if evidence_text else False
        claims_refutation = "باطل" in objection.get("conclusion", "") or "مرفوض" in objection.get("conclusion", "")
        
        return targets_evidence and claims_refutation
    
    def _log_violations(
        self, 
        violations: List[str], 
        agent_id: str,
        message: Dict,
        context: Dict
    ):
        """تسجيل المخالفات"""
        
        for v in violations:
            if v.startswith("FALLACY:"):
                severity = "severe"
                principle_text = FORBIDDEN_FALLACIES.get(v.replace("FALLACY:", ""), {}).get("description", "")
            else:
                severity = "minor" if v in ["J05", "J17"] else "major"
                principle_text = JADAL_PRINCIPLES.get(v, {}).get("arabic", "")
            
            violation = PrincipleViolation(
                principle_id=v,
                principle_text=principle_text,
                violation_type="pre_send_check",
                agent_id=agent_id,
                context=str(context),
                timestamp=datetime.utcnow().isoformat(),
                severity=severity,
                corrective_action=JADAL_PRINCIPLES.get(v, {}).get("violation", "مراجعة")
            )
            
            self.violation_log.append(violation)
            logger.warning(f"مخالفة جدلية: {v} من {agent_id}")
    
    def _generate_recommendations(
        self, 
        top_violations: List[Tuple[str, int]]
    ) -> List[str]:
        """توليد توصيات بناءً على المخالفات"""
        
        recommendations = []
        
        for violation_id, count in top_violations:
            principle = JADAL_PRINCIPLES.get(violation_id, {})
            if principle:
                recommendations.append(
                    f"راجع المبدأ {violation_id}: {principle.get('arabic', '')} "
                    f"(وُجدت {count} مخالفة)"
                )
        
        return recommendations
    
    def get_violation_report(self) -> Dict[str, Any]:
        """تقرير المخالفات"""
        
        return {
            "total_violations": len(self.violation_log),
            "by_severity": {
                "severe": len([v for v in self.violation_log if v.severity == "severe"]),
                "major": len([v for v in self.violation_log if v.severity == "major"]),
                "minor": len([v for v in self.violation_log if v.severity == "minor"]),
            },
            "by_principle": self._group_violations_by_principle(),
            "recent_violations": [
                {
                    "principle": v.principle_id,
                    "agent": v.agent_id,
                    "timestamp": v.timestamp,
                    "severity": v.severity
                }
                for v in self.violation_log[-10:]
            ]
        }
    
    def _group_violations_by_principle(self) -> Dict[str, int]:
        """تجميع المخالفات حسب المبدأ"""
        groups = {}
        for v in self.violation_log:
            groups[v.principle_id] = groups.get(v.principle_id, 0) + 1
        return groups
