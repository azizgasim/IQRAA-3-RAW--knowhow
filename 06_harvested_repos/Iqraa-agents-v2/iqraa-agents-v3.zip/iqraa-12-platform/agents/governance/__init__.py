"""
IQRAA Governance Package
حزمة الحوكمة لمنظومة إقرأ

تشمل:
- دستور الجدل (30 مبدأ تشغيلي)
- ربط الجدل بالتداول
- البوابات والسياسات
"""

from .jadal_constitution import (
    JADAL_PRINCIPLES,
    FORBIDDEN_FALLACIES,
    PRINCIPLES_BY_CATEGORY,
    JadalEvaluator,
    JadalCompliance,
    JadalPurpose,
    get_jadal_summary,
    IGNORANCE_THRESHOLD,
    RELEVANCE_THRESHOLD,
)

from .jadal_integration import (
    JadalEnforcedDeliberation,
)

__all__ = [
    # الجدل
    "JADAL_PRINCIPLES",
    "FORBIDDEN_FALLACIES", 
    "PRINCIPLES_BY_CATEGORY",
    "JadalEvaluator",
    "JadalCompliance",
    "JadalPurpose",
    "JadalEnforcedDeliberation",
    "get_jadal_summary",
    
    # الثوابت
    "IGNORANCE_THRESHOLD",
    "RELEVANCE_THRESHOLD",
]
