"""
اختبار متكامل لمنظومة إقرأ
IQRAA Integration Test

يختبر:
1. دستور الجدل
2. المنسق والتداول
3. البوابات
4. التكامل الكامل
"""

import sys
import os
sys.path.insert(0, '/home/user/iqraa-12-platform')

from datetime import datetime


def print_header(title: str):
    print(f"\n{'='*60}")
    print(f"  {title}")
    print(f"{'='*60}\n")


def print_result(test_name: str, passed: bool, details: str = ""):
    status = "✅ نجح" if passed else "❌ فشل"
    print(f"  {status} | {test_name}")
    if details:
        print(f"       └─ {details}")


def test_jadal_constitution():
    """اختبار دستور الجدل"""
    print_header("🏛️ اختبار دستور الجدل")
    
    results = []
    
    try:
        from agents.governance.jadal_constitution import (
            JADAL_PRINCIPLES,
            FORBIDDEN_FALLACIES,
            PRINCIPLES_BY_CATEGORY,
            JadalEvaluator,
            get_jadal_summary
        )
        
        # اختبار 1: عدد المبادئ
        count = len(JADAL_PRINCIPLES)
        passed = count == 30
        print_result("عدد المبادئ = 30", passed, f"الفعلي: {count}")
        results.append(passed)
        
        # اختبار 2: التصنيفات
        categories = len(PRINCIPLES_BY_CATEGORY)
        passed = categories == 6
        print_result("عدد التصنيفات = 6", passed, f"الفعلي: {categories}")
        results.append(passed)
        
        # اختبار 3: المغالطات
        fallacies = len(FORBIDDEN_FALLACIES)
        passed = fallacies == 6
        print_result("عدد المغالطات = 6", passed, f"الفعلي: {fallacies}")
        results.append(passed)
        
        # اختبار 4: المُقيِّم
        evaluator = JadalEvaluator()
        test_message = {
            "content": "هذا رأيي",
            "confidence": 0.3,
            "relevance": 0.9,
            "type": "PROPOSE",
            "purpose": "SEEK_TRUTH"
        }
        result = evaluator.evaluate_message(test_message)
        passed = "score" in result and "compliance" in result
        print_result("المُقيِّم يعمل", passed, f"الدرجة: {result.get('score', 0)}")
        results.append(passed)
        
        # اختبار 5: مبدأ J11 (الاعتراف بالجهل)
        # ثقة منخفضة بدون "لا أدري" = مخالفة
        passed = "J11" in result.get("violations", [])
        print_result("كشف مخالفة J11 (الثقة المنخفضة)", passed)
        results.append(passed)
        
        # اختبار 6: الملخص
        summary = get_jadal_summary()
        passed = "30 مبدأ" in summary
        print_result("الملخص يعمل", passed)
        results.append(passed)
        
    except Exception as e:
        print_result("استيراد دستور الجدل", False, str(e))
        results.append(False)
    
    return results


def test_jadal_integration():
    """اختبار ربط الجدل بالتداول"""
    print_header("🔗 اختبار ربط الجدل بالتداول")
    
    results = []
    
    try:
        from agents.governance.jadal_integration import JadalEnforcedDeliberation
        
        deliberation = JadalEnforcedDeliberation()
        
        # اختبار 1: فحص رسالة صحيحة
        good_message = {
            "content": "أقترح أن نبحث في المصادر الأولية",
            "confidence": 0.8,
            "relevance": 0.9,
            "type": "PROPOSE",
            "purpose": "SEEK_TRUTH",
            "justification": "لأن المصادر الأولية أوثق"
        }
        is_valid, reason, suggestions = deliberation.validate_before_send(
            good_message, "agent_1", {}
        )
        passed = is_valid
        print_result("رسالة صحيحة تمر", passed, reason)
        results.append(passed)
        
        # اختبار 2: فحص رسالة بمقصد خاطئ
        bad_purpose_message = {
            "content": "سأثبت خطأك",
            "confidence": 0.9,
            "relevance": 0.9,
            "type": "OBJECT",
            "purpose": "SILENCE_OPPONENT",
            "justification": "لإسكاته"
        }
        is_valid, reason, suggestions = deliberation.validate_before_send(
            bad_purpose_message, "agent_2", {}
        )
        passed = not is_valid and "J01" in reason
        print_result("كشف المقصد الخاطئ (J01)", passed, reason[:50])
        results.append(passed)
        
        # اختبار 3: اعتراض بدون تبرير
        no_justification = {
            "content": "أعترض",
            "confidence": 0.7,
            "relevance": 0.8,
            "type": "OBJECT",
            "purpose": "SEEK_TRUTH"
            # لا يوجد justification
        }
        is_valid, reason, suggestions = deliberation.validate_before_send(
            no_justification, "agent_3", {}
        )
        passed = not is_valid and "J18" in reason
        print_result("كشف اعتراض بلا تبرير (J18)", passed, reason[:50])
        results.append(passed)
        
        # اختبار 4: معالجة التعارض
        pos_a = {"claim": "الرأي الأول", "evidence": ["دليل1", "دليل2"], "evidence_strength": 0.8}
        pos_b = {"claim": "الرأي الثاني", "evidence": ["دليل3"], "evidence_strength": 0.5}
        
        conflict_result = deliberation.handle_conflict(pos_a, pos_b, "conflict_1")
        passed = "resolution_type" in conflict_result
        print_result("معالجة التعارض", passed, f"النوع: {conflict_result.get('resolution_type')}")
        results.append(passed)
        
    except Exception as e:
        print_result("استيراد ربط الجدل", False, str(e))
        results.append(False)
    
    return results


def test_orchestrator():
    """اختبار المنسق"""
    print_header("🎯 اختبار المنسق")
    
    results = []
    
    try:
        from agents.orchestrator import (
            Orchestrator,
            OrchestratorConfig,
            TaskType,
            Dimension,
            AgentRole
        )
        
        # اختبار 1: إنشاء المنسق
        config = OrchestratorConfig()
        orchestrator = Orchestrator(config)
        passed = orchestrator is not None
        print_result("إنشاء المنسق", passed)
        results.append(passed)
        
        # اختبار 2: تحليل النية
        import asyncio
        
        async def test_intent():
            intent = await orchestrator.analyze_intent("ما معنى التوحيد في الإسلام؟")
            return intent
        
        intent = asyncio.run(test_intent())
        passed = intent.task_type == TaskType.RESEARCH or intent.task_type == TaskType.ANALYSIS
        print_result("تحليل النية", passed, f"النوع: {intent.task_type.value}")
        results.append(passed)
        
        # اختبار 3: الأبعاد
        passed = len(intent.dimensions) > 0
        dims = [d.value for d in intent.dimensions]
        print_result("استخراج الأبعاد", passed, f"الأبعاد: {dims}")
        results.append(passed)
        
        # اختبار 4: الوكلاء المطلوبين
        passed = len(intent.required_agents) >= 2
        agents = [a.value for a in intent.required_agents]
        print_result("تحديد الوكلاء", passed, f"العدد: {len(agents)}")
        results.append(passed)
        
        # اختبار 5: الإحصائيات
        stats = orchestrator.get_stats()
        passed = "registered_agents" in stats
        print_result("الإحصائيات", passed)
        results.append(passed)
        
    except Exception as e:
        print_result("استيراد المنسق", False, str(e))
        import traceback
        traceback.print_exc()
        results.append(False)
    
    return results


def test_messages():
    """اختبار نموذج الرسائل"""
    print_header("📨 اختبار نموذج الرسائل")
    
    results = []
    
    try:
        from agents.orchestrator.schemas.messages import (
            Message, MessageType, AgentRole, Conversation
        )
        
        # اختبار 1: إنشاء رسالة
        msg = Message(
            type=MessageType.PROPOSE,
            from_agent=AgentRole.ANALYST,
            to_agent=AgentRole.ORCHESTRATOR,
            content="أقترح تحليل النص",
            task_id="task_001",
            session_id="session_001",
            justification="للوصول لفهم أعمق",
            expected_effect="تحسين جودة النتيجة"
        )
        passed = msg.id is not None
        print_result("إنشاء رسالة", passed, f"ID: {msg.id[:8]}...")
        results.append(passed)
        
        # اختبار 2: أنواع الرسائل
        types = list(MessageType)
        passed = len(types) == 9
        print_result("أنواع الرسائل = 9", passed, f"الفعلي: {len(types)}")
        results.append(passed)
        
        # اختبار 3: أدوار الوكلاء
        roles = list(AgentRole)
        passed = len(roles) == 11
        print_result("أدوار الوكلاء = 11", passed, f"الفعلي: {len(roles)}")
        results.append(passed)
        
        # اختبار 4: المحادثة
        conv = Conversation(
            task_id="task_001",
            session_id="session_001",
            participants=[AgentRole.ANALYST, AgentRole.ORCHESTRATOR]
        )
        conv.add_message(msg)
        passed = len(conv.messages) == 1
        print_result("إضافة رسالة للمحادثة", passed)
        results.append(passed)
        
    except Exception as e:
        print_result("استيراد الرسائل", False, str(e))
        results.append(False)
    
    return results


def test_gates():
    """اختبار البوابات"""
    print_header("🚪 اختبار البوابات")
    
    results = []
    
    try:
        # فحص وجود ملفات البوابات
        gates_path = "/home/user/iqraa-12-platform/agents/gates"
        gate_files = [
            "g0_input_gate.py",
            "g1_evidence_gate.py",
            "g2_concepts_gate.py",
            "g3_genealogy_gate.py",
            "g4_theories_gate.py",
            "g5_export_gate.py"
        ]
        
        for gate_file in gate_files:
            full_path = os.path.join(gates_path, gate_file)
            exists = os.path.exists(full_path)
            print_result(f"وجود {gate_file}", exists)
            results.append(exists)
        
    except Exception as e:
        print_result("فحص البوابات", False, str(e))
        results.append(False)
    
    return results


def main():
    """تشغيل جميع الاختبارات"""
    
    print("\n" + "="*60)
    print("  🧪 اختبار متكامل لمنظومة إقرأ")
    print(f"  📅 {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("="*60)
    
    all_results = []
    
    # تشغيل الاختبارات
    all_results.extend(test_jadal_constitution())
    all_results.extend(test_jadal_integration())
    all_results.extend(test_orchestrator())
    all_results.extend(test_messages())
    all_results.extend(test_gates())
    
    # الملخص النهائي
    print_header("📊 الملخص النهائي")
    
    total = len(all_results)
    passed = sum(all_results)
    failed = total - passed
    percentage = (passed / total) * 100 if total > 0 else 0
    
    print(f"  إجمالي الاختبارات: {total}")
    print(f"  ✅ نجح: {passed}")
    print(f"  ❌ فشل: {failed}")
    print(f"  📈 النسبة: {percentage:.1f}%")
    
    if percentage >= 90:
        status = "🎉 ممتاز!"
    elif percentage >= 70:
        status = "👍 جيد"
    elif percentage >= 50:
        status = "⚠️ يحتاج تحسين"
    else:
        status = "❌ يحتاج مراجعة"
    
    print(f"\n  الحالة: {status}")
    print("\n" + "="*60 + "\n")
    
    return percentage >= 70


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
