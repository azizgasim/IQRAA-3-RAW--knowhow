/**
 * Obsidia Store - إدارة الحالة باستخدام Zustand
 */

import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export const useStore = create(
  persist(
    (set, get) => ({
      // ===== UI State =====
      darkMode: false,
      toggleDarkMode: () => set((state) => ({ darkMode: !state.darkMode })),
      
      sidebarOpen: true,
      toggleSidebar: () => set((state) => ({ sidebarOpen: !state.sidebarOpen })),
      
      // ===== Notes State =====
      currentNote: null,
      setCurrentNote: (note) => set({ currentNote: note }),
      
      draftContent: '',
      setDraftContent: (content) => set({ draftContent: content }),
      
      // ===== Search State =====
      searchQuery: '',
      setSearchQuery: (query) => set({ searchQuery: query }),
      
      searchFilters: {
        searchIn: ['notes', 'questions', 'quotations'],
        projectId: null,
        tags: [],
        dateFrom: null,
        dateTo: null,
      },
      setSearchFilters: (filters) => set((state) => ({
        searchFilters: { ...state.searchFilters, ...filters }
      })),
      
      // ===== Project State =====
      currentProject: null,
      setCurrentProject: (project) => set({ currentProject: project }),
      
      // ===== Notifications =====
      pendingReminders: 0,
      setPendingReminders: (count) => set({ pendingReminders: count }),
      
      // ===== Integration =====
      iqraConnected: false,
      setIqraConnected: (connected) => set({ iqraConnected: connected }),
      
      // ===== Cognitive =====
      momentum: {
        score: 0,
        trend: 'stable',
        streak: 0,
      },
      setMomentum: (momentum) => set({ momentum }),
    }),
    {
      name: 'obsidia-storage',
      partialize: (state) => ({
        darkMode: state.darkMode,
        searchFilters: state.searchFilters,
      }),
    }
  )
);
