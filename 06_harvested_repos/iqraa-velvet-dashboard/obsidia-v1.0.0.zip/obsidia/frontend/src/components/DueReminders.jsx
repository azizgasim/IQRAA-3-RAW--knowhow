/**
 * DueReminders - التذكيرات المستحقة
 */

import React from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Bell, Check, Clock } from 'lucide-react';
import toast from 'react-hot-toast';
import { api } from '../services/api';

export default function DueReminders({ reminders }) {
  const queryClient = useQueryClient();

  const completeMutation = useMutation({
    mutationFn: api.completeReminder,
    onSuccess: () => {
      queryClient.invalidateQueries(['reminders']);
      toast.success('تم إكمال التذكير');
    },
  });

  if (!reminders?.length) return null;

  return (
    <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-xl p-6">
      <h3 className="text-lg font-semibold text-yellow-800 dark:text-yellow-200 flex items-center gap-2 mb-4">
        <Bell className="h-5 w-5" />
        تذكيرات مستحقة ({reminders.length})
      </h3>
      <div className="space-y-3">
        {reminders.map((reminder) => (
          <div
            key={reminder.id}
            className="flex items-center justify-between p-3 bg-white dark:bg-gray-800 rounded-lg"
          >
            <div className="flex items-center gap-3">
              <Clock className="h-4 w-4 text-yellow-500" />
              <span className="text-gray-700 dark:text-gray-300">
                {reminder.message}
              </span>
            </div>
            <button
              onClick={() => completeMutation.mutate(reminder.id)}
              disabled={completeMutation.isPending}
              className="p-2 text-green-600 hover:bg-green-50 dark:hover:bg-green-900/30 rounded-lg"
            >
              <Check className="h-4 w-4" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
