/**
 * MomentumCard - بطاقة مؤشر الزخم
 */

import React from 'react';
import { Flame, TrendingUp, TrendingDown, Minus, Award } from 'lucide-react';

export default function MomentumCard({ momentum }) {
  if (!momentum) {
    return (
      <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm animate-pulse">
        <div className="h-20 bg-gray-200 dark:bg-gray-700 rounded"></div>
      </div>
    );
  }

  const trendIcons = {
    rising: TrendingUp,
    stable: Minus,
    declining: TrendingDown,
  };

  const trendColors = {
    rising: 'text-green-500',
    stable: 'text-yellow-500',
    declining: 'text-red-500',
  };

  const TrendIcon = trendIcons[momentum.trend];

  return (
    <div className="bg-gradient-to-br from-orange-500 to-red-500 rounded-xl p-6 text-white">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Flame className="h-6 w-6" />
          <span className="font-medium">الزخم البحثي</span>
        </div>
        <TrendIcon className={`h-5 w-5 ${trendColors[momentum.trend]}`} />
      </div>
      
      <div className="text-4xl font-bold mb-2">
        {momentum.current_score}
        <span className="text-lg font-normal opacity-80 mr-1">نقطة</span>
      </div>
      
      <div className="flex items-center gap-4 text-sm opacity-90">
        <span className="flex items-center gap-1">
          {momentum.streak_days >= 7 && <Award className="h-4 w-4 text-yellow-300" />}
          {momentum.streak_days} يوم متتالي
        </span>
      </div>
    </div>
  );
}
