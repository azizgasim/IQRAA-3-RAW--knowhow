/**
 * NoteCard - بطاقة الملاحظة
 */

import React from 'react';
import { Link } from 'react-router-dom';
import { FileText, Tag, Link2, Clock } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { ar } from 'date-fns/locale';

export default function NoteCard({ note, viewMode = 'grid' }) {
  const timeAgo = formatDistanceToNow(new Date(note.updated_at), {
    addSuffix: true,
    locale: ar,
  });

  if (viewMode === 'list') {
    return (
      <Link
        to={`/notes/${note.id}`}
        className="block bg-white dark:bg-gray-800 rounded-xl p-4 shadow-sm hover:shadow-md transition-all"
      >
        <div className="flex items-start gap-4">
          <div className="p-2 bg-blue-50 dark:bg-blue-900/30 rounded-lg">
            <FileText className="h-5 w-5 text-blue-500" />
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="font-medium text-gray-900 dark:text-white truncate">
              {note.title}
            </h3>
            <p className="text-sm text-gray-500 dark:text-gray-400 line-clamp-1 mt-1">
              {note.content.substring(0, 100)}
            </p>
            <div className="flex items-center gap-4 mt-2 text-xs text-gray-400">
              <span className="flex items-center gap-1">
                <Clock className="h-3 w-3" />
                {timeAgo}
              </span>
              {note.links_count > 0 && (
                <span className="flex items-center gap-1">
                  <Link2 className="h-3 w-3" />
                  {note.links_count}
                </span>
              )}
              {note.tags?.length > 0 && (
                <span className="flex items-center gap-1">
                  <Tag className="h-3 w-3" />
                  {note.tags.length}
                </span>
              )}
            </div>
          </div>
        </div>
      </Link>
    );
  }

  return (
    <Link
      to={`/notes/${note.id}`}
      className="block bg-white dark:bg-gray-800 rounded-xl p-4 shadow-sm hover:shadow-md transition-all group"
    >
      <h3 className="font-medium text-gray-900 dark:text-white truncate group-hover:text-blue-600 transition-colors">
        {note.title}
      </h3>
      <p className="text-sm text-gray-500 dark:text-gray-400 line-clamp-3 mt-2">
        {note.content.substring(0, 150)}
      </p>
      
      {/* Tags */}
      {note.tags?.length > 0 && (
        <div className="flex flex-wrap gap-1 mt-3">
          {note.tags.slice(0, 3).map((tag, i) => (
            <span
              key={i}
              className="px-2 py-0.5 bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 rounded text-xs"
            >
              #{tag}
            </span>
          ))}
          {note.tags.length > 3 && (
            <span className="text-xs text-gray-400">+{note.tags.length - 3}</span>
          )}
        </div>
      )}
      
      {/* Footer */}
      <div className="flex items-center justify-between mt-4 pt-3 border-t border-gray-100 dark:border-gray-700">
        <span className="text-xs text-gray-400 flex items-center gap-1">
          <Clock className="h-3 w-3" />
          {timeAgo}
        </span>
        <div className="flex items-center gap-3 text-xs text-gray-400">
          {note.links_count > 0 && (
            <span className="flex items-center gap-1" title="روابط صادرة">
              <Link2 className="h-3 w-3" />
              {note.links_count}
            </span>
          )}
          {note.backlinks_count > 0 && (
            <span className="flex items-center gap-1 text-green-500" title="روابط واردة">
              <Link2 className="h-3 w-3 rotate-180" />
              {note.backlinks_count}
            </span>
          )}
        </div>
      </div>
    </Link>
  );
}
