/**
 * MarkdownEditor - محرر Markdown بسيط
 */

import React, { useState, useRef, useCallback } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Bold, Italic, Link2, List, Eye, Edit2 } from 'lucide-react';

export default function MarkdownEditor({ value, onChange, placeholder }) {
  const [showPreview, setShowPreview] = useState(false);
  const textareaRef = useRef(null);

  const insertMarkdown = useCallback((before, after = '') => {
    const textarea = textareaRef.current;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selectedText = value.substring(start, end);
    
    const newText = value.substring(0, start) + before + selectedText + after + value.substring(end);
    onChange(newText);

    // إعادة التركيز
    setTimeout(() => {
      textarea.focus();
      textarea.selectionStart = start + before.length;
      textarea.selectionEnd = start + before.length + selectedText.length;
    }, 0);
  }, [value, onChange]);

  const handleKeyDown = useCallback((e) => {
    // Tab للإزاحة
    if (e.key === 'Tab') {
      e.preventDefault();
      insertMarkdown('  ');
    }
    
    // Ctrl+B للعريض
    if (e.ctrlKey && e.key === 'b') {
      e.preventDefault();
      insertMarkdown('**', '**');
    }
    
    // Ctrl+I للمائل
    if (e.ctrlKey && e.key === 'i') {
      e.preventDefault();
      insertMarkdown('*', '*');
    }
  }, [insertMarkdown]);

  return (
    <div className="border border-gray-200 dark:border-gray-700 rounded-lg overflow-hidden">
      {/* Toolbar */}
      <div className="flex items-center justify-between px-3 py-2 bg-gray-50 dark:bg-gray-900 border-b border-gray-200 dark:border-gray-700">
        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={() => insertMarkdown('**', '**')}
            className="p-1.5 rounded hover:bg-gray-200 dark:hover:bg-gray-700"
            title="عريض (Ctrl+B)"
          >
            <Bold className="h-4 w-4" />
          </button>
          <button
            type="button"
            onClick={() => insertMarkdown('*', '*')}
            className="p-1.5 rounded hover:bg-gray-200 dark:hover:bg-gray-700"
            title="مائل (Ctrl+I)"
          >
            <Italic className="h-4 w-4" />
          </button>
          <button
            type="button"
            onClick={() => insertMarkdown('[[', ']]')}
            className="p-1.5 rounded hover:bg-gray-200 dark:hover:bg-gray-700"
            title="رابط ملاحظة [[]]"
          >
            <Link2 className="h-4 w-4" />
          </button>
          <button
            type="button"
            onClick={() => insertMarkdown('\n- ')}
            className="p-1.5 rounded hover:bg-gray-200 dark:hover:bg-gray-700"
            title="قائمة"
          >
            <List className="h-4 w-4" />
          </button>
        </div>
        
        <button
          type="button"
          onClick={() => setShowPreview(!showPreview)}
          className={`flex items-center gap-1 px-2 py-1 rounded text-sm ${
            showPreview 
              ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/30' 
              : 'hover:bg-gray-200 dark:hover:bg-gray-700'
          }`}
        >
          {showPreview ? <Edit2 className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
          {showPreview ? 'تحرير' : 'معاينة'}
        </button>
      </div>

      {/* Editor / Preview */}
      {showPreview ? (
        <div className="p-4 min-h-[300px] prose prose-sm dark:prose-invert max-w-none">
          <ReactMarkdown remarkPlugins={[remarkGfm]}>
            {value || '*لا يوجد محتوى*'}
          </ReactMarkdown>
        </div>
      ) : (
        <textarea
          ref={textareaRef}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={placeholder}
          className="w-full min-h-[300px] p-4 bg-transparent resize-none focus:outline-none font-mono text-sm"
          dir="auto"
        />
      )}
    </div>
  );
}
