/**
 * RecentNotes - آخر الملاحظات
 */

import React from 'react';
import { Link } from 'react-router-dom';
import { FileText, Plus, Clock } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { ar } from 'date-fns/locale';

export default function RecentNotes({ notes }) {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white flex items-center gap-2">
          <FileText className="h-5 w-5 text-blue-500" />
          آخر الملاحظات
        </h3>
        <Link
          to="/notes"
          className="text-sm text-blue-600 hover:text-blue-700"
        >
          عرض الكل
        </Link>
      </div>

      {!notes || notes.length === 0 ? (
        <div className="text-center py-8">
          <FileText className="h-12 w-12 text-gray-300 mx-auto mb-3" />
          <p className="text-gray-500 mb-4">لا توجد ملاحظات</p>
          <Link
            to="/notes/new"
            className="inline-flex items-center gap-2 text-blue-600 hover:text-blue-700"
          >
            <Plus className="h-4 w-4" />
            أضف أول ملاحظة
          </Link>
        </div>
      ) : (
        <div className="space-y-3">
          {notes.map((note) => (
            <Link
              key={note.id}
              to={`/notes/${note.id}`}
              className="block p-3 rounded-lg bg-gray-50 dark:bg-gray-900 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
            >
              <h4 className="font-medium text-gray-900 dark:text-white truncate">
                {note.title}
              </h4>
              <p className="text-sm text-gray-500 dark:text-gray-400 line-clamp-1 mt-1">
                {note.content?.substring(0, 80)}
              </p>
              <p className="text-xs text-gray-400 mt-2 flex items-center gap-1">
                <Clock className="h-3 w-3" />
                {formatDistanceToNow(new Date(note.updated_at), { addSuffix: true, locale: ar })}
              </p>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
