/**
 * Projects - صفحة المشاريع البحثية
 */

import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Plus, FolderOpen, FileText, HelpCircle, MoreVertical } from 'lucide-react';
import toast from 'react-hot-toast';
import { api } from '../services/api';

export default function Projects() {
  const queryClient = useQueryClient();
  const [showNewForm, setShowNewForm] = useState(false);
  const [newProject, setNewProject] = useState({ name: '', description: '', color: '#10B981' });

  const { data: projects, isLoading } = useQuery({
    queryKey: ['projects'],
    queryFn: api.getProjects,
  });

  const createMutation = useMutation({
    mutationFn: api.createProject,
    onSuccess: () => {
      queryClient.invalidateQueries(['projects']);
      toast.success('تم إنشاء المشروع');
      setShowNewForm(false);
      setNewProject({ name: '', description: '', color: '#10B981' });
    },
  });

  const handleCreate = () => {
    if (!newProject.name.trim()) {
      toast.error('اسم المشروع مطلوب');
      return;
    }
    createMutation.mutate(newProject);
  };

  const statusColors = {
    active: 'bg-green-100 text-green-700 dark:bg-green-900/30',
    paused: 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30',
    completed: 'bg-blue-100 text-blue-700 dark:bg-blue-900/30',
    archived: 'bg-gray-100 text-gray-700 dark:bg-gray-700',
  };

  const statusLabels = {
    active: 'نشط',
    paused: 'متوقف',
    completed: 'مكتمل',
    archived: 'مؤرشف',
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
          المشاريع البحثية
        </h1>
        <button
          onClick={() => setShowNewForm(true)}
          className="inline-flex items-center justify-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Plus className="h-4 w-4" />
          مشروع جديد
        </button>
      </div>

      {/* New Project Form */}
      {showNewForm && (
        <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
          <h3 className="text-lg font-semibold mb-4">مشروع جديد</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                اسم المشروع *
              </label>
              <input
                type="text"
                value={newProject.name}
                onChange={(e) => setNewProject({ ...newProject, name: e.target.value })}
                className="w-full px-4 py-2 border border-gray-200 dark:border-gray-700 rounded-lg bg-transparent focus:ring-2 focus:ring-blue-500"
                placeholder="مثال: دراسة تطور مفهوم السببية"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                الوصف
              </label>
              <textarea
                value={newProject.description}
                onChange={(e) => setNewProject({ ...newProject, description: e.target.value })}
                className="w-full px-4 py-2 border border-gray-200 dark:border-gray-700 rounded-lg bg-transparent focus:ring-2 focus:ring-blue-500"
                rows={3}
                placeholder="وصف مختصر للمشروع..."
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                اللون
              </label>
              <input
                type="color"
                value={newProject.color}
                onChange={(e) => setNewProject({ ...newProject, color: e.target.value })}
                className="h-10 w-20 rounded cursor-pointer"
              />
            </div>
            <div className="flex gap-3">
              <button
                onClick={handleCreate}
                disabled={createMutation.isPending}
                className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 disabled:opacity-50"
              >
                {createMutation.isPending ? 'جاري الإنشاء...' : 'إنشاء'}
              </button>
              <button
                onClick={() => setShowNewForm(false)}
                className="px-4 py-2 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Projects List */}
      {isLoading ? (
        <div className="text-center py-12">
          <div className="animate-spin h-8 w-8 border-4 border-blue-500 border-t-transparent rounded-full mx-auto"></div>
        </div>
      ) : projects?.length === 0 ? (
        <div className="text-center py-12 bg-white dark:bg-gray-800 rounded-xl">
          <FolderOpen className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-500 dark:text-gray-400 mb-4">لا توجد مشاريع</p>
          <button
            onClick={() => setShowNewForm(true)}
            className="inline-flex items-center gap-2 text-blue-600 hover:text-blue-700"
          >
            <Plus className="h-4 w-4" />
            أنشئ أول مشروع
          </button>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {projects?.map((project) => (
            <Link
              key={project.id}
              to={`/projects/${project.id}`}
              className="bg-white dark:bg-gray-800 rounded-xl p-5 shadow-sm hover:shadow-md transition-shadow group"
            >
              <div className="flex items-start justify-between mb-3">
                <div
                  className="h-10 w-10 rounded-lg flex items-center justify-center"
                  style={{ backgroundColor: project.color + '20', color: project.color }}
                >
                  <FolderOpen className="h-5 w-5" />
                </div>
                <span className={`text-xs px-2 py-1 rounded-full ${statusColors[project.status]}`}>
                  {statusLabels[project.status]}
                </span>
              </div>
              <h3 className="font-semibold text-gray-900 dark:text-white mb-2 group-hover:text-blue-600 transition-colors">
                {project.name}
              </h3>
              {project.description && (
                <p className="text-sm text-gray-500 dark:text-gray-400 line-clamp-2 mb-4">
                  {project.description}
                </p>
              )}
              <div className="flex items-center gap-4 text-sm text-gray-500 dark:text-gray-400">
                <span className="flex items-center gap-1">
                  <FileText className="h-4 w-4" />
                  {project.notes_count}
                </span>
                <span className="flex items-center gap-1">
                  <HelpCircle className="h-4 w-4" />
                  {project.questions_count}
                </span>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
