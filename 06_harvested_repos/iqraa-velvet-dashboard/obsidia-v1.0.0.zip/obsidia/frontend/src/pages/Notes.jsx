/**
 * Notes - صفحة الملاحظات
 */

import React, { useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { Plus, Search, Filter, Grid, List, Tag } from 'lucide-react';
import { api } from '../services/api';
import NoteCard from '../components/NoteCard';

export default function Notes() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [viewMode, setViewMode] = useState('grid');
  const [showFilters, setShowFilters] = useState(false);

  const filters = {
    project_id: searchParams.get('project'),
    tag: searchParams.get('tag'),
    source: searchParams.get('source'),
  };

  const { data: notes, isLoading } = useQuery({
    queryKey: ['notes', filters],
    queryFn: () => api.getNotes(filters),
  });

  const { data: tags } = useQuery({
    queryKey: ['tags'],
    queryFn: api.getTags,
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
          الملاحظات
        </h1>
        <Link
          to="/notes/new"
          className="inline-flex items-center justify-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Plus className="h-4 w-4" />
          ملاحظة جديدة
        </Link>
      </div>

      {/* Search & Filters */}
      <div className="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-sm">
        <div className="flex flex-col sm:flex-row gap-4">
          {/* Search */}
          <div className="flex-1 relative">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
            <input
              type="text"
              placeholder="ابحث في الملاحظات..."
              className="w-full pr-10 pl-4 py-2 border border-gray-200 dark:border-gray-700 rounded-lg bg-gray-50 dark:bg-gray-900 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          {/* Filter Toggle */}
          <button
            onClick={() => setShowFilters(!showFilters)}
            className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg border transition-colors ${
              showFilters 
                ? 'bg-blue-50 border-blue-200 text-blue-600 dark:bg-blue-900/30'
                : 'border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700'
            }`}
          >
            <Filter className="h-4 w-4" />
            فلترة
          </button>

          {/* View Mode */}
          <div className="flex border border-gray-200 dark:border-gray-700 rounded-lg overflow-hidden">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-2 ${viewMode === 'grid' ? 'bg-gray-100 dark:bg-gray-700' : ''}`}
            >
              <Grid className="h-5 w-5" />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-2 ${viewMode === 'list' ? 'bg-gray-100 dark:bg-gray-700' : ''}`}
            >
              <List className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Expanded Filters */}
        {showFilters && (
          <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
            <div className="flex flex-wrap gap-2">
              <span className="text-sm text-gray-500 dark:text-gray-400 flex items-center gap-1">
                <Tag className="h-4 w-4" />
                الوسوم:
              </span>
              {tags?.map((tag) => (
                <button
                  key={tag.id}
                  onClick={() => setSearchParams({ tag: tag.name })}
                  className={`px-3 py-1 rounded-full text-sm transition-colors ${
                    filters.tag === tag.name
                      ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/50'
                      : 'bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-300 hover:bg-gray-200'
                  }`}
                  style={{ 
                    borderLeft: `3px solid ${tag.color}` 
                  }}
                >
                  #{tag.name}
                </button>
              ))}
              {filters.tag && (
                <button
                  onClick={() => setSearchParams({})}
                  className="px-3 py-1 rounded-full text-sm bg-red-100 text-red-600 dark:bg-red-900/30"
                >
                  مسح الفلتر
                </button>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Notes List */}
      {isLoading ? (
        <div className="text-center py-12">
          <div className="animate-spin h-8 w-8 border-4 border-blue-500 border-t-transparent rounded-full mx-auto"></div>
          <p className="mt-4 text-gray-500">جاري التحميل...</p>
        </div>
      ) : notes?.length === 0 ? (
        <div className="text-center py-12 bg-white dark:bg-gray-800 rounded-xl">
          <p className="text-gray-500 dark:text-gray-400 mb-4">لا توجد ملاحظات</p>
          <Link
            to="/notes/new"
            className="inline-flex items-center gap-2 text-blue-600 hover:text-blue-700"
          >
            <Plus className="h-4 w-4" />
            أضف أول ملاحظة
          </Link>
        </div>
      ) : (
        <div className={viewMode === 'grid' 
          ? 'grid sm:grid-cols-2 lg:grid-cols-3 gap-4' 
          : 'space-y-4'
        }>
          {notes?.map((note) => (
            <NoteCard key={note.id} note={note} viewMode={viewMode} />
          ))}
        </div>
      )}
    </div>
  );
}
