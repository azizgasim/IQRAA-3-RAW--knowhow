/**
 * ProjectDetail - تفاصيل المشروع البحثي
 */

import React, { useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { 
  ArrowRight, FileText, HelpCircle, Flag, Milestone,
  Plus, Check, Clock, Trash2, Edit2
} from 'lucide-react';
import toast from 'react-hot-toast';
import { api } from '../services/api';

export default function ProjectDetail() {
  const { projectId } = useParams();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  
  const [newQuestion, setNewQuestion] = useState('');
  const [showQuestionForm, setShowQuestionForm] = useState(false);

  // جلب المشروع
  const { data: project, isLoading } = useQuery({
    queryKey: ['project', projectId],
    queryFn: () => api.getProject(projectId),
  });

  // جلب الرحلة البحثية
  const { data: journey } = useQuery({
    queryKey: ['journey', projectId],
    queryFn: () => api.getProjectJourney(projectId),
  });

  // إنشاء سؤال
  const createQuestionMutation = useMutation({
    mutationFn: (content) => api.createQuestion(projectId, { content }),
    onSuccess: () => {
      queryClient.invalidateQueries(['journey', projectId]);
      toast.success('تم إضافة السؤال');
      setNewQuestion('');
      setShowQuestionForm(false);
    },
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin h-8 w-8 border-4 border-blue-500 border-t-transparent rounded-full"></div>
      </div>
    );
  }

  if (!project) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500">المشروع غير موجود</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <button
          onClick={() => navigate('/projects')}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-900 dark:text-gray-400"
        >
          <ArrowRight className="h-5 w-5" />
          المشاريع
        </button>
      </div>

      {/* Project Info */}
      <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
        <div className="flex items-start gap-4">
          <div
            className="h-14 w-14 rounded-xl flex items-center justify-center flex-shrink-0"
            style={{ backgroundColor: project.color + '20', color: project.color }}
          >
            <Flag className="h-7 w-7" />
          </div>
          <div className="flex-1">
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
              {project.name}
            </h1>
            {project.description && (
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                {project.description}
              </p>
            )}
            <div className="flex flex-wrap gap-4 text-sm">
              <span className="flex items-center gap-1 text-gray-500">
                <FileText className="h-4 w-4" />
                {project.notes_count} ملاحظة
              </span>
              <span className="flex items-center gap-1 text-gray-500">
                <HelpCircle className="h-4 w-4" />
                {project.questions_count} سؤال
              </span>
              <span className="flex items-center gap-1 text-gray-500">
                <Clock className="h-4 w-4" />
                {new Date(project.created_at).toLocaleDateString('ar-SA')}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Content Grid */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Questions */}
        <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white flex items-center gap-2">
              <HelpCircle className="h-5 w-5 text-yellow-500" />
              الأسئلة البحثية
            </h2>
            <button
              onClick={() => setShowQuestionForm(!showQuestionForm)}
              className="text-sm text-blue-600 hover:text-blue-700 flex items-center gap-1"
            >
              <Plus className="h-4 w-4" />
              سؤال جديد
            </button>
          </div>

          {showQuestionForm && (
            <div className="mb-4 p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
              <textarea
                value={newQuestion}
                onChange={(e) => setNewQuestion(e.target.value)}
                placeholder="اكتب سؤالك البحثي..."
                className="w-full p-3 border border-gray-200 dark:border-gray-700 rounded-lg bg-transparent resize-none"
                rows={3}
              />
              <div className="flex gap-2 mt-2">
                <button
                  onClick={() => createQuestionMutation.mutate(newQuestion)}
                  disabled={!newQuestion.trim() || createQuestionMutation.isPending}
                  className="bg-blue-600 text-white px-3 py-1 rounded text-sm hover:bg-blue-700 disabled:opacity-50"
                >
                  إضافة
                </button>
                <button
                  onClick={() => setShowQuestionForm(false)}
                  className="px-3 py-1 rounded text-sm border border-gray-200 dark:border-gray-700"
                >
                  إلغاء
                </button>
              </div>
            </div>
          )}

          <div className="space-y-3">
            {journey?.questions?.length === 0 ? (
              <p className="text-gray-500 text-sm text-center py-4">
                لا توجد أسئلة بعد
              </p>
            ) : (
              journey?.questions?.map((q) => (
                <QuestionItem key={q.id} question={q} projectId={projectId} />
              ))
            )}
          </div>
        </div>

        {/* Milestones / Journey */}
        <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white flex items-center gap-2">
              <Milestone className="h-5 w-5 text-purple-500" />
              خريطة الرحلة
            </h2>
          </div>

          <div className="space-y-4">
            {journey?.milestones?.length === 0 ? (
              <p className="text-gray-500 text-sm text-center py-4">
                لا توجد نقاط تحول مسجلة
              </p>
            ) : (
              <div className="relative">
                <div className="absolute right-4 top-0 bottom-0 w-0.5 bg-gray-200 dark:bg-gray-700" />
                {journey?.milestones?.map((m, i) => (
                  <div key={m.id} className="relative pr-10 pb-4">
                    <div className="absolute right-2 top-1 h-5 w-5 rounded-full bg-purple-100 dark:bg-purple-900/30 flex items-center justify-center">
                      <div className="h-2 w-2 rounded-full bg-purple-500" />
                    </div>
                    <div className="bg-gray-50 dark:bg-gray-900 rounded-lg p-3">
                      <p className="font-medium text-gray-900 dark:text-white text-sm">
                        {m.title}
                      </p>
                      {m.description && (
                        <p className="text-xs text-gray-500 mt-1">{m.description}</p>
                      )}
                      <p className="text-xs text-gray-400 mt-2">
                        {new Date(m.created_at).toLocaleDateString('ar-SA')}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Recent Notes */}
      <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white flex items-center gap-2">
            <FileText className="h-5 w-5 text-blue-500" />
            آخر الملاحظات
          </h2>
          <Link
            to={`/notes?project=${projectId}`}
            className="text-sm text-blue-600 hover:text-blue-700"
          >
            عرض الكل
          </Link>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {journey?.recent_notes?.map((note) => (
            <Link
              key={note.id}
              to={`/notes/${note.id}`}
              className="p-4 bg-gray-50 dark:bg-gray-900 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
            >
              <p className="font-medium text-gray-900 dark:text-white truncate">
                {note.title}
              </p>
              <p className="text-xs text-gray-500 mt-1">
                {new Date(note.created_at).toLocaleDateString('ar-SA')}
              </p>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}

function QuestionItem({ question, projectId }) {
  const queryClient = useQueryClient();
  
  const statusColors = {
    open: 'bg-yellow-100 text-yellow-700',
    in_progress: 'bg-blue-100 text-blue-700',
    resolved: 'bg-green-100 text-green-700',
    branched: 'bg-purple-100 text-purple-700',
  };

  const resolveMutation = useMutation({
    mutationFn: () => api.updateQuestion(question.id, { status: 'resolved' }),
    onSuccess: () => {
      queryClient.invalidateQueries(['journey', projectId]);
      toast.success('تم حل السؤال');
    },
  });

  return (
    <div className="p-3 bg-gray-50 dark:bg-gray-900 rounded-lg group">
      <div className="flex items-start gap-3">
        <button
          onClick={() => resolveMutation.mutate()}
          disabled={question.status === 'resolved'}
          className={`mt-1 h-5 w-5 rounded border flex-shrink-0 flex items-center justify-center transition-colors ${
            question.status === 'resolved'
              ? 'bg-green-500 border-green-500 text-white'
              : 'border-gray-300 hover:border-green-500 hover:bg-green-50'
          }`}
        >
          {question.status === 'resolved' && <Check className="h-3 w-3" />}
        </button>
        <div className="flex-1">
          <p className={`text-sm ${question.status === 'resolved' ? 'line-through text-gray-400' : 'text-gray-900 dark:text-white'}`}>
            {question.content}
          </p>
          <div className="flex items-center gap-2 mt-2">
            <span className={`text-xs px-2 py-0.5 rounded-full ${statusColors[question.status]}`}>
              {question.status === 'open' ? 'مفتوح' : 
               question.status === 'resolved' ? 'محلول' :
               question.status === 'branched' ? 'متشعب' : 'قيد العمل'}
            </span>
            {question.sub_questions_count > 0 && (
              <span className="text-xs text-gray-500">
                {question.sub_questions_count} سؤال فرعي
              </span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
