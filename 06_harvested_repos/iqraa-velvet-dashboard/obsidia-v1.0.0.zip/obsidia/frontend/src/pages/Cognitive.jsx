/**
 * Cognitive - المرآة المعرفية
 * 
 * تحليل السلوك لا المحتوى
 * فلسفة الذكاء الصامت: 90% صامت | 8% يهمس | 2% ينصح | <1% يُنبّه
 */

import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { 
  Activity, TrendingUp, TrendingDown, Minus,
  Calendar, FileText, Link2, Target, Bell,
  Flame, Award, Lightbulb
} from 'lucide-react';
import { 
  LineChart, Line, XAxis, YAxis, CartesianGrid, 
  Tooltip, ResponsiveContainer, BarChart, Bar 
} from 'recharts';
import { api } from '../services/api';

export default function Cognitive() {
  // جلب الزخم
  const { data: momentum } = useQuery({
    queryKey: ['momentum'],
    queryFn: api.getMomentum,
  });

  // جلب التقرير الأسبوعي
  const { data: weeklyReport } = useQuery({
    queryKey: ['weeklyReport'],
    queryFn: api.getWeeklyReport,
  });

  // جلب الأنماط
  const { data: patterns } = useQuery({
    queryKey: ['patterns'],
    queryFn: api.getCognitivePatterns,
  });

  // جلب التاريخ المعرفي
  const { data: history } = useQuery({
    queryKey: ['cognitiveHistory'],
    queryFn: () => api.getCognitiveHistory(30),
  });

  const trendIcons = {
    rising: TrendingUp,
    stable: Minus,
    declining: TrendingDown,
  };

  const trendColors = {
    rising: 'text-green-500',
    stable: 'text-yellow-500',
    declining: 'text-red-500',
  };

  const trendLabels = {
    rising: 'صاعد',
    stable: 'مستقر',
    declining: 'هابط',
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
          المرآة المعرفية
        </h1>
        <p className="text-sm text-gray-500">
          تحليل السلوك لا المحتوى
        </p>
      </div>

      {/* Momentum Card */}
      <div className="bg-gradient-to-r from-purple-500 to-indigo-600 rounded-2xl p-6 text-white">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Flame className="h-6 w-6" />
            <h2 className="text-lg font-semibold">مؤشر الزخم البحثي</h2>
          </div>
          {momentum && (
            <div className={`flex items-center gap-1 ${trendColors[momentum.trend]} bg-white/20 px-3 py-1 rounded-full`}>
              {React.createElement(trendIcons[momentum.trend], { className: 'h-4 w-4' })}
              <span className="text-sm">{trendLabels[momentum.trend]}</span>
            </div>
          )}
        </div>
        
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div>
            <p className="text-purple-200 text-sm">النقاط</p>
            <p className="text-3xl font-bold">{momentum?.current_score || 0}</p>
          </div>
          <div>
            <p className="text-purple-200 text-sm">أيام النشاط المتتالية</p>
            <p className="text-3xl font-bold flex items-center gap-1">
              {momentum?.streak_days || 0}
              {momentum?.streak_days >= 7 && <Award className="h-5 w-5 text-yellow-300" />}
            </p>
          </div>
          <div>
            <p className="text-purple-200 text-sm">إجمالي الملاحظات</p>
            <p className="text-3xl font-bold">{momentum?.total_notes || 0}</p>
          </div>
          <div>
            <p className="text-purple-200 text-sm">الأسئلة المفتوحة</p>
            <p className="text-3xl font-bold">{momentum?.open_questions || 0}</p>
          </div>
        </div>
      </div>

      {/* Activity Chart */}
      {history?.length > 0 && (
        <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
            <Activity className="h-5 w-5 text-blue-500" />
            نشاط آخر 30 يوم
          </h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={history}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis 
                  dataKey="date" 
                  tick={{ fontSize: 12 }}
                  tickFormatter={(value) => new Date(value).getDate()}
                />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip 
                  labelFormatter={(value) => new Date(value).toLocaleDateString('ar-SA')}
                />
                <Line 
                  type="monotone" 
                  dataKey="notes_created" 
                  stroke="#3B82F6" 
                  name="ملاحظات"
                  strokeWidth={2}
                />
                <Line 
                  type="monotone" 
                  dataKey="links_created" 
                  stroke="#10B981" 
                  name="روابط"
                  strokeWidth={2}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* Weekly Report */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Summary */}
        <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
            <Calendar className="h-5 w-5 text-green-500" />
            ملخص الأسبوع
          </h3>
          {weeklyReport && (
            <div className="space-y-4">
              <div className="grid grid-cols-3 gap-4">
                <div className="text-center p-3 bg-blue-50 dark:bg-blue-900/30 rounded-lg">
                  <FileText className="h-6 w-6 text-blue-500 mx-auto mb-1" />
                  <p className="text-2xl font-bold text-blue-600">{weeklyReport.summary.new_notes}</p>
                  <p className="text-xs text-gray-500">ملاحظة جديدة</p>
                </div>
                <div className="text-center p-3 bg-green-50 dark:bg-green-900/30 rounded-lg">
                  <Link2 className="h-6 w-6 text-green-500 mx-auto mb-1" />
                  <p className="text-2xl font-bold text-green-600">{weeklyReport.summary.new_links}</p>
                  <p className="text-xs text-gray-500">رابط جديد</p>
                </div>
                <div className="text-center p-3 bg-purple-50 dark:bg-purple-900/30 rounded-lg">
                  <Target className="h-6 w-6 text-purple-500 mx-auto mb-1" />
                  <p className="text-2xl font-bold text-purple-600">{weeklyReport.summary.resolved_questions}</p>
                  <p className="text-xs text-gray-500">سؤال محلول</p>
                </div>
              </div>

              {/* Top Tags */}
              {weeklyReport.highlights.top_tags?.length > 0 && (
                <div>
                  <p className="text-sm text-gray-500 mb-2">الوسوم الأكثر استخداماً:</p>
                  <div className="flex flex-wrap gap-2">
                    {weeklyReport.highlights.top_tags.map((tag, i) => (
                      <span
                        key={i}
                        className="px-2 py-1 bg-gray-100 dark:bg-gray-700 rounded text-sm"
                      >
                        #{tag.name} ({tag.count})
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Peak Hours */}
              {weeklyReport.highlights.peak_hours?.length > 0 && (
                <div>
                  <p className="text-sm text-gray-500 mb-2">ساعات الذروة:</p>
                  <p className="text-gray-700 dark:text-gray-300">
                    {weeklyReport.highlights.peak_hours.map(h => `${h}:00`).join(' - ')}
                  </p>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Reflection Prompts */}
        <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
            <Lightbulb className="h-5 w-5 text-yellow-500" />
            أسئلة للتأمل
          </h3>
          <p className="text-xs text-gray-500 mb-4">محفّز لا موجّه</p>
          
          {weeklyReport?.reflection_prompts?.length > 0 ? (
            <div className="space-y-3">
              {weeklyReport.reflection_prompts.map((prompt, i) => (
                <div
                  key={i}
                  className="p-3 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg border-r-4 border-yellow-400"
                >
                  <p className="text-gray-700 dark:text-gray-300">{prompt}</p>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-500 text-center py-4">
              لا توجد اقتراحات حالياً
            </p>
          )}
        </div>
      </div>

      {/* Patterns */}
      {patterns && (
        <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
            أنماط السلوك المعرفي
          </h3>
          
          <div className="grid lg:grid-cols-2 gap-6">
            {/* Note Lengths */}
            {patterns.note_lengths?.length > 0 && (
              <div>
                <p className="text-sm text-gray-500 mb-3">أطوال الملاحظات:</p>
                <div className="h-48">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={patterns.note_lengths}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis 
                        dataKey="length_category"
                        tickFormatter={(v) => v === 'short' ? 'قصيرة' : v === 'medium' ? 'متوسطة' : 'طويلة'}
                      />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="count" fill="#3B82F6" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            )}

            {/* Linking Behavior */}
            <div>
              <p className="text-sm text-gray-500 mb-3">سلوك الربط:</p>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-gray-600 dark:text-gray-400">نسبة الملاحظات المرتبطة</span>
                  <span className="font-semibold text-gray-900 dark:text-white">
                    {patterns.linking_behavior?.linking_rate}%
                  </span>
                </div>
                <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                  <div
                    className="bg-blue-500 h-2 rounded-full"
                    style={{ width: `${patterns.linking_behavior?.linking_rate || 0}%` }}
                  />
                </div>
                
                {patterns.insights?.map((insight, i) => (
                  <p key={i} className="text-sm text-gray-600 dark:text-gray-400 italic">
                    💡 {insight}
                  </p>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Philosophy Note */}
      <div className="text-center py-6 text-sm text-gray-400">
        <p>فلسفة الذكاء الصامت:</p>
        <p>90% صامت | 8% يهمس | 2% ينصح | &lt;1% يُنبّه</p>
      </div>
    </div>
  );
}
