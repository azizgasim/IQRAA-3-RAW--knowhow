/**
 * Settings - صفحة الإعدادات
 */

import React, { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { 
  Moon, Sun, Database, Cloud, Link2, 
  Download, Upload, Trash2, Check, AlertCircle
} from 'lucide-react';
import toast from 'react-hot-toast';
import { api } from '../services/api';
import { useStore } from '../store/useStore';

export default function Settings() {
  const { darkMode, toggleDarkMode } = useStore();
  const [backupInProgress, setBackupInProgress] = useState(false);

  // حالة التكامل
  const { data: integrationStatus } = useQuery({
    queryKey: ['integrationStatus'],
    queryFn: api.getIntegrationStatus,
  });

  // حالة المزامنة
  const { data: syncStatus } = useQuery({
    queryKey: ['syncStatus'],
    queryFn: api.getSyncStatus,
  });

  // إحصائيات البحث
  const { data: searchStats } = useQuery({
    queryKey: ['searchStats'],
    queryFn: api.getSearchStats,
  });

  // نسخ احتياطي محلي
  const backupLocalMutation = useMutation({
    mutationFn: api.backupLocal,
    onSuccess: (data) => {
      toast.success('تم النسخ الاحتياطي بنجاح');
    },
    onError: () => {
      toast.error('فشل النسخ الاحتياطي');
    },
  });

  // تصدير JSON
  const exportMutation = useMutation({
    mutationFn: api.exportToJson,
    onSuccess: (data) => {
      toast.success(`تم التصدير: ${data.stats.notes} ملاحظة`);
    },
  });

  return (
    <div className="space-y-6 max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
        الإعدادات
      </h1>

      {/* Appearance */}
      <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
        <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
          المظهر
        </h2>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            {darkMode ? (
              <Moon className="h-5 w-5 text-indigo-500" />
            ) : (
              <Sun className="h-5 w-5 text-yellow-500" />
            )}
            <span className="text-gray-700 dark:text-gray-300">
              الوضع {darkMode ? 'الداكن' : 'الفاتح'}
            </span>
          </div>
          <button
            onClick={toggleDarkMode}
            className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
              darkMode ? 'bg-indigo-600' : 'bg-gray-300'
            }`}
          >
            <span
              className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                darkMode ? 'translate-x-1' : 'translate-x-6'
              }`}
            />
          </button>
        </div>
      </div>

      {/* Statistics */}
      <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
        <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
          <Database className="h-5 w-5 text-blue-500" />
          إحصائيات المفكرة
        </h2>
        {searchStats && (
          <div className="grid grid-cols-2 gap-4">
            <div className="p-3 bg-gray-50 dark:bg-gray-900 rounded-lg">
              <p className="text-2xl font-bold text-gray-900 dark:text-white">
                {searchStats.total_notes}
              </p>
              <p className="text-sm text-gray-500">ملاحظة</p>
            </div>
            <div className="p-3 bg-gray-50 dark:bg-gray-900 rounded-lg">
              <p className="text-2xl font-bold text-gray-900 dark:text-white">
                {searchStats.total_tags}
              </p>
              <p className="text-sm text-gray-500">وسم</p>
            </div>
            <div className="p-3 bg-gray-50 dark:bg-gray-900 rounded-lg">
              <p className="text-2xl font-bold text-gray-900 dark:text-white">
                {searchStats.total_questions}
              </p>
              <p className="text-sm text-gray-500">سؤال</p>
            </div>
            <div className="p-3 bg-gray-50 dark:bg-gray-900 rounded-lg">
              <p className="text-2xl font-bold text-gray-900 dark:text-white">
                {searchStats.total_quotations}
              </p>
              <p className="text-sm text-gray-500">اقتباس</p>
            </div>
          </div>
        )}
      </div>

      {/* Integration Status */}
      <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
        <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
          <Link2 className="h-5 w-5 text-green-500" />
          التكامل مع إقرأ
        </h2>
        
        {integrationStatus ? (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-gray-600 dark:text-gray-400">حالة الاتصال</span>
              <span className={`flex items-center gap-1 ${
                integrationStatus.connected ? 'text-green-500' : 'text-gray-400'
              }`}>
                {integrationStatus.connected ? (
                  <>
                    <Check className="h-4 w-4" />
                    متصل
                  </>
                ) : (
                  <>
                    <AlertCircle className="h-4 w-4" />
                    غير متصل
                  </>
                )}
              </span>
            </div>
            
            <div className="text-sm text-gray-500 pt-2 border-t border-gray-200 dark:border-gray-700">
              <p className="font-medium mb-2">نقاط التكامل (6 فقط):</p>
              <ul className="space-y-1">
                <li>✓ زر "أضف للمفكرة" من إقرأ</li>
                <li>✓ تحديد نص + "أضف كاقتباس"</li>
                <li>✓ إشعار بانتهاء تحليل</li>
                <li>✓ زر "ابحث في إقرأ"</li>
                <li>✓ زر "اطلب تحليل"</li>
                <li>✓ زر "افتح المصدر"</li>
              </ul>
            </div>
          </div>
        ) : (
          <p className="text-gray-500">جاري التحميل...</p>
        )}
      </div>

      {/* Backup & Sync */}
      <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
        <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
          <Cloud className="h-5 w-5 text-purple-500" />
          النسخ الاحتياطي والمزامنة
        </h2>
        
        {syncStatus && (
          <div className="mb-4 p-3 bg-gray-50 dark:bg-gray-900 rounded-lg">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600 dark:text-gray-400">آخر نسخ احتياطي</span>
              <span className="text-sm text-gray-900 dark:text-white">
                {syncStatus.last_sync 
                  ? new Date(syncStatus.last_sync).toLocaleString('ar-SA')
                  : 'لم يتم بعد'}
              </span>
            </div>
          </div>
        )}

        <div className="space-y-3">
          <button
            onClick={() => backupLocalMutation.mutate()}
            disabled={backupLocalMutation.isPending}
            className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
          >
            <Download className="h-4 w-4" />
            {backupLocalMutation.isPending ? 'جاري النسخ...' : 'نسخ احتياطي محلي'}
          </button>
          
          <button
            onClick={() => exportMutation.mutate()}
            disabled={exportMutation.isPending}
            className="w-full flex items-center justify-center gap-2 px-4 py-2 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700"
          >
            <Upload className="h-4 w-4" />
            {exportMutation.isPending ? 'جاري التصدير...' : 'تصدير JSON'}
          </button>
        </div>

        <p className="text-xs text-gray-500 mt-4 text-center">
          BigQuery للنسخ الاحتياطي فقط - لا تحليل، لا استعلامات معقدة
        </p>
      </div>

      {/* About */}
      <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm text-center">
        <div className="h-16 w-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
          <span className="text-white font-bold text-2xl">O</span>
        </div>
        <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Obsidia</h2>
        <p className="text-sm text-gray-500 mt-1">المفكرة الذكية الشخصية للباحث</p>
        <p className="text-xs text-gray-400 mt-2">الإصدار 1.0.0</p>
        <p className="text-xs text-gray-400 mt-4 italic">
          "ليست عقلاً بل وعياً بالعقل"
        </p>
      </div>
    </div>
  );
}
