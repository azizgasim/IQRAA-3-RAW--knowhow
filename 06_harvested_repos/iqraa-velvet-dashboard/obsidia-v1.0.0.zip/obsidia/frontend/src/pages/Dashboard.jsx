/**
 * Dashboard - لوحة التحكم الرئيسية
 */

import React from 'react';
import { Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { 
  FileText, FolderOpen, HelpCircle, Link2, 
  TrendingUp, Calendar, Bell, Plus 
} from 'lucide-react';
import { api } from '../services/api';
import MomentumCard from '../components/MomentumCard';
import RecentNotes from '../components/RecentNotes';
import DueReminders from '../components/DueReminders';

export default function Dashboard() {
  // جلب الإحصائيات
  const { data: stats } = useQuery({
    queryKey: ['stats'],
    queryFn: api.getStats,
  });

  // جلب الزخم
  const { data: momentum } = useQuery({
    queryKey: ['momentum'],
    queryFn: api.getMomentum,
  });

  // جلب الملاحظات الأخيرة
  const { data: recentNotes } = useQuery({
    queryKey: ['notes', 'recent'],
    queryFn: () => api.getNotes({ limit: 5 }),
  });

  // جلب التذكيرات المستحقة
  const { data: dueReminders } = useQuery({
    queryKey: ['reminders', 'due'],
    queryFn: api.getDueReminders,
  });

  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-blue-500 to-purple-600 rounded-2xl p-6 text-white">
        <h2 className="text-2xl font-bold mb-2">مرحباً بك في Obsidia</h2>
        <p className="text-blue-100 mb-4">مفكرتك الذكية الشخصية - امتداد رقمي لذاكرتك وتفكيرك</p>
        <Link
          to="/notes/new"
          className="inline-flex items-center gap-2 bg-white text-blue-600 px-4 py-2 rounded-lg font-medium hover:bg-blue-50 transition-colors"
        >
          <Plus className="h-4 w-4" />
          ملاحظة جديدة
        </Link>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="الملاحظات"
          value={stats?.total_notes || 0}
          icon={FileText}
          color="blue"
        />
        <StatCard
          title="المشاريع"
          value={stats?.total_projects || 0}
          icon={FolderOpen}
          color="green"
        />
        <StatCard
          title="الأسئلة"
          value={stats?.open_questions || 0}
          icon={HelpCircle}
          color="yellow"
        />
        <StatCard
          title="الروابط"
          value={stats?.total_links || 0}
          icon={Link2}
          color="purple"
        />
      </div>

      {/* Main Content */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Momentum */}
        <div className="lg:col-span-1">
          <MomentumCard momentum={momentum} />
        </div>

        {/* Recent Notes */}
        <div className="lg:col-span-2">
          <RecentNotes notes={recentNotes} />
        </div>
      </div>

      {/* Due Reminders */}
      {dueReminders?.length > 0 && (
        <DueReminders reminders={dueReminders} />
      )}
    </div>
  );
}

function StatCard({ title, value, icon: Icon, color }) {
  const colors = {
    blue: 'bg-blue-50 text-blue-600 dark:bg-blue-900/30',
    green: 'bg-green-50 text-green-600 dark:bg-green-900/30',
    yellow: 'bg-yellow-50 text-yellow-600 dark:bg-yellow-900/30',
    purple: 'bg-purple-50 text-purple-600 dark:bg-purple-900/30',
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-sm">
      <div className="flex items-center gap-3">
        <div className={`p-2 rounded-lg ${colors[color]}`}>
          <Icon className="h-5 w-5" />
        </div>
        <div>
          <p className="text-sm text-gray-500 dark:text-gray-400">{title}</p>
          <p className="text-2xl font-bold text-gray-900 dark:text-white">{value}</p>
        </div>
      </div>
    </div>
  );
}
