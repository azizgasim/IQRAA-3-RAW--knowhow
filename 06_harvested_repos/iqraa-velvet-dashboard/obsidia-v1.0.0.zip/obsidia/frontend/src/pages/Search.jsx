/**
 * Search - صفحة البحث النصي
 */

import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { Search as SearchIcon, FileText, HelpCircle, Quote, Filter } from 'lucide-react';
import { api } from '../services/api';
import { useStore } from '../store/useStore';
import { useDebounce } from '../hooks/useDebounce';

export default function Search() {
  const { searchQuery, setSearchQuery, searchFilters, setSearchFilters } = useStore();
  const [localQuery, setLocalQuery] = useState(searchQuery);
  const debouncedQuery = useDebounce(localQuery, 300);

  useEffect(() => {
    setSearchQuery(debouncedQuery);
  }, [debouncedQuery, setSearchQuery]);

  const { data: results, isLoading, isFetching } = useQuery({
    queryKey: ['search', debouncedQuery, searchFilters],
    queryFn: () => api.search({
      query: debouncedQuery,
      search_in: searchFilters.searchIn,
      project_id: searchFilters.projectId,
      tags: searchFilters.tags,
    }),
    enabled: debouncedQuery.length >= 2,
  });

  const { data: suggestions } = useQuery({
    queryKey: ['suggestions', localQuery],
    queryFn: () => api.getSearchSuggestions(localQuery),
    enabled: localQuery.length >= 2 && !debouncedQuery,
  });

  const typeIcons = {
    note: FileText,
    question: HelpCircle,
    quotation: Quote,
  };

  const typeLabels = {
    note: 'ملاحظة',
    question: 'سؤال',
    quotation: 'اقتباس',
  };

  const typeColors = {
    note: 'bg-blue-100 text-blue-700',
    question: 'bg-yellow-100 text-yellow-700',
    quotation: 'bg-purple-100 text-purple-700',
  };

  return (
    <div className="space-y-6">
      {/* Search Box */}
      <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
        <div className="relative">
          <SearchIcon className="absolute right-4 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
          <input
            type="text"
            value={localQuery}
            onChange={(e) => setLocalQuery(e.target.value)}
            placeholder="ابحث في ملاحظاتك وأسئلتك واقتباساتك..."
            className="w-full pr-12 pl-4 py-3 text-lg border border-gray-200 dark:border-gray-700 rounded-xl bg-transparent focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            autoFocus
          />
          {isFetching && (
            <div className="absolute left-4 top-1/2 -translate-y-1/2">
              <div className="animate-spin h-5 w-5 border-2 border-blue-500 border-t-transparent rounded-full"></div>
            </div>
          )}
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-2 mt-4">
          <span className="text-sm text-gray-500 flex items-center gap-1">
            <Filter className="h-4 w-4" />
            البحث في:
          </span>
          {['notes', 'questions', 'quotations'].map((type) => (
            <button
              key={type}
              onClick={() => {
                const newSearchIn = searchFilters.searchIn.includes(type)
                  ? searchFilters.searchIn.filter((t) => t !== type)
                  : [...searchFilters.searchIn, type];
                setSearchFilters({ searchIn: newSearchIn.length ? newSearchIn : ['notes'] });
              }}
              className={`px-3 py-1 rounded-full text-sm transition-colors ${
                searchFilters.searchIn.includes(type)
                  ? typeColors[type]
                  : 'bg-gray-100 text-gray-600 dark:bg-gray-700'
              }`}
            >
              {typeLabels[type]}
            </button>
          ))}
        </div>
      </div>

      {/* Suggestions */}
      {suggestions?.length > 0 && !results && (
        <div className="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-sm">
          <p className="text-sm text-gray-500 mb-3">اقتراحات:</p>
          <div className="flex flex-wrap gap-2">
            {suggestions.map((s, i) => (
              <button
                key={i}
                onClick={() => setLocalQuery(s.text)}
                className="px-3 py-1 bg-gray-100 dark:bg-gray-700 rounded-full text-sm hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
              >
                {s.text}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Results */}
      {debouncedQuery.length >= 2 && (
        <div className="space-y-4">
          {isLoading ? (
            <div className="text-center py-12">
              <div className="animate-spin h-8 w-8 border-4 border-blue-500 border-t-transparent rounded-full mx-auto"></div>
              <p className="mt-4 text-gray-500">جاري البحث...</p>
            </div>
          ) : results?.length === 0 ? (
            <div className="text-center py-12 bg-white dark:bg-gray-800 rounded-xl">
              <SearchIcon className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500">لا توجد نتائج لـ "{debouncedQuery}"</p>
            </div>
          ) : (
            <>
              <p className="text-sm text-gray-500">
                {results?.length} نتيجة
              </p>
              {results?.map((result) => {
                const Icon = typeIcons[result.type];
                return (
                  <Link
                    key={`${result.type}-${result.id}`}
                    to={result.type === 'note' ? `/notes/${result.id}` : '#'}
                    className="block bg-white dark:bg-gray-800 rounded-xl p-4 shadow-sm hover:shadow-md transition-shadow"
                  >
                    <div className="flex items-start gap-3">
                      <div className={`p-2 rounded-lg ${typeColors[result.type]}`}>
                        <Icon className="h-4 w-4" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className={`text-xs px-2 py-0.5 rounded ${typeColors[result.type]}`}>
                            {typeLabels[result.type]}
                          </span>
                        </div>
                        <h3 className="font-medium text-gray-900 dark:text-white truncate">
                          {result.title}
                        </h3>
                        <p className="text-sm text-gray-500 dark:text-gray-400 mt-1 line-clamp-2">
                          {result.snippet}
                        </p>
                        <p className="text-xs text-gray-400 mt-2">
                          {new Date(result.created_at).toLocaleDateString('ar-SA')}
                        </p>
                      </div>
                    </div>
                  </Link>
                );
              })}
            </>
          )}
        </div>
      )}

      {/* Empty State */}
      {!debouncedQuery && (
        <div className="text-center py-12">
          <SearchIcon className="h-16 w-16 text-gray-300 dark:text-gray-600 mx-auto mb-4" />
          <p className="text-gray-500 dark:text-gray-400">
            ابدأ الكتابة للبحث في مفكرتك
          </p>
          <p className="text-sm text-gray-400 mt-2">
            البحث النصي البسيط - ليس دلالياً
          </p>
        </div>
      )}
    </div>
  );
}
