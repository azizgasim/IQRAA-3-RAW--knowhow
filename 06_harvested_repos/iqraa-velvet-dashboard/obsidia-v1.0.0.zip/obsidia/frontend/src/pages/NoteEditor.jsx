/**
 * NoteEditor - محرر الملاحظات
 */

import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Save, ArrowRight, Tag, Link2, Trash2, Clock } from 'lucide-react';
import toast from 'react-hot-toast';
import { api } from '../services/api';
import MarkdownEditor from '../components/MarkdownEditor';
import TagInput from '../components/TagInput';

export default function NoteEditor() {
  const { noteId } = useParams();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const isNew = !noteId;

  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [tags, setTags] = useState([]);
  const [projectId, setProjectId] = useState(null);
  const [isSaving, setIsSaving] = useState(false);

  // جلب الملاحظة إن كانت موجودة
  const { data: note, isLoading } = useQuery({
    queryKey: ['note', noteId],
    queryFn: () => api.getNote(noteId),
    enabled: !isNew,
  });

  // جلب المشاريع
  const { data: projects } = useQuery({
    queryKey: ['projects'],
    queryFn: api.getProjects,
  });

  // تحديث الحقول عند جلب الملاحظة
  useEffect(() => {
    if (note) {
      setTitle(note.title);
      setContent(note.content);
      setTags(note.tags || []);
      setProjectId(note.project_id);
    }
  }, [note]);

  // حفظ الملاحظة
  const saveMutation = useMutation({
    mutationFn: (data) => isNew ? api.createNote(data) : api.updateNote(noteId, data),
    onSuccess: (data) => {
      queryClient.invalidateQueries(['notes']);
      queryClient.invalidateQueries(['note', data.id]);
      toast.success(isNew ? 'تم إنشاء الملاحظة' : 'تم حفظ التغييرات');
      if (isNew) {
        navigate(`/notes/${data.id}`);
      }
    },
    onError: () => {
      toast.error('حدث خطأ أثناء الحفظ');
    },
  });

  // حذف الملاحظة
  const deleteMutation = useMutation({
    mutationFn: () => api.deleteNote(noteId),
    onSuccess: () => {
      queryClient.invalidateQueries(['notes']);
      toast.success('تم حذف الملاحظة');
      navigate('/notes');
    },
  });

  const handleSave = useCallback(() => {
    if (!title.trim()) {
      toast.error('العنوان مطلوب');
      return;
    }
    if (!content.trim()) {
      toast.error('المحتوى مطلوب');
      return;
    }

    saveMutation.mutate({
      title: title.trim(),
      content: content.trim(),
      tags,
      project_id: projectId,
    });
  }, [title, content, tags, projectId, saveMutation]);

  // اختصار لوحة المفاتيح للحفظ
  useEffect(() => {
    const handleKeyDown = (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 's') {
        e.preventDefault();
        handleSave();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleSave]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin h-8 w-8 border-4 border-blue-500 border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <button
          onClick={() => navigate(-1)}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white"
        >
          <ArrowRight className="h-5 w-5" />
          رجوع
        </button>
        <div className="flex items-center gap-3">
          {!isNew && (
            <button
              onClick={() => {
                if (confirm('هل أنت متأكد من حذف هذه الملاحظة؟')) {
                  deleteMutation.mutate();
                }
              }}
              className="p-2 text-red-600 hover:bg-red-50 dark:hover:bg-red-900/30 rounded-lg"
              title="حذف"
            >
              <Trash2 className="h-5 w-5" />
            </button>
          )}
          <button
            onClick={handleSave}
            disabled={saveMutation.isPending}
            className="inline-flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 disabled:opacity-50 transition-colors"
          >
            <Save className="h-4 w-4" />
            {saveMutation.isPending ? 'جاري الحفظ...' : 'حفظ'}
          </button>
        </div>
      </div>

      {/* Editor */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm overflow-hidden">
        {/* Title */}
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="عنوان الملاحظة..."
          className="w-full px-6 py-4 text-2xl font-bold border-b border-gray-200 dark:border-gray-700 bg-transparent focus:outline-none"
        />

        {/* Metadata */}
        <div className="px-6 py-3 border-b border-gray-200 dark:border-gray-700 flex flex-wrap gap-4">
          {/* Project */}
          <div className="flex items-center gap-2">
            <span className="text-sm text-gray-500">المشروع:</span>
            <select
              value={projectId || ''}
              onChange={(e) => setProjectId(e.target.value || null)}
              className="text-sm border border-gray-200 dark:border-gray-700 rounded px-2 py-1 bg-transparent"
            >
              <option value="">بدون مشروع</option>
              {projects?.map((p) => (
                <option key={p.id} value={p.id}>{p.name}</option>
              ))}
            </select>
          </div>

          {/* Tags */}
          <div className="flex items-center gap-2 flex-1">
            <Tag className="h-4 w-4 text-gray-400" />
            <TagInput tags={tags} onChange={setTags} />
          </div>
        </div>

        {/* Content Editor */}
        <div className="p-6">
          <MarkdownEditor
            value={content}
            onChange={setContent}
            placeholder="ابدأ الكتابة... (يدعم Markdown والروابط [[عنوان الملاحظة]])"
          />
        </div>

        {/* Footer Info */}
        {note && (
          <div className="px-6 py-3 bg-gray-50 dark:bg-gray-900 border-t border-gray-200 dark:border-gray-700 flex items-center gap-4 text-sm text-gray-500">
            <span className="flex items-center gap-1">
              <Clock className="h-4 w-4" />
              آخر تعديل: {new Date(note.updated_at).toLocaleString('ar-SA')}
            </span>
            <span className="flex items-center gap-1">
              <Link2 className="h-4 w-4" />
              {note.links_count} روابط صادرة • {note.backlinks_count} واردة
            </span>
          </div>
        )}
      </div>
    </div>
  );
}
