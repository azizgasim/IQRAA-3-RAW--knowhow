"""
Obsidia Models - نماذج البيانات

تعريف جميع الكيانات المستخدمة في النظام
"""

from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime
from enum import Enum
import uuid

def generate_id() -> str:
    """توليد معرف فريد"""
    return str(uuid.uuid4())

# ===== Enums =====

class NoteSource(str, Enum):
    MANUAL = "manual"           # إدخال يدوي
    VOICE = "voice"             # ملاحظة صوتية
    WHATSAPP = "whatsapp"       # من واتساب
    IQRA = "iqra"               # من منصة إقرأ
    IMPORT = "import"           # استيراد

class ContentType(str, Enum):
    MARKDOWN = "markdown"
    PLAIN = "plain"
    VOICE_TRANSCRIPT = "voice_transcript"

class ProjectStatus(str, Enum):
    ACTIVE = "active"
    PAUSED = "paused"
    COMPLETED = "completed"
    ARCHIVED = "archived"

class QuestionStatus(str, Enum):
    OPEN = "open"
    IN_PROGRESS = "in_progress"
    RESOLVED = "resolved"
    BRANCHED = "branched"       # تشعبت لأسئلة فرعية

class LinkType(str, Enum):
    REFERENCE = "reference"     # إشارة عادية
    SUPPORTS = "supports"       # يدعم
    CONTRADICTS = "contradicts" # يناقض
    EXTENDS = "extends"         # يوسع
    QUESTIONS = "questions"     # يتساءل عن

class ReminderType(str, Enum):
    REVIEW = "review"           # مراجعة ملاحظة
    QUESTION = "question"       # متابعة سؤال
    CUSTOM = "custom"           # تذكير مخصص

class MilestoneType(str, Enum):
    INSIGHT = "insight"         # اكتشاف/فهم جديد
    DECISION = "decision"       # قرار مهم
    PIVOT = "pivot"             # تغيير اتجاه
    BREAKTHROUGH = "breakthrough" # اختراق
    CONNECTION = "connection"   # ربط مهم

# ===== Note Models =====

class NoteBase(BaseModel):
    title: str = Field(..., min_length=1, max_length=500)
    content: str = Field(..., min_length=1)
    content_type: ContentType = ContentType.MARKDOWN
    source: NoteSource = NoteSource.MANUAL
    source_url: Optional[str] = None
    project_id: Optional[str] = None

class NoteCreate(NoteBase):
    tags: Optional[List[str]] = []  # قائمة أسماء الوسوم

class NoteUpdate(BaseModel):
    title: Optional[str] = None
    content: Optional[str] = None
    content_type: Optional[ContentType] = None
    project_id: Optional[str] = None
    tags: Optional[List[str]] = None

class NoteResponse(NoteBase):
    id: str
    created_at: datetime
    updated_at: datetime
    is_orphan: bool = False
    review_count: int = 0
    last_reviewed_at: Optional[datetime] = None
    next_review_at: Optional[datetime] = None
    tags: List[str] = []
    links_count: int = 0
    backlinks_count: int = 0

    class Config:
        from_attributes = True

# ===== Tag Models =====

class TagBase(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    color: str = Field(default="#3B82F6", pattern="^#[0-9A-Fa-f]{6}$")
    description: Optional[str] = None

class TagCreate(TagBase):
    pass

class TagUpdate(BaseModel):
    name: Optional[str] = None
    color: Optional[str] = None
    description: Optional[str] = None

class TagResponse(TagBase):
    id: str
    usage_count: int = 0
    created_at: datetime

    class Config:
        from_attributes = True

# ===== Link Models =====

class LinkBase(BaseModel):
    source_note_id: str
    target_note_id: str
    link_type: LinkType = LinkType.REFERENCE
    context: Optional[str] = None

class LinkCreate(LinkBase):
    pass

class LinkResponse(LinkBase):
    id: str
    created_at: datetime
    source_title: Optional[str] = None
    target_title: Optional[str] = None

    class Config:
        from_attributes = True

# ===== Project Models =====

class ProjectBase(BaseModel):
    name: str = Field(..., min_length=1, max_length=200)
    description: Optional[str] = None
    status: ProjectStatus = ProjectStatus.ACTIVE
    color: str = Field(default="#10B981", pattern="^#[0-9A-Fa-f]{6}$")
    parent_id: Optional[str] = None

class ProjectCreate(ProjectBase):
    pass

class ProjectUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[ProjectStatus] = None
    color: Optional[str] = None
    parent_id: Optional[str] = None

class ProjectResponse(ProjectBase):
    id: str
    created_at: datetime
    updated_at: datetime
    notes_count: int = 0
    questions_count: int = 0

    class Config:
        from_attributes = True

# ===== Question Models =====

class QuestionBase(BaseModel):
    content: str = Field(..., min_length=1)
    project_id: Optional[str] = None
    parent_question_id: Optional[str] = None
    status: QuestionStatus = QuestionStatus.OPEN
    priority: int = Field(default=0, ge=0, le=5)

class QuestionCreate(QuestionBase):
    pass

class QuestionUpdate(BaseModel):
    content: Optional[str] = None
    project_id: Optional[str] = None
    status: Optional[QuestionStatus] = None
    priority: Optional[int] = None

class QuestionResponse(QuestionBase):
    id: str
    created_at: datetime
    updated_at: datetime
    resolved_at: Optional[datetime] = None
    sub_questions_count: int = 0

    class Config:
        from_attributes = True

# ===== Quotation Models =====

class QuotationBase(BaseModel):
    content: str = Field(..., min_length=1)
    source: Optional[str] = None
    source_url: Optional[str] = None
    author: Optional[str] = None
    page: Optional[str] = None
    note_id: Optional[str] = None

class QuotationCreate(QuotationBase):
    pass

class QuotationResponse(QuotationBase):
    id: str
    created_at: datetime

    class Config:
        from_attributes = True

# ===== Reminder Models =====

class ReminderBase(BaseModel):
    note_id: Optional[str] = None
    question_id: Optional[str] = None
    reminder_type: ReminderType
    message: Optional[str] = None
    due_at: datetime

class ReminderCreate(ReminderBase):
    pass

class ReminderResponse(ReminderBase):
    id: str
    is_completed: bool = False
    completed_at: Optional[datetime] = None
    created_at: datetime

    class Config:
        from_attributes = True

# ===== Cognitive Profile Models =====

class CognitiveProfileResponse(BaseModel):
    id: str
    date: str
    notes_created: int
    notes_edited: int
    links_created: int
    tags_used: int
    active_minutes: int
    peak_hour: Optional[int]
    most_used_tags: Optional[str]
    momentum_score: float

    class Config:
        from_attributes = True

class MomentumReport(BaseModel):
    """تقرير الزخم البحثي"""
    current_score: float
    trend: str  # "rising", "stable", "declining"
    streak_days: int
    total_notes: int
    total_links: int
    active_projects: int
    open_questions: int

# ===== Decision Models =====

class DecisionBase(BaseModel):
    project_id: Optional[str] = None
    title: str = Field(..., min_length=1, max_length=200)
    decision: str = Field(..., min_length=1)
    reasoning: Optional[str] = None
    alternatives: Optional[str] = None

class DecisionCreate(DecisionBase):
    pass

class DecisionResponse(DecisionBase):
    id: str
    created_at: datetime

    class Config:
        from_attributes = True

# ===== Journey Milestone Models =====

class MilestoneBase(BaseModel):
    project_id: Optional[str] = None
    title: str = Field(..., min_length=1, max_length=200)
    description: Optional[str] = None
    milestone_type: MilestoneType = MilestoneType.INSIGHT
    significance: int = Field(default=1, ge=1, le=5)

class MilestoneCreate(MilestoneBase):
    pass

class MilestoneResponse(MilestoneBase):
    id: str
    created_at: datetime

    class Config:
        from_attributes = True

# ===== Search Models =====

class SearchQuery(BaseModel):
    query: str = Field(..., min_length=1)
    search_in: List[str] = ["notes", "questions", "quotations"]
    project_id: Optional[str] = None
    tags: Optional[List[str]] = None
    date_from: Optional[datetime] = None
    date_to: Optional[datetime] = None
    limit: int = Field(default=20, ge=1, le=100)

class SearchResult(BaseModel):
    type: str  # "note", "question", "quotation"
    id: str
    title: str
    snippet: str
    score: float
    created_at: datetime

# ===== Sync Models =====

class SyncStatus(BaseModel):
    last_sync: Optional[datetime]
    pending_changes: int
    sync_enabled: bool

class SyncRequest(BaseModel):
    sync_type: str = "full"  # "full", "incremental"
    direction: str = "backup"  # "backup", "restore"

# ===== Integration Models (التكامل مع إقرأ) =====

class IqraNote(BaseModel):
    """ملاحظة قادمة من إقرأ"""
    content: str
    source_url: str
    source_title: Optional[str] = None
    context: Optional[str] = None

class IqraQuotation(BaseModel):
    """اقتباس قادم من إقرأ"""
    content: str
    source_url: str
    source_title: Optional[str] = None
    author: Optional[str] = None
    page: Optional[str] = None

class IqraSearchRequest(BaseModel):
    """طلب بحث في إقرأ"""
    query: str
    search_type: str = "semantic"  # "semantic", "exact"
