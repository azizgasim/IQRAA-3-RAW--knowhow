"""
Obsidia Cognitive Router - المرآة المعرفية

تحليل السلوك لا المحتوى:
- مؤشر الزخم البحثي
- أنماط النشاط
- التقارير الدورية
- التذكيرات

فلسفة الذكاء الصامت:
90% صامت | 8% يهمس | 2% ينصح | <1% يُنبّه
"""

from fastapi import APIRouter, HTTPException, Depends, Query
from typing import List, Optional
from datetime import datetime, timedelta
import uuid

from database.db import get_db
from models.schemas import (
    CognitiveProfileResponse, MomentumReport,
    ReminderCreate, ReminderResponse
)

router = APIRouter()

def generate_id() -> str:
    return str(uuid.uuid4())

# ===== المرآة المعرفية =====

@router.get("/mirror/today", response_model=CognitiveProfileResponse)
async def get_today_profile(db=Depends(get_db)):
    """الملف المعرفي لليوم"""
    today = datetime.now().date()
    
    result = await db.execute(
        "SELECT * FROM cognitive_profile WHERE date = ?",
        (today,)
    )
    row = await result.fetchone()
    
    if not row:
        # إنشاء سجل جديد
        profile_id = generate_id()
        await db.execute("""
            INSERT INTO cognitive_profile (id, date)
            VALUES (?, ?)
        """, (profile_id, today))
        await db.commit()
        
        result = await db.execute(
            "SELECT * FROM cognitive_profile WHERE id = ?",
            (profile_id,)
        )
        row = await result.fetchone()
    
    return CognitiveProfileResponse(**dict(row))

@router.get("/mirror/history")
async def get_profile_history(days: int = 30, db=Depends(get_db)):
    """تاريخ النشاط المعرفي"""
    start_date = datetime.now().date() - timedelta(days=days)
    
    result = await db.execute("""
        SELECT * FROM cognitive_profile
        WHERE date >= ?
        ORDER BY date DESC
    """, (start_date,))
    
    rows = await result.fetchall()
    return [dict(row) for row in rows]

# ===== مؤشر الزخم البحثي =====

@router.get("/momentum", response_model=MomentumReport)
async def get_momentum_report(db=Depends(get_db)):
    """مؤشر الزخم البحثي (حرارة النشاط)"""
    
    # حساب النقاط للأسبوع الماضي
    week_ago = datetime.now() - timedelta(days=7)
    
    # إحصائيات الأسبوع
    notes_result = await db.execute("""
        SELECT COUNT(*) as count FROM notes WHERE created_at >= ?
    """, (week_ago,))
    notes_count = (await notes_result.fetchone())['count']
    
    links_result = await db.execute("""
        SELECT COUNT(*) as count FROM links WHERE created_at >= ?
    """, (week_ago,))
    links_count = (await links_result.fetchone())['count']
    
    # حساب الزخم (صيغة بسيطة)
    momentum_score = (notes_count * 2) + (links_count * 1)
    
    # تحديد الاتجاه
    prev_week = week_ago - timedelta(days=7)
    prev_notes = await db.execute("""
        SELECT COUNT(*) as count FROM notes 
        WHERE created_at >= ? AND created_at < ?
    """, (prev_week, week_ago))
    prev_count = (await prev_notes.fetchone())['count']
    
    if notes_count > prev_count * 1.2:
        trend = "rising"
    elif notes_count < prev_count * 0.8:
        trend = "declining"
    else:
        trend = "stable"
    
    # حساب أيام النشاط المتتالية
    streak = 0
    current_date = datetime.now().date()
    while True:
        result = await db.execute("""
            SELECT notes_created FROM cognitive_profile WHERE date = ?
        """, (current_date,))
        row = await result.fetchone()
        if row and row['notes_created'] > 0:
            streak += 1
            current_date -= timedelta(days=1)
        else:
            break
    
    # إحصائيات عامة
    total_notes = await db.execute("SELECT COUNT(*) as count FROM notes")
    total_links = await db.execute("SELECT COUNT(*) as count FROM links")
    active_projects = await db.execute("""
        SELECT COUNT(*) as count FROM projects WHERE status = 'active'
    """)
    open_questions = await db.execute("""
        SELECT COUNT(*) as count FROM questions WHERE status = 'open'
    """)
    
    return MomentumReport(
        current_score=momentum_score,
        trend=trend,
        streak_days=streak,
        total_notes=(await total_notes.fetchone())['count'],
        total_links=(await total_links.fetchone())['count'],
        active_projects=(await active_projects.fetchone())['count'],
        open_questions=(await open_questions.fetchone())['count']
    )

# ===== التقارير الدورية =====

@router.get("/reports/weekly")
async def get_weekly_report(db=Depends(get_db)):
    """التقرير الأسبوعي"""
    week_ago = datetime.now() - timedelta(days=7)
    
    # الملاحظات الجديدة
    notes = await db.execute("""
        SELECT id, title, created_at FROM notes
        WHERE created_at >= ?
        ORDER BY created_at DESC
    """, (week_ago,))
    new_notes = [dict(row) for row in await notes.fetchall()]
    
    # الأسئلة المحلولة
    resolved = await db.execute("""
        SELECT content FROM questions
        WHERE resolved_at >= ?
    """, (week_ago,))
    resolved_questions = [row['content'] for row in await resolved.fetchall()]
    
    # الروابط الجديدة
    links = await db.execute("""
        SELECT COUNT(*) as count FROM links WHERE created_at >= ?
    """, (week_ago,))
    new_links = (await links.fetchone())['count']
    
    # الوسوم الأكثر استخداماً
    top_tags = await db.execute("""
        SELECT t.name, COUNT(*) as count
        FROM tags t
        JOIN note_tags nt ON t.id = nt.tag_id
        JOIN notes n ON nt.note_id = n.id
        WHERE n.created_at >= ?
        GROUP BY t.id
        ORDER BY count DESC
        LIMIT 5
    """, (week_ago,))
    
    # ساعات النشاط
    activity = await db.execute("""
        SELECT strftime('%H', created_at) as hour, COUNT(*) as count
        FROM notes
        WHERE created_at >= ?
        GROUP BY hour
        ORDER BY count DESC
        LIMIT 3
    """, (week_ago,))
    peak_hours = [row['hour'] for row in await activity.fetchall()]
    
    return {
        "period": {
            "start": week_ago.isoformat(),
            "end": datetime.now().isoformat()
        },
        "summary": {
            "new_notes": len(new_notes),
            "new_links": new_links,
            "resolved_questions": len(resolved_questions)
        },
        "highlights": {
            "recent_notes": new_notes[:5],
            "top_tags": [dict(row) for row in await top_tags.fetchall()],
            "peak_hours": peak_hours
        },
        "reflection_prompts": generate_reflection_prompts(len(new_notes), new_links)
    }

def generate_reflection_prompts(notes_count: int, links_count: int) -> List[str]:
    """توليد أسئلة تأملية عامة (محفّز لا موجّه)"""
    prompts = [
        "ما الفكرة التي تراودك كثيراً هذا الأسبوع؟",
        "هل هناك ربط لم تسجله بعد؟",
        "ما السؤال الذي لم تجد له إجابة؟"
    ]
    
    if notes_count < 3:
        prompts.append("ما الذي يمنعك من التدوين أكثر؟")
    
    if links_count == 0:
        prompts.append("هل تبحث عن علاقات بين أفكارك؟")
    
    return prompts[:3]  # أقصى 3 أسئلة

# ===== التذكيرات =====

@router.post("/reminders", response_model=ReminderResponse)
async def create_reminder(reminder: ReminderCreate, db=Depends(get_db)):
    """إنشاء تذكير"""
    reminder_id = generate_id()
    
    await db.execute("""
        INSERT INTO reminders (id, note_id, question_id, reminder_type, message, due_at)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (reminder_id, reminder.note_id, reminder.question_id,
          reminder.reminder_type.value, reminder.message, reminder.due_at))
    
    await db.commit()
    
    result = await db.execute("SELECT * FROM reminders WHERE id = ?", (reminder_id,))
    row = await result.fetchone()
    return ReminderResponse(**dict(row))

@router.get("/reminders/due", response_model=List[ReminderResponse])
async def get_due_reminders(db=Depends(get_db)):
    """التذكيرات المستحقة"""
    result = await db.execute("""
        SELECT * FROM reminders
        WHERE is_completed = 0 AND due_at <= ?
        ORDER BY due_at ASC
    """, (datetime.now(),))
    
    rows = await result.fetchall()
    return [ReminderResponse(**dict(row)) for row in rows]

@router.post("/reminders/{reminder_id}/complete")
async def complete_reminder(reminder_id: str, db=Depends(get_db)):
    """إكمال تذكير"""
    await db.execute("""
        UPDATE reminders
        SET is_completed = 1, completed_at = ?
        WHERE id = ?
    """, (datetime.now(), reminder_id))
    
    await db.commit()
    return {"message": "تم إكمال التذكير"}

@router.get("/reminders/upcoming")
async def get_upcoming_reminders(days: int = 7, db=Depends(get_db)):
    """التذكيرات القادمة"""
    future = datetime.now() + timedelta(days=days)
    
    result = await db.execute("""
        SELECT * FROM reminders
        WHERE is_completed = 0 AND due_at > ? AND due_at <= ?
        ORDER BY due_at ASC
    """, (datetime.now(), future))
    
    rows = await result.fetchall()
    return [dict(row) for row in rows]

# ===== محلل الأنماط المعرفية =====

@router.get("/patterns")
async def analyze_cognitive_patterns(db=Depends(get_db)):
    """تحليل أنماط السلوك المعرفي (لا المحتوى)"""
    
    # أوقات النشاط
    time_pattern = await db.execute("""
        SELECT 
            strftime('%H', created_at) as hour,
            strftime('%w', created_at) as day_of_week,
            COUNT(*) as count
        FROM notes
        GROUP BY hour, day_of_week
        ORDER BY count DESC
    """)
    
    # طول الملاحظات
    length_pattern = await db.execute("""
        SELECT 
            CASE 
                WHEN LENGTH(content) < 200 THEN 'short'
                WHEN LENGTH(content) < 1000 THEN 'medium'
                ELSE 'long'
            END as length_category,
            COUNT(*) as count
        FROM notes
        GROUP BY length_category
    """)
    
    # نسبة الملاحظات المرتبطة
    linked = await db.execute("""
        SELECT 
            COUNT(DISTINCT source_note_id) + COUNT(DISTINCT target_note_id) as linked_notes
        FROM links
    """)
    total = await db.execute("SELECT COUNT(*) as count FROM notes")
    
    linked_count = (await linked.fetchone())['linked_notes']
    total_count = (await total.fetchone())['count']
    linking_rate = (linked_count / total_count * 100) if total_count > 0 else 0
    
    return {
        "activity_patterns": [dict(row) for row in await time_pattern.fetchall()],
        "note_lengths": [dict(row) for row in await length_pattern.fetchall()],
        "linking_behavior": {
            "linked_notes": linked_count,
            "total_notes": total_count,
            "linking_rate": round(linking_rate, 1)
        },
        "insights": generate_pattern_insights(linking_rate)
    }

def generate_pattern_insights(linking_rate: float) -> List[str]:
    """توليد رؤى من الأنماط"""
    insights = []
    
    if linking_rate < 20:
        insights.append("معظم ملاحظاتك غير مرتبطة. فكر في إيجاد علاقات.")
    elif linking_rate > 60:
        insights.append("شبكة أفكارك متصلة جيداً!")
    
    return insights
