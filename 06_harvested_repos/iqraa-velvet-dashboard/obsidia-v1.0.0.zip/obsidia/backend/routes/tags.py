"""
Obsidia Tags Router - إدارة الوسوم #
"""

from fastapi import APIRouter, HTTPException, Depends, Query
from typing import List, Optional
from datetime import datetime
import uuid

from database.db import get_db
from models.schemas import TagCreate, TagUpdate, TagResponse

router = APIRouter()

def generate_id() -> str:
    return str(uuid.uuid4())

@router.post("/", response_model=TagResponse)
async def create_tag(tag: TagCreate, db=Depends(get_db)):
    """إنشاء وسم جديد"""
    # التحقق من عدم وجود الوسم
    existing = await db.execute("SELECT id FROM tags WHERE name = ?", (tag.name,))
    if await existing.fetchone():
        raise HTTPException(status_code=400, detail="الوسم موجود مسبقاً")
    
    tag_id = generate_id()
    await db.execute("""
        INSERT INTO tags (id, name, color, description)
        VALUES (?, ?, ?, ?)
    """, (tag_id, tag.name, tag.color, tag.description))
    
    await db.commit()
    
    return await get_tag(tag_id, db)

@router.get("/", response_model=List[TagResponse])
async def list_tags(
    sort_by: str = Query(default="usage", regex="^(usage|name|created)$"),
    limit: int = Query(default=50, le=200),
    db=Depends(get_db)
):
    """قائمة الوسوم"""
    order_map = {
        "usage": "usage_count DESC",
        "name": "name ASC",
        "created": "created_at DESC"
    }
    
    result = await db.execute(f"""
        SELECT * FROM tags
        ORDER BY {order_map[sort_by]}
        LIMIT ?
    """, (limit,))
    
    rows = await result.fetchall()
    return [TagResponse(**dict(row)) for row in rows]

@router.get("/{tag_id}", response_model=TagResponse)
async def get_tag(tag_id: str, db=Depends(get_db)):
    """جلب وسم محدد"""
    result = await db.execute("SELECT * FROM tags WHERE id = ?", (tag_id,))
    row = await result.fetchone()
    
    if not row:
        raise HTTPException(status_code=404, detail="الوسم غير موجود")
    
    return TagResponse(**dict(row))

@router.get("/name/{tag_name}", response_model=TagResponse)
async def get_tag_by_name(tag_name: str, db=Depends(get_db)):
    """جلب وسم بالاسم"""
    result = await db.execute("SELECT * FROM tags WHERE name = ?", (tag_name,))
    row = await result.fetchone()
    
    if not row:
        raise HTTPException(status_code=404, detail="الوسم غير موجود")
    
    return TagResponse(**dict(row))

@router.put("/{tag_id}", response_model=TagResponse)
async def update_tag(tag_id: str, tag: TagUpdate, db=Depends(get_db)):
    """تحديث وسم"""
    existing = await db.execute("SELECT id FROM tags WHERE id = ?", (tag_id,))
    if not await existing.fetchone():
        raise HTTPException(status_code=404, detail="الوسم غير موجود")
    
    updates = []
    params = []
    
    if tag.name is not None:
        # التحقق من عدم وجود وسم آخر بنفس الاسم
        dup = await db.execute("SELECT id FROM tags WHERE name = ? AND id != ?", (tag.name, tag_id))
        if await dup.fetchone():
            raise HTTPException(status_code=400, detail="اسم الوسم مستخدم مسبقاً")
        updates.append("name = ?")
        params.append(tag.name)
    
    if tag.color is not None:
        updates.append("color = ?")
        params.append(tag.color)
    
    if tag.description is not None:
        updates.append("description = ?")
        params.append(tag.description)
    
    if updates:
        params.append(tag_id)
        await db.execute(
            f"UPDATE tags SET {', '.join(updates)} WHERE id = ?",
            params
        )
        await db.commit()
    
    return await get_tag(tag_id, db)

@router.delete("/{tag_id}")
async def delete_tag(tag_id: str, db=Depends(get_db)):
    """حذف وسم"""
    result = await db.execute("DELETE FROM tags WHERE id = ?", (tag_id,))
    if result.rowcount == 0:
        raise HTTPException(status_code=404, detail="الوسم غير موجود")
    
    await db.commit()
    return {"message": "تم حذف الوسم بنجاح"}

@router.get("/{tag_id}/notes")
async def get_tag_notes(tag_id: str, db=Depends(get_db)):
    """جلب الملاحظات المرتبطة بوسم"""
    result = await db.execute("""
        SELECT n.id, n.title, n.created_at, n.updated_at
        FROM notes n
        JOIN note_tags nt ON n.id = nt.note_id
        WHERE nt.tag_id = ?
        ORDER BY n.updated_at DESC
    """, (tag_id,))
    
    rows = await result.fetchall()
    return [dict(row) for row in rows]

@router.get("/stats/frequent")
async def get_frequent_concepts(days: int = 30, limit: int = 20, db=Depends(get_db)):
    """المفاهيم المتكررة (عد الوسوم الأكثر استخداماً)"""
    result = await db.execute("""
        SELECT t.name, t.color, COUNT(nt.note_id) as count
        FROM tags t
        JOIN note_tags nt ON t.id = nt.tag_id
        JOIN notes n ON nt.note_id = n.id
        WHERE n.created_at >= datetime('now', ?)
        GROUP BY t.id
        ORDER BY count DESC
        LIMIT ?
    """, (f'-{days} days', limit))
    
    rows = await result.fetchall()
    return [dict(row) for row in rows]
