"""
Obsidia Notes Router - إدارة الملاحظات

الوظائف المشمولة:
1. ملاحظة نصية Markdown
2. التقاط من مصادر متعددة
3. إدارة الروابط [[]]
4. المراجعة المتباعدة
"""

from fastapi import APIRouter, HTTPException, Depends, Query
from typing import List, Optional
from datetime import datetime, timedelta
import uuid
import re

from database.db import get_db
from models.schemas import (
    NoteCreate, NoteUpdate, NoteResponse,
    LinkCreate, LinkResponse, LinkType
)

router = APIRouter()

def generate_id() -> str:
    return str(uuid.uuid4())

def extract_links(content: str) -> List[str]:
    """استخراج الروابط [[title]] من المحتوى"""
    pattern = r'\[\[([^\]]+)\]\]'
    return re.findall(pattern, content)

def calculate_next_review(review_count: int) -> datetime:
    """حساب موعد المراجعة القادمة (المراجعة المتباعدة)"""
    intervals = [1, 7, 30, 90, 180, 365]  # يوم، أسبوع، شهر، 3 أشهر، 6 أشهر، سنة
    index = min(review_count, len(intervals) - 1)
    return datetime.now() + timedelta(days=intervals[index])

# ===== CRUD Operations =====

@router.post("/", response_model=NoteResponse)
async def create_note(note: NoteCreate, db=Depends(get_db)):
    """إنشاء ملاحظة جديدة"""
    note_id = generate_id()
    now = datetime.now()
    
    # إدخال الملاحظة
    await db.execute("""
        INSERT INTO notes (id, title, content, content_type, source, source_url, project_id, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (note_id, note.title, note.content, note.content_type.value, 
          note.source.value, note.source_url, note.project_id, now, now))
    
    # إضافة الوسوم
    for tag_name in (note.tags or []):
        # التأكد من وجود الوسم أو إنشائه
        tag_result = await db.execute("SELECT id FROM tags WHERE name = ?", (tag_name,))
        tag_row = await tag_result.fetchone()
        
        if tag_row:
            tag_id = tag_row['id']
        else:
            tag_id = generate_id()
            await db.execute(
                "INSERT INTO tags (id, name) VALUES (?, ?)",
                (tag_id, tag_name)
            )
        
        # ربط الوسم بالملاحظة
        await db.execute(
            "INSERT OR IGNORE INTO note_tags (note_id, tag_id) VALUES (?, ?)",
            (note_id, tag_id)
        )
        
        # تحديث عداد الاستخدام
        await db.execute(
            "UPDATE tags SET usage_count = usage_count + 1 WHERE id = ?",
            (tag_id,)
        )
    
    # استخراج وإنشاء الروابط
    linked_titles = extract_links(note.content)
    for title in linked_titles:
        # البحث عن الملاحظة المستهدفة
        target_result = await db.execute(
            "SELECT id FROM notes WHERE title = ?", (title,)
        )
        target_row = await target_result.fetchone()
        
        if target_row:
            link_id = generate_id()
            await db.execute("""
                INSERT OR IGNORE INTO links (id, source_note_id, target_note_id, link_type)
                VALUES (?, ?, ?, ?)
            """, (link_id, note_id, target_row['id'], LinkType.REFERENCE.value))
    
    # تحديث FTS
    await db.execute("""
        INSERT INTO notes_fts (rowid, title, content)
        SELECT rowid, title, content FROM notes WHERE id = ?
    """, (note_id,))
    
    # تحديث الملف الشخصي المعرفي
    today = datetime.now().date()
    await db.execute("""
        INSERT INTO cognitive_profile (id, date, notes_created)
        VALUES (?, ?, 1)
        ON CONFLICT(date) DO UPDATE SET notes_created = notes_created + 1
    """, (generate_id(), today))
    
    await db.commit()
    
    # جلب الملاحظة المُنشأة
    return await get_note(note_id, db)

@router.get("/", response_model=List[NoteResponse])
async def list_notes(
    project_id: Optional[str] = None,
    tag: Optional[str] = None,
    source: Optional[str] = None,
    orphans_only: bool = False,
    review_due: bool = False,
    skip: int = 0,
    limit: int = Query(default=50, le=100),
    db=Depends(get_db)
):
    """قائمة الملاحظات مع فلاتر"""
    query = """
        SELECT DISTINCT n.*, 
               GROUP_CONCAT(DISTINCT t.name) as tag_names,
               (SELECT COUNT(*) FROM links WHERE source_note_id = n.id) as links_count,
               (SELECT COUNT(*) FROM links WHERE target_note_id = n.id) as backlinks_count
        FROM notes n
        LEFT JOIN note_tags nt ON n.id = nt.note_id
        LEFT JOIN tags t ON nt.tag_id = t.id
        WHERE 1=1
    """
    params = []
    
    if project_id:
        query += " AND n.project_id = ?"
        params.append(project_id)
    
    if tag:
        query += " AND t.name = ?"
        params.append(tag)
    
    if source:
        query += " AND n.source = ?"
        params.append(source)
    
    if orphans_only:
        query += """ AND n.id NOT IN (
            SELECT source_note_id FROM links
            UNION
            SELECT target_note_id FROM links
        )"""
    
    if review_due:
        query += " AND n.next_review_at <= ?"
        params.append(datetime.now())
    
    query += " GROUP BY n.id ORDER BY n.updated_at DESC LIMIT ? OFFSET ?"
    params.extend([limit, skip])
    
    result = await db.execute(query, params)
    rows = await result.fetchall()
    
    notes = []
    for row in rows:
        note_dict = dict(row)
        note_dict['tags'] = row['tag_names'].split(',') if row['tag_names'] else []
        notes.append(NoteResponse(**note_dict))
    
    return notes

@router.get("/{note_id}", response_model=NoteResponse)
async def get_note(note_id: str, db=Depends(get_db)):
    """جلب ملاحظة محددة"""
    result = await db.execute("""
        SELECT n.*,
               GROUP_CONCAT(DISTINCT t.name) as tag_names,
               (SELECT COUNT(*) FROM links WHERE source_note_id = n.id) as links_count,
               (SELECT COUNT(*) FROM links WHERE target_note_id = n.id) as backlinks_count
        FROM notes n
        LEFT JOIN note_tags nt ON n.id = nt.note_id
        LEFT JOIN tags t ON nt.tag_id = t.id
        WHERE n.id = ?
        GROUP BY n.id
    """, (note_id,))
    
    row = await result.fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="الملاحظة غير موجودة")
    
    note_dict = dict(row)
    note_dict['tags'] = row['tag_names'].split(',') if row['tag_names'] else []
    
    return NoteResponse(**note_dict)

@router.put("/{note_id}", response_model=NoteResponse)
async def update_note(note_id: str, note: NoteUpdate, db=Depends(get_db)):
    """تحديث ملاحظة"""
    # التحقق من وجود الملاحظة
    existing = await db.execute("SELECT id FROM notes WHERE id = ?", (note_id,))
    if not await existing.fetchone():
        raise HTTPException(status_code=404, detail="الملاحظة غير موجودة")
    
    # بناء استعلام التحديث
    updates = []
    params = []
    
    if note.title is not None:
        updates.append("title = ?")
        params.append(note.title)
    
    if note.content is not None:
        updates.append("content = ?")
        params.append(note.content)
    
    if note.content_type is not None:
        updates.append("content_type = ?")
        params.append(note.content_type.value)
    
    if note.project_id is not None:
        updates.append("project_id = ?")
        params.append(note.project_id)
    
    updates.append("updated_at = ?")
    params.append(datetime.now())
    params.append(note_id)
    
    if updates:
        await db.execute(
            f"UPDATE notes SET {', '.join(updates)} WHERE id = ?",
            params
        )
    
    # تحديث الوسوم إن وُجدت
    if note.tags is not None:
        # حذف الوسوم القديمة
        await db.execute("DELETE FROM note_tags WHERE note_id = ?", (note_id,))
        
        # إضافة الوسوم الجديدة
        for tag_name in note.tags:
            tag_result = await db.execute("SELECT id FROM tags WHERE name = ?", (tag_name,))
            tag_row = await tag_result.fetchone()
            
            if tag_row:
                tag_id = tag_row['id']
            else:
                tag_id = generate_id()
                await db.execute(
                    "INSERT INTO tags (id, name) VALUES (?, ?)",
                    (tag_id, tag_name)
                )
            
            await db.execute(
                "INSERT INTO note_tags (note_id, tag_id) VALUES (?, ?)",
                (note_id, tag_id)
            )
    
    # تحديث الروابط إن تغير المحتوى
    if note.content is not None:
        # حذف الروابط القديمة
        await db.execute("DELETE FROM links WHERE source_note_id = ?", (note_id,))
        
        # إنشاء روابط جديدة
        linked_titles = extract_links(note.content)
        for title in linked_titles:
            target_result = await db.execute(
                "SELECT id FROM notes WHERE title = ?", (title,)
            )
            target_row = await target_result.fetchone()
            
            if target_row:
                link_id = generate_id()
                await db.execute("""
                    INSERT OR IGNORE INTO links (id, source_note_id, target_note_id, link_type)
                    VALUES (?, ?, ?, ?)
                """, (link_id, note_id, target_row['id'], LinkType.REFERENCE.value))
    
    # تحديث الملف المعرفي
    today = datetime.now().date()
    await db.execute("""
        INSERT INTO cognitive_profile (id, date, notes_edited)
        VALUES (?, ?, 1)
        ON CONFLICT(date) DO UPDATE SET notes_edited = notes_edited + 1
    """, (generate_id(), today))
    
    await db.commit()
    
    return await get_note(note_id, db)

@router.delete("/{note_id}")
async def delete_note(note_id: str, db=Depends(get_db)):
    """حذف ملاحظة"""
    result = await db.execute("DELETE FROM notes WHERE id = ?", (note_id,))
    if result.rowcount == 0:
        raise HTTPException(status_code=404, detail="الملاحظة غير موجودة")
    
    await db.commit()
    return {"message": "تم حذف الملاحظة بنجاح"}

# ===== Links =====

@router.get("/{note_id}/links", response_model=List[LinkResponse])
async def get_note_links(note_id: str, db=Depends(get_db)):
    """جلب روابط ملاحظة (صادرة)"""
    result = await db.execute("""
        SELECT l.*, n.title as target_title
        FROM links l
        JOIN notes n ON l.target_note_id = n.id
        WHERE l.source_note_id = ?
    """, (note_id,))
    
    rows = await result.fetchall()
    return [LinkResponse(**dict(row), source_title=None) for row in rows]

@router.get("/{note_id}/backlinks", response_model=List[LinkResponse])
async def get_note_backlinks(note_id: str, db=Depends(get_db)):
    """جلب الروابط الواردة لملاحظة"""
    result = await db.execute("""
        SELECT l.*, n.title as source_title
        FROM links l
        JOIN notes n ON l.source_note_id = n.id
        WHERE l.target_note_id = ?
    """, (note_id,))
    
    rows = await result.fetchall()
    return [LinkResponse(**dict(row), target_title=None) for row in rows]

@router.post("/{note_id}/links", response_model=LinkResponse)
async def create_link(note_id: str, link: LinkCreate, db=Depends(get_db)):
    """إنشاء رابط يدوي"""
    # التحقق من وجود الملاحظتين
    source = await db.execute("SELECT id FROM notes WHERE id = ?", (note_id,))
    target = await db.execute("SELECT id FROM notes WHERE id = ?", (link.target_note_id,))
    
    if not await source.fetchone():
        raise HTTPException(status_code=404, detail="الملاحظة المصدر غير موجودة")
    if not await target.fetchone():
        raise HTTPException(status_code=404, detail="الملاحظة الهدف غير موجودة")
    
    link_id = generate_id()
    await db.execute("""
        INSERT INTO links (id, source_note_id, target_note_id, link_type, context)
        VALUES (?, ?, ?, ?, ?)
    """, (link_id, note_id, link.target_note_id, link.link_type.value, link.context))
    
    # تحديث الملف المعرفي
    today = datetime.now().date()
    await db.execute("""
        INSERT INTO cognitive_profile (id, date, links_created)
        VALUES (?, ?, 1)
        ON CONFLICT(date) DO UPDATE SET links_created = links_created + 1
    """, (generate_id(), today))
    
    await db.commit()
    
    result = await db.execute("SELECT * FROM links WHERE id = ?", (link_id,))
    row = await result.fetchone()
    return LinkResponse(**dict(row))

# ===== Spaced Repetition =====

@router.post("/{note_id}/review")
async def mark_note_reviewed(note_id: str, db=Depends(get_db)):
    """تسجيل مراجعة الملاحظة (المراجعة المتباعدة)"""
    result = await db.execute("SELECT review_count FROM notes WHERE id = ?", (note_id,))
    row = await result.fetchone()
    
    if not row:
        raise HTTPException(status_code=404, detail="الملاحظة غير موجودة")
    
    new_count = row['review_count'] + 1
    next_review = calculate_next_review(new_count)
    
    await db.execute("""
        UPDATE notes 
        SET review_count = ?, last_reviewed_at = ?, next_review_at = ?
        WHERE id = ?
    """, (new_count, datetime.now(), next_review, note_id))
    
    await db.commit()
    
    return {
        "message": "تم تسجيل المراجعة",
        "review_count": new_count,
        "next_review_at": next_review.isoformat()
    }

@router.get("/reviews/due", response_model=List[NoteResponse])
async def get_due_reviews(limit: int = 10, db=Depends(get_db)):
    """جلب الملاحظات المستحقة للمراجعة"""
    return await list_notes(review_due=True, limit=limit, db=db)

# ===== Orphan Detection =====

@router.get("/orphans/", response_model=List[NoteResponse])
async def get_orphan_notes(db=Depends(get_db)):
    """جلب الملاحظات اليتيمة (بدون روابط)"""
    return await list_notes(orphans_only=True, db=db)
