"""
Obsidia Projects Router - إدارة المشاريع والأسئلة البحثية

الوظائف:
- المشاريع البحثية
- الأسئلة البحثية (دفتر الأسئلة الحية)
- سجل القرارات البحثية
- نقاط التحول في الرحلة البحثية
"""

from fastapi import APIRouter, HTTPException, Depends, Query
from typing import List, Optional
from datetime import datetime
import uuid

from database.db import get_db
from models.schemas import (
    ProjectCreate, ProjectUpdate, ProjectResponse,
    QuestionCreate, QuestionUpdate, QuestionResponse,
    DecisionCreate, DecisionResponse,
    MilestoneCreate, MilestoneResponse
)

router = APIRouter()

def generate_id() -> str:
    return str(uuid.uuid4())

# ===== Projects =====

@router.post("/", response_model=ProjectResponse)
async def create_project(project: ProjectCreate, db=Depends(get_db)):
    """إنشاء مشروع بحثي جديد"""
    project_id = generate_id()
    now = datetime.now()
    
    await db.execute("""
        INSERT INTO projects (id, name, description, status, color, parent_id, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, (project_id, project.name, project.description, project.status.value,
          project.color, project.parent_id, now, now))
    
    await db.commit()
    return await get_project(project_id, db)

@router.get("/", response_model=List[ProjectResponse])
async def list_projects(
    status: Optional[str] = None,
    parent_id: Optional[str] = None,
    db=Depends(get_db)
):
    """قائمة المشاريع"""
    query = """
        SELECT p.*,
               (SELECT COUNT(*) FROM notes WHERE project_id = p.id) as notes_count,
               (SELECT COUNT(*) FROM questions WHERE project_id = p.id) as questions_count
        FROM projects p
        WHERE 1=1
    """
    params = []
    
    if status:
        query += " AND p.status = ?"
        params.append(status)
    
    if parent_id:
        query += " AND p.parent_id = ?"
        params.append(parent_id)
    elif parent_id is None:
        query += " AND p.parent_id IS NULL"
    
    query += " ORDER BY p.updated_at DESC"
    
    result = await db.execute(query, params)
    rows = await result.fetchall()
    return [ProjectResponse(**dict(row)) for row in rows]

@router.get("/{project_id}", response_model=ProjectResponse)
async def get_project(project_id: str, db=Depends(get_db)):
    """جلب مشروع محدد"""
    result = await db.execute("""
        SELECT p.*,
               (SELECT COUNT(*) FROM notes WHERE project_id = p.id) as notes_count,
               (SELECT COUNT(*) FROM questions WHERE project_id = p.id) as questions_count
        FROM projects p
        WHERE p.id = ?
    """, (project_id,))
    
    row = await result.fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="المشروع غير موجود")
    
    return ProjectResponse(**dict(row))

@router.put("/{project_id}", response_model=ProjectResponse)
async def update_project(project_id: str, project: ProjectUpdate, db=Depends(get_db)):
    """تحديث مشروع"""
    existing = await db.execute("SELECT id FROM projects WHERE id = ?", (project_id,))
    if not await existing.fetchone():
        raise HTTPException(status_code=404, detail="المشروع غير موجود")
    
    updates = []
    params = []
    
    if project.name is not None:
        updates.append("name = ?")
        params.append(project.name)
    if project.description is not None:
        updates.append("description = ?")
        params.append(project.description)
    if project.status is not None:
        updates.append("status = ?")
        params.append(project.status.value)
    if project.color is not None:
        updates.append("color = ?")
        params.append(project.color)
    if project.parent_id is not None:
        updates.append("parent_id = ?")
        params.append(project.parent_id)
    
    updates.append("updated_at = ?")
    params.append(datetime.now())
    params.append(project_id)
    
    await db.execute(f"UPDATE projects SET {', '.join(updates)} WHERE id = ?", params)
    await db.commit()
    
    return await get_project(project_id, db)

@router.delete("/{project_id}")
async def delete_project(project_id: str, db=Depends(get_db)):
    """حذف مشروع"""
    result = await db.execute("DELETE FROM projects WHERE id = ?", (project_id,))
    if result.rowcount == 0:
        raise HTTPException(status_code=404, detail="المشروع غير موجود")
    
    await db.commit()
    return {"message": "تم حذف المشروع بنجاح"}

# ===== Questions (دفتر الأسئلة الحية) =====

@router.post("/{project_id}/questions", response_model=QuestionResponse)
async def create_question(project_id: str, question: QuestionCreate, db=Depends(get_db)):
    """إنشاء سؤال بحثي جديد"""
    # التحقق من وجود المشروع
    project = await db.execute("SELECT id FROM projects WHERE id = ?", (project_id,))
    if not await project.fetchone():
        raise HTTPException(status_code=404, detail="المشروع غير موجود")
    
    question_id = generate_id()
    now = datetime.now()
    
    await db.execute("""
        INSERT INTO questions (id, content, project_id, parent_question_id, status, priority, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, (question_id, question.content, project_id, question.parent_question_id,
          question.status.value, question.priority, now, now))
    
    await db.commit()
    return await get_question(question_id, db)

@router.get("/{project_id}/questions", response_model=List[QuestionResponse])
async def list_project_questions(
    project_id: str,
    status: Optional[str] = None,
    parent_only: bool = True,
    db=Depends(get_db)
):
    """قائمة أسئلة المشروع"""
    query = """
        SELECT q.*,
               (SELECT COUNT(*) FROM questions WHERE parent_question_id = q.id) as sub_questions_count
        FROM questions q
        WHERE q.project_id = ?
    """
    params = [project_id]
    
    if status:
        query += " AND q.status = ?"
        params.append(status)
    
    if parent_only:
        query += " AND q.parent_question_id IS NULL"
    
    query += " ORDER BY q.priority DESC, q.created_at DESC"
    
    result = await db.execute(query, params)
    rows = await result.fetchall()
    return [QuestionResponse(**dict(row)) for row in rows]

@router.get("/questions/{question_id}", response_model=QuestionResponse)
async def get_question(question_id: str, db=Depends(get_db)):
    """جلب سؤال محدد"""
    result = await db.execute("""
        SELECT q.*,
               (SELECT COUNT(*) FROM questions WHERE parent_question_id = q.id) as sub_questions_count
        FROM questions q
        WHERE q.id = ?
    """, (question_id,))
    
    row = await result.fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="السؤال غير موجود")
    
    return QuestionResponse(**dict(row))

@router.put("/questions/{question_id}", response_model=QuestionResponse)
async def update_question(question_id: str, question: QuestionUpdate, db=Depends(get_db)):
    """تحديث سؤال"""
    existing = await db.execute("SELECT id FROM questions WHERE id = ?", (question_id,))
    if not await existing.fetchone():
        raise HTTPException(status_code=404, detail="السؤال غير موجود")
    
    updates = []
    params = []
    
    if question.content is not None:
        updates.append("content = ?")
        params.append(question.content)
    if question.status is not None:
        updates.append("status = ?")
        params.append(question.status.value)
        if question.status.value == "resolved":
            updates.append("resolved_at = ?")
            params.append(datetime.now())
    if question.priority is not None:
        updates.append("priority = ?")
        params.append(question.priority)
    
    updates.append("updated_at = ?")
    params.append(datetime.now())
    params.append(question_id)
    
    await db.execute(f"UPDATE questions SET {', '.join(updates)} WHERE id = ?", params)
    await db.commit()
    
    return await get_question(question_id, db)

@router.post("/questions/{question_id}/branch", response_model=QuestionResponse)
async def branch_question(question_id: str, sub_question: QuestionCreate, db=Depends(get_db)):
    """تشعيب سؤال (إنشاء سؤال فرعي)"""
    parent = await db.execute("SELECT project_id FROM questions WHERE id = ?", (question_id,))
    parent_row = await parent.fetchone()
    
    if not parent_row:
        raise HTTPException(status_code=404, detail="السؤال الأصلي غير موجود")
    
    # تحديث حالة السؤال الأصلي
    await db.execute(
        "UPDATE questions SET status = 'branched', updated_at = ? WHERE id = ?",
        (datetime.now(), question_id)
    )
    
    # إنشاء السؤال الفرعي
    sub_id = generate_id()
    now = datetime.now()
    
    await db.execute("""
        INSERT INTO questions (id, content, project_id, parent_question_id, status, priority, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, (sub_id, sub_question.content, parent_row['project_id'], question_id,
          sub_question.status.value, sub_question.priority, now, now))
    
    await db.commit()
    return await get_question(sub_id, db)

# ===== Decisions (سجل القرارات) =====

@router.post("/{project_id}/decisions", response_model=DecisionResponse)
async def create_decision(project_id: str, decision: DecisionCreate, db=Depends(get_db)):
    """تسجيل قرار بحثي"""
    decision_id = generate_id()
    
    await db.execute("""
        INSERT INTO decisions (id, project_id, title, decision, reasoning, alternatives)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (decision_id, project_id, decision.title, decision.decision,
          decision.reasoning, decision.alternatives))
    
    await db.commit()
    
    result = await db.execute("SELECT * FROM decisions WHERE id = ?", (decision_id,))
    row = await result.fetchone()
    return DecisionResponse(**dict(row))

@router.get("/{project_id}/decisions", response_model=List[DecisionResponse])
async def list_project_decisions(project_id: str, db=Depends(get_db)):
    """قائمة قرارات المشروع"""
    result = await db.execute("""
        SELECT * FROM decisions WHERE project_id = ?
        ORDER BY created_at DESC
    """, (project_id,))
    
    rows = await result.fetchall()
    return [DecisionResponse(**dict(row)) for row in rows]

# ===== Milestones (نقاط التحول) =====

@router.post("/{project_id}/milestones", response_model=MilestoneResponse)
async def create_milestone(project_id: str, milestone: MilestoneCreate, db=Depends(get_db)):
    """إضافة نقطة تحول في الرحلة البحثية"""
    milestone_id = generate_id()
    
    await db.execute("""
        INSERT INTO journey_milestones (id, project_id, title, description, milestone_type, significance)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (milestone_id, project_id, milestone.title, milestone.description,
          milestone.milestone_type.value, milestone.significance))
    
    await db.commit()
    
    result = await db.execute("SELECT * FROM journey_milestones WHERE id = ?", (milestone_id,))
    row = await result.fetchone()
    return MilestoneResponse(**dict(row))

@router.get("/{project_id}/milestones", response_model=List[MilestoneResponse])
async def list_project_milestones(project_id: str, db=Depends(get_db)):
    """خريطة الرحلة البحثية"""
    result = await db.execute("""
        SELECT * FROM journey_milestones WHERE project_id = ?
        ORDER BY created_at ASC
    """, (project_id,))
    
    rows = await result.fetchall()
    return [MilestoneResponse(**dict(row)) for row in rows]

@router.get("/{project_id}/journey")
async def get_research_journey(project_id: str, db=Depends(get_db)):
    """الرحلة البحثية الكاملة للمشروع"""
    # المشروع
    project = await get_project(project_id, db)
    
    # نقاط التحول
    milestones = await list_project_milestones(project_id, db)
    
    # القرارات
    decisions = await list_project_decisions(project_id, db)
    
    # الأسئلة
    questions = await list_project_questions(project_id, db=db)
    
    # الملاحظات (عدد فقط مع آخر 5)
    notes_result = await db.execute("""
        SELECT id, title, created_at FROM notes 
        WHERE project_id = ? 
        ORDER BY created_at DESC LIMIT 5
    """, (project_id,))
    recent_notes = [dict(row) for row in await notes_result.fetchall()]
    
    return {
        "project": project,
        "milestones": milestones,
        "decisions": decisions,
        "questions": questions,
        "recent_notes": recent_notes,
        "timeline": sorted(
            [{"type": "milestone", "date": m.created_at, "data": m} for m in milestones] +
            [{"type": "decision", "date": d.created_at, "data": d} for d in decisions],
            key=lambda x: x["date"]
        )
    }
