"""
Obsidia Search Router - البحث النصي البسيط

ملاحظة: البحث هنا نصي بسيط (FTS5)، وليس دلالياً
البحث الدلالي من مسؤولية محرك البحث في المنصة
"""

from fastapi import APIRouter, HTTPException, Depends, Query
from typing import List, Optional
from datetime import datetime

from database.db import get_db
from models.schemas import SearchQuery, SearchResult

router = APIRouter()

@router.post("/", response_model=List[SearchResult])
async def search(query: SearchQuery, db=Depends(get_db)):
    """البحث النصي الشامل"""
    results = []
    
    # البحث في الملاحظات
    if "notes" in query.search_in:
        notes_query = """
            SELECT n.id, n.title, n.content, n.created_at,
                   bm25(notes_fts) as score
            FROM notes_fts
            JOIN notes n ON notes_fts.rowid = n.rowid
            WHERE notes_fts MATCH ?
        """
        params = [query.query]
        
        if query.project_id:
            notes_query += " AND n.project_id = ?"
            params.append(query.project_id)
        
        if query.date_from:
            notes_query += " AND n.created_at >= ?"
            params.append(query.date_from)
        
        if query.date_to:
            notes_query += " AND n.created_at <= ?"
            params.append(query.date_to)
        
        notes_query += " ORDER BY score LIMIT ?"
        params.append(query.limit)
        
        try:
            result = await db.execute(notes_query, params)
            rows = await result.fetchall()
            
            for row in rows:
                content = row['content']
                # إنشاء مقتطف
                snippet = content[:200] + "..." if len(content) > 200 else content
                
                results.append(SearchResult(
                    type="note",
                    id=row['id'],
                    title=row['title'],
                    snippet=snippet,
                    score=abs(row['score']),
                    created_at=row['created_at']
                ))
        except Exception as e:
            # FTS قد لا يعمل على بعض الاستعلامات
            pass
    
    # البحث في الأسئلة
    if "questions" in query.search_in:
        q_result = await db.execute("""
            SELECT id, content, created_at
            FROM questions
            WHERE content LIKE ?
            ORDER BY created_at DESC
            LIMIT ?
        """, (f"%{query.query}%", query.limit))
        
        for row in await q_result.fetchall():
            results.append(SearchResult(
                type="question",
                id=row['id'],
                title="سؤال بحثي",
                snippet=row['content'][:200],
                score=1.0,
                created_at=row['created_at']
            ))
    
    # البحث في الاقتباسات
    if "quotations" in query.search_in:
        q_result = await db.execute("""
            SELECT id, content, source, created_at
            FROM quotations
            WHERE content LIKE ?
            ORDER BY created_at DESC
            LIMIT ?
        """, (f"%{query.query}%", query.limit))
        
        for row in await q_result.fetchall():
            results.append(SearchResult(
                type="quotation",
                id=row['id'],
                title=row['source'] or "اقتباس",
                snippet=row['content'][:200],
                score=1.0,
                created_at=row['created_at']
            ))
    
    # ترتيب النتائج
    results.sort(key=lambda x: x.score, reverse=True)
    
    return results[:query.limit]

@router.get("/suggestions")
async def get_search_suggestions(
    q: str = Query(..., min_length=2),
    limit: int = 10,
    db=Depends(get_db)
):
    """اقتراحات البحث من العناوين والوسوم"""
    suggestions = []
    
    # من عناوين الملاحظات
    notes = await db.execute("""
        SELECT DISTINCT title FROM notes
        WHERE title LIKE ?
        LIMIT ?
    """, (f"%{q}%", limit))
    
    for row in await notes.fetchall():
        suggestions.append({"type": "note", "text": row['title']})
    
    # من الوسوم
    tags = await db.execute("""
        SELECT name FROM tags
        WHERE name LIKE ?
        LIMIT ?
    """, (f"%{q}%", limit))
    
    for row in await tags.fetchall():
        suggestions.append({"type": "tag", "text": f"#{row['name']}"})
    
    return suggestions[:limit]

@router.get("/recent")
async def get_recent_searches(limit: int = 10, db=Depends(get_db)):
    """آخر عمليات البحث (للتذكير)"""
    # يمكن إضافة جدول لتتبع عمليات البحث لاحقاً
    return []

@router.get("/stats")
async def get_search_stats(db=Depends(get_db)):
    """إحصائيات البحث"""
    notes_count = await db.execute("SELECT COUNT(*) as count FROM notes")
    tags_count = await db.execute("SELECT COUNT(*) as count FROM tags")
    questions_count = await db.execute("SELECT COUNT(*) as count FROM questions")
    quotations_count = await db.execute("SELECT COUNT(*) as count FROM quotations")
    
    return {
        "total_notes": (await notes_count.fetchone())['count'],
        "total_tags": (await tags_count.fetchone())['count'],
        "total_questions": (await questions_count.fetchone())['count'],
        "total_quotations": (await quotations_count.fetchone())['count'],
        "searchable_items": "notes, questions, quotations"
    }
