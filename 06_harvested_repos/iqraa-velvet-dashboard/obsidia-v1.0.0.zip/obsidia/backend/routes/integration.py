"""
Obsidia Integration Router - التكامل مع منصة إقرأ

6 نقاط تكامل فقط:

من إقرأ إلى Obsidia (3):
1. زر "أضف للمفكرة" (ملاحظة + رابط)
2. تحديد نص + "أضف كاقتباس"
3. إشعار بانتهاء تحليل

من Obsidia إلى إقرأ (3):
4. زر "ابحث في إقرأ"
5. زر "اطلب تحليل" (يُرسل للوكلاء)
6. زر "افتح المصدر"

قاعدة: Obsidia لا تستورد بيانات المنصة، ولا تُصدّر ملاحظات الباحث
"""

from fastapi import APIRouter, HTTPException, Depends
from typing import Optional
from datetime import datetime
import uuid
import os
import httpx

from database.db import get_db
from models.schemas import IqraNote, IqraQuotation, IqraSearchRequest

router = APIRouter()

# إعدادات التكامل
IQRA_API_URL = os.getenv("IQRA_API_URL", "http://localhost:8000/api")
IQRA_API_KEY = os.getenv("IQRA_API_KEY", "")

def generate_id() -> str:
    return str(uuid.uuid4())

# ===== من إقرأ إلى Obsidia =====

@router.post("/from-iqra/note")
async def add_note_from_iqra(note: IqraNote, db=Depends(get_db)):
    """
    نقطة 1: زر "أضف للمفكرة" في إقرأ
    يُنشئ ملاحظة جديدة مع رابط للمصدر
    """
    note_id = generate_id()
    now = datetime.now()
    
    # إنشاء العنوان من المحتوى إن لم يكن موجوداً
    title = note.source_title or note.content[:50] + "..."
    
    # إضافة الملاحظة
    await db.execute("""
        INSERT INTO notes (id, title, content, content_type, source, source_url, created_at, updated_at)
        VALUES (?, ?, ?, 'markdown', 'iqra', ?, ?, ?)
    """, (note_id, title, note.content, note.source_url, now, now))
    
    # إضافة وسم تلقائي
    tag_result = await db.execute("SELECT id FROM tags WHERE name = 'من_إقرأ'")
    tag_row = await tag_result.fetchone()
    
    if not tag_row:
        tag_id = generate_id()
        await db.execute(
            "INSERT INTO tags (id, name, color) VALUES (?, 'من_إقرأ', '#6366F1')",
            (tag_id,)
        )
    else:
        tag_id = tag_row['id']
    
    await db.execute(
        "INSERT INTO note_tags (note_id, tag_id) VALUES (?, ?)",
        (note_id, tag_id)
    )
    
    await db.commit()
    
    return {
        "message": "تمت إضافة الملاحظة من إقرأ",
        "note_id": note_id,
        "title": title
    }

@router.post("/from-iqra/quotation")
async def add_quotation_from_iqra(quotation: IqraQuotation, db=Depends(get_db)):
    """
    نقطة 2: تحديد نص + "أضف كاقتباس" في إقرأ
    """
    quotation_id = generate_id()
    
    await db.execute("""
        INSERT INTO quotations (id, content, source, source_url, author, page)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (quotation_id, quotation.content, quotation.source_title,
          quotation.source_url, quotation.author, quotation.page))
    
    await db.commit()
    
    return {
        "message": "تمت إضافة الاقتباس",
        "quotation_id": quotation_id
    }

@router.post("/from-iqra/notification")
async def receive_analysis_notification(
    analysis_id: str,
    analysis_type: str,
    status: str,
    result_url: Optional[str] = None,
    db=Depends(get_db)
):
    """
    نقطة 3: إشعار بانتهاء تحليل من إقرأ
    """
    # إنشاء تذكير للباحث
    reminder_id = generate_id()
    
    message = f"انتهى تحليل {analysis_type} في إقرأ"
    if result_url:
        message += f"\nالنتائج: {result_url}"
    
    await db.execute("""
        INSERT INTO reminders (id, reminder_type, message, due_at)
        VALUES (?, 'custom', ?, ?)
    """, (reminder_id, message, datetime.now()))
    
    await db.commit()
    
    return {
        "message": "تم استلام الإشعار",
        "reminder_id": reminder_id
    }

# ===== من Obsidia إلى إقرأ =====

@router.post("/to-iqra/search")
async def search_in_iqra(request: IqraSearchRequest):
    """
    نقطة 4: زر "ابحث في إقرأ"
    يُعيد رابطاً لصفحة البحث في إقرأ
    """
    # بناء رابط البحث
    search_url = f"{IQRA_API_URL}/search?q={request.query}&type={request.search_type}"
    
    return {
        "action": "redirect",
        "url": search_url,
        "message": "افتح هذا الرابط للبحث في إقرأ"
    }

@router.post("/to-iqra/analyze")
async def request_analysis(
    content: str,
    analysis_type: str = "concepts",
    callback_url: Optional[str] = None
):
    """
    نقطة 5: زر "اطلب تحليل" (يُرسل للوكلاء)
    """
    if not IQRA_API_KEY:
        return {
            "action": "manual",
            "message": "التكامل غير مُفعّل. انسخ المحتوى وأرسله يدوياً لإقرأ"
        }
    
    # إرسال طلب التحليل لـ API إقرأ
    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{IQRA_API_URL}/analyze",
                json={
                    "content": content,
                    "analysis_type": analysis_type,
                    "callback_url": callback_url
                },
                headers={"Authorization": f"Bearer {IQRA_API_KEY}"},
                timeout=30.0
            )
            
            if response.status_code == 200:
                return {
                    "message": "تم إرسال طلب التحليل",
                    "analysis_id": response.json().get("analysis_id")
                }
            else:
                raise HTTPException(status_code=response.status_code, detail="فشل الطلب")
                
    except httpx.TimeoutException:
        return {
            "action": "manual",
            "message": "انتهت مهلة الاتصال. حاول لاحقاً"
        }

@router.get("/to-iqra/open/{source_url:path}")
async def open_source_in_iqra(source_url: str):
    """
    نقطة 6: زر "افتح المصدر" في إقرأ
    """
    # بناء رابط لفتح المصدر في إقرأ
    viewer_url = f"{IQRA_API_URL}/viewer?url={source_url}"
    
    return {
        "action": "redirect",
        "url": viewer_url,
        "message": "افتح هذا الرابط لعرض المصدر في إقرأ"
    }

# ===== حالة التكامل =====

@router.get("/status")
async def get_integration_status():
    """حالة التكامل مع إقرأ"""
    is_configured = bool(IQRA_API_URL and IQRA_API_KEY)
    
    # اختبار الاتصال
    is_connected = False
    if is_configured:
        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    f"{IQRA_API_URL}/health",
                    timeout=5.0
                )
                is_connected = response.status_code == 200
        except:
            pass
    
    return {
        "configured": is_configured,
        "connected": is_connected,
        "iqra_url": IQRA_API_URL if is_configured else None,
        "features": {
            "add_note": True,  # دائماً متاح
            "add_quotation": True,
            "notifications": is_connected,
            "search": True,  # يفتح رابط
            "analyze": is_connected,
            "open_source": True
        }
    }
