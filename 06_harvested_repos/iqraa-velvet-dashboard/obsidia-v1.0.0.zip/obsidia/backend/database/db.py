"""
Obsidia Database - قاعدة بيانات SQLite للتخزين المحلي

الجداول:
1. notes - الملاحظات
2. tags - الوسوم
3. note_tags - العلاقة بين الملاحظات والوسوم
4. links - الروابط بين الملاحظات [[]]
5. projects - المشاريع البحثية
6. questions - الأسئلة البحثية
7. quotations - الاقتباسات
8. cognitive_profile - بيانات المرآة المعرفية
9. reminders - التذكيرات
10. sync_log - سجل المزامنة
"""

import aiosqlite
import os
from datetime import datetime
from pathlib import Path

# مسار قاعدة البيانات
DB_PATH = Path(os.getenv("OBSIDIA_DB_PATH", "./data/obsidia.db"))
DB_PATH.parent.mkdir(parents=True, exist_ok=True)

async def get_db():
    """الحصول على اتصال بقاعدة البيانات"""
    db = await aiosqlite.connect(str(DB_PATH))
    db.row_factory = aiosqlite.Row
    try:
        yield db
    finally:
        await db.close()

async def init_db():
    """تهيئة قاعدة البيانات وإنشاء الجداول"""
    async with aiosqlite.connect(str(DB_PATH)) as db:
        # تفعيل المفاتيح الأجنبية
        await db.execute("PRAGMA foreign_keys = ON")
        
        # 1. جدول الملاحظات
        await db.execute("""
            CREATE TABLE IF NOT EXISTS notes (
                id TEXT PRIMARY KEY,
                title TEXT NOT NULL,
                content TEXT NOT NULL,
                content_type TEXT DEFAULT 'markdown',
                source TEXT DEFAULT 'manual',
                source_url TEXT,
                project_id TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                is_orphan INTEGER DEFAULT 0,
                review_count INTEGER DEFAULT 0,
                last_reviewed_at TIMESTAMP,
                next_review_at TIMESTAMP,
                FOREIGN KEY (project_id) REFERENCES projects(id)
            )
        """)
        
        # 2. جدول الوسوم
        await db.execute("""
            CREATE TABLE IF NOT EXISTS tags (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL UNIQUE,
                color TEXT DEFAULT '#3B82F6',
                description TEXT,
                usage_count INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # 3. جدول العلاقة بين الملاحظات والوسوم
        await db.execute("""
            CREATE TABLE IF NOT EXISTS note_tags (
                note_id TEXT NOT NULL,
                tag_id TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (note_id, tag_id),
                FOREIGN KEY (note_id) REFERENCES notes(id) ON DELETE CASCADE,
                FOREIGN KEY (tag_id) REFERENCES tags(id) ON DELETE CASCADE
            )
        """)
        
        # 4. جدول الروابط بين الملاحظات [[]]
        await db.execute("""
            CREATE TABLE IF NOT EXISTS links (
                id TEXT PRIMARY KEY,
                source_note_id TEXT NOT NULL,
                target_note_id TEXT NOT NULL,
                link_type TEXT DEFAULT 'reference',
                context TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (source_note_id) REFERENCES notes(id) ON DELETE CASCADE,
                FOREIGN KEY (target_note_id) REFERENCES notes(id) ON DELETE CASCADE,
                UNIQUE(source_note_id, target_note_id)
            )
        """)
        
        # 5. جدول المشاريع البحثية
        await db.execute("""
            CREATE TABLE IF NOT EXISTS projects (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                description TEXT,
                status TEXT DEFAULT 'active',
                color TEXT DEFAULT '#10B981',
                parent_id TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (parent_id) REFERENCES projects(id)
            )
        """)
        
        # 6. جدول الأسئلة البحثية
        await db.execute("""
            CREATE TABLE IF NOT EXISTS questions (
                id TEXT PRIMARY KEY,
                content TEXT NOT NULL,
                project_id TEXT,
                parent_question_id TEXT,
                status TEXT DEFAULT 'open',
                priority INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                resolved_at TIMESTAMP,
                FOREIGN KEY (project_id) REFERENCES projects(id),
                FOREIGN KEY (parent_question_id) REFERENCES questions(id)
            )
        """)
        
        # 7. جدول الاقتباسات
        await db.execute("""
            CREATE TABLE IF NOT EXISTS quotations (
                id TEXT PRIMARY KEY,
                content TEXT NOT NULL,
                source TEXT,
                source_url TEXT,
                author TEXT,
                page TEXT,
                note_id TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (note_id) REFERENCES notes(id) ON DELETE SET NULL
            )
        """)
        
        # 8. جدول المرآة المعرفية (تحليل السلوك لا المحتوى)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS cognitive_profile (
                id TEXT PRIMARY KEY,
                date DATE NOT NULL UNIQUE,
                notes_created INTEGER DEFAULT 0,
                notes_edited INTEGER DEFAULT 0,
                links_created INTEGER DEFAULT 0,
                tags_used INTEGER DEFAULT 0,
                active_minutes INTEGER DEFAULT 0,
                peak_hour INTEGER,
                most_used_tags TEXT,
                momentum_score REAL DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # 9. جدول التذكيرات
        await db.execute("""
            CREATE TABLE IF NOT EXISTS reminders (
                id TEXT PRIMARY KEY,
                note_id TEXT,
                question_id TEXT,
                reminder_type TEXT NOT NULL,
                message TEXT,
                due_at TIMESTAMP NOT NULL,
                is_completed INTEGER DEFAULT 0,
                completed_at TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (note_id) REFERENCES notes(id) ON DELETE CASCADE,
                FOREIGN KEY (question_id) REFERENCES questions(id) ON DELETE CASCADE
            )
        """)
        
        # 10. جدول سجل المزامنة
        await db.execute("""
            CREATE TABLE IF NOT EXISTS sync_log (
                id TEXT PRIMARY KEY,
                sync_type TEXT NOT NULL,
                direction TEXT NOT NULL,
                status TEXT NOT NULL,
                items_synced INTEGER DEFAULT 0,
                error_message TEXT,
                started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                completed_at TIMESTAMP
            )
        """)
        
        # 11. جدول القرارات البحثية
        await db.execute("""
            CREATE TABLE IF NOT EXISTS decisions (
                id TEXT PRIMARY KEY,
                project_id TEXT,
                title TEXT NOT NULL,
                decision TEXT NOT NULL,
                reasoning TEXT,
                alternatives TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (project_id) REFERENCES projects(id)
            )
        """)
        
        # 12. جدول نقاط التحول في الرحلة البحثية
        await db.execute("""
            CREATE TABLE IF NOT EXISTS journey_milestones (
                id TEXT PRIMARY KEY,
                project_id TEXT,
                title TEXT NOT NULL,
                description TEXT,
                milestone_type TEXT,
                significance INTEGER DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (project_id) REFERENCES projects(id)
            )
        """)
        
        # إنشاء الفهارس للأداء
        await db.execute("CREATE INDEX IF NOT EXISTS idx_notes_project ON notes(project_id)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_notes_created ON notes(created_at)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_notes_updated ON notes(updated_at)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_links_source ON links(source_note_id)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_links_target ON links(target_note_id)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_questions_project ON questions(project_id)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_reminders_due ON reminders(due_at)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_cognitive_date ON cognitive_profile(date)")
        
        # فهرس البحث النصي الكامل
        await db.execute("""
            CREATE VIRTUAL TABLE IF NOT EXISTS notes_fts USING fts5(
                title, content, content='notes', content_rowid='rowid'
            )
        """)
        
        await db.commit()
        print("✅ Database initialized successfully")

async def backup_to_file(backup_path: str):
    """نسخ احتياطي لقاعدة البيانات"""
    import shutil
    shutil.copy2(str(DB_PATH), backup_path)
    return backup_path
