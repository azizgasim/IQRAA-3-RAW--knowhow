"""
Obsidia - المفكرة الذكية الشخصية للباحث
Backend API - FastAPI

الفلسفة: "ليست عقلاً بل وعياً بالعقل"
- طبقة فوق معرفية تُراقب تفكير الباحث وتُسجّله
- 25 وظيفة شخصية
- تكامل محدود مع منصة إقرأ (6 نقاط فقط)
"""

from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from contextlib import asynccontextmanager
import uvicorn

from database.db import init_db, get_db
from routes import notes, tags, projects, search, sync, integration, cognitive

# إعدادات التطبيق
APP_NAME = "Obsidia"
APP_VERSION = "1.0.0"
APP_DESCRIPTION = """
المفكرة الذكية الشخصية للباحث - امتداد رقمي لذاكرته وتفكيره.

## المبادئ الأساسية:
- **الشخصية**: كل ما في Obsidia ينتمي للباحث الفرد
- **الامتداد**: تُسجّل ما يفكر فيه، لا ما يجب أن يفكر فيه  
- **الاستقلالية**: تعمل بكفاءة كاملة بدون المنصة

## القواعد الذهبية:
1. المفكرة لا تستدعي نموذجاً لغوياً للتحليل
2. المفكرة لا تُعيد كتابة المخرجات
3. المفكرة لا تقترح حلولاً معرفية (تُذكّر فقط)
"""

@asynccontextmanager
async def lifespan(app: FastAPI):
    """إدارة دورة حياة التطبيق"""
    # عند البدء
    await init_db()
    print("✅ Obsidia started successfully")
    yield
    # عند الإغلاق
    print("👋 Obsidia shutting down")

# إنشاء التطبيق
app = FastAPI(
    title=APP_NAME,
    version=APP_VERSION,
    description=APP_DESCRIPTION,
    lifespan=lifespan,
    docs_url="/api/docs",
    redoc_url="/api/redoc"
)

# إعداد CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # في الإنتاج: حدد النطاقات المسموحة
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# تسجيل الـ Routes
app.include_router(notes.router, prefix="/api/notes", tags=["الملاحظات"])
app.include_router(tags.router, prefix="/api/tags", tags=["الوسوم"])
app.include_router(projects.router, prefix="/api/projects", tags=["المشاريع البحثية"])
app.include_router(search.router, prefix="/api/search", tags=["البحث"])
app.include_router(sync.router, prefix="/api/sync", tags=["المزامنة"])
app.include_router(integration.router, prefix="/api/integration", tags=["التكامل مع إقرأ"])
app.include_router(cognitive.router, prefix="/api/cognitive", tags=["المرآة المعرفية"])

@app.get("/", tags=["الرئيسية"])
async def root():
    """الصفحة الرئيسية"""
    return {
        "name": APP_NAME,
        "version": APP_VERSION,
        "philosophy": "ليست عقلاً بل وعياً بالعقل",
        "status": "running",
        "endpoints": {
            "docs": "/api/docs",
            "notes": "/api/notes",
            "tags": "/api/tags",
            "projects": "/api/projects",
            "search": "/api/search",
            "sync": "/api/sync",
            "integration": "/api/integration",
            "cognitive": "/api/cognitive"
        }
    }

@app.get("/health", tags=["الصحة"])
async def health_check():
    """فحص صحة النظام"""
    return {
        "status": "healthy",
        "database": "connected",
        "version": APP_VERSION
    }

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8001,
        reload=True
    )
